"""vsim body builder: raw XML-assembly + geometry-math primitives only. No knowledge of limbs,
rings, caps, torsos, or any other body-plan concept -- callers (a ModuleLibrary's construct_robot)
resolve every name/origin/axis to an absolute value and hand it to these emitters."""
import math
import os
import uuid
from pathlib import Path

_GENERATED_ROOT = Path(__file__).parent / "assets" / "generated"
_PROC_DIR: Path | None = None


def generated_dir() -> Path:
    """Scratch directory for emitted assets, unique to this PROCESS.

    Every emitted name here is a function of the body, not of the run: `ant_morph_{gi}.vsim`,
    `{name}_prop_{gi}.vsim`, `{name}.png`. That is fine for one process and wrong the moment two
    share an install, which is the normal case -- the paper harness runs 8 training runs at once on
    one machine against one installed package, and each rewrites all of these on every resample.

    Sharing the path corrupts a rebuild two ways, both observed:

    * `write_text` truncates before it writes, so a run could import a file another had just
      emptied -- `XML_ERROR_EMPTY_DOCUMENT`, no articulation def, and `get_articulation_def`
      returns None.
    * A run could import a file another had fully replaced between its own write and its import.
      That build then wires its gather/scatter tensors from a record describing a *different body*:
      a KeyError on a link the articulation does not have, or -- when the two happen to overlap
      enough -- no error at all, just warnings, and a run that trains on the wrong morphology.

    Per-process isolation is what makes the write and the import an atomic pair; nothing else here
    needs locking. Directories are left behind deliberately: the XML that failed to import is the
    one artifact worth having after a crash. They are gitignored and a few KB each.
    """
    global _PROC_DIR
    if _PROC_DIR is None:
        # pid alone is not unique across containers sharing a bind-mounted install; uuid alone
        # loses the ability to tell which process left a directory behind. Keep both.
        _PROC_DIR = _GENERATED_ROOT / f"p{os.getpid()}_{uuid.uuid4().hex[:8]}"
        _PROC_DIR.mkdir(parents=True, exist_ok=True)
    return _PROC_DIR


def fmt_float(v: float) -> str:
    return repr(0.0 if v == 0 else float(v))


def vec_str(mag: float, u: tuple) -> str:
    return f"{fmt_float(mag * u[0])} {fmt_float(mag * u[1])} {fmt_float(mag * u[2])}"


def quat_axis(axis: tuple, angle: float) -> tuple:
    s = math.sin(0.5 * angle)
    return (axis[0] * s, axis[1] * s, axis[2] * s, math.cos(0.5 * angle))


def quat_mul(a: tuple, b: tuple) -> tuple:
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return (aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz)


def quat_str(q: tuple) -> str:
    return f"{fmt_float(q[0])} {fmt_float(q[1])} {fmt_float(q[2])} {fmt_float(q[3])}"


def quat_rotate(q: tuple, u: tuple) -> tuple:
    x, y, z, w = q
    t = (2 * (y * u[2] - z * u[1]), 2 * (z * u[0] - x * u[2]), 2 * (x * u[1] - y * u[0]))
    c = (y * t[2] - z * t[1], z * t[0] - x * t[2], x * t[1] - y * t[0])
    return tuple(u[i] + w * t[i] + c[i] for i in range(3))


def geom_volume(kind: str, dims: tuple) -> float:
    if kind == "box":
        return 8.0 * dims[0] * dims[1] * dims[2]
    if kind == "cylinder":
        return math.pi * dims[1] ** 2 * 2 * dims[0]
    if kind == "sphere":
        return 4.0 / 3.0 * math.pi * dims[0] ** 3
    raise ValueError(f"unknown geom kind {kind}")


def geom_xml(kind: str, dims: tuple) -> str:
    if kind == "box":
        return f'<box size="{fmt_float(dims[0])} {fmt_float(dims[1])} {fmt_float(dims[2])}"/>'
    if kind == "cylinder":
        return f'<cylinder length="{fmt_float(dims[0])}" radius="{fmt_float(dims[1])}"/>'
    if kind == "sphere":
        return f'<sphere radius="{fmt_float(dims[0])}"/>'
    raise ValueError(f"unknown geom kind {kind}")


def collision_xml(origin: str, rot: str, kind: str, dims: tuple) -> str:
    return f"""        <collision>
            <origin xyz="{origin}" rot="{rot}"/>
            <geometry>
                {geom_xml(kind, dims)}
                <queryProperties useQueries="true"/>
            </geometry>
        </collision>"""


def inertial_xml(density) -> str:
    """mass=-1 => vsim derives mass and inertia from the collision volume at this density."""
    return f"""
        <inertial>
            <origin xyz="0.0 0.0 0.0" rot="0.0 0.0 0.0 1.0"/>
            <mass value="-1.0"/>
            <density value="{density}"/>
            <inertia ixx="-1.0" iyy="-1.0" izz="-1.0" ixy="-1.0" ixz="-1.0" iyz="-1.0"/>
        </inertial>"""


def link_xml(name: str, density, collisions: list) -> str:
    body = "\n" + "\n".join(collisions) if collisions else ""
    return f'    <link name="{name}">{inertial_xml(density)}{body}\n    </link>'


def explicit_inertial_xml(mass: float, inertia: float) -> str:
    """<inertial> with a caller-given mass/inertia and no geometry to derive them from.

    For links that need real mass to be a valid articulated-body stage but carry no collision
    geometry of their own -- density=-1 tells vsim not to derive anything from geometry, the mirror
    of `inertial_xml`'s mass=-1 "derive from geometry" sentinel. Matches vlearn's own massless-dummy
    link pattern (e.g. its `hip_roll_assembly_2`/`cube_dummy` sample assets)."""
    m, i = fmt_float(mass), fmt_float(inertia)
    return f"""
        <inertial>
            <origin xyz="0.0 0.0 0.0" rot="0.0 0.0 0.0 1.0"/>
            <mass value="{m}"/>
            <density value="-1"/>
            <inertia ixx="{i}" iyy="{i}" izz="{i}" ixy="0.0" ixz="0.0" iyz="0.0"/>
        </inertial>"""


def massless_link_xml(name: str, mass: float, inertia: float) -> str:
    """A link with explicit mass/inertia and no geometry -- so it has no visible or collidable
    presence, unlike `link_xml` (which always derives mass from a collision geom that then also
    renders, since this codebase never supplies a separate visual mesh)."""
    return f'    <link name="{name}">{explicit_inertial_xml(mass, inertia)}\n    </link>'


def joint_xml(name: str, joint_type: str, parent: str, child: str, origin: str,
              rot: str = "0.0 0.0 0.0 1.0", axis: str = None, limits: tuple = None,
              effort=None, velocity=None, dynamics: str = None) -> str:
    """joint_type: revolute/prismatic/fixed. axis+limits are omitted (no DOF) for fixed joints."""
    parts = [f'    <joint name="{name}" type="{joint_type}">',
              f'        <child link="{child}"/>',
              f'        <parent link="{parent}"/>',
              f'        <origin xyz="{origin}" rot="{rot}"/>',
              f'        <linkTransform xyz="{origin}" rot="{rot}"/>']
    if axis is not None:
        parts.append(f'        <axis xyz="{axis}"/>')
    if limits is not None:
        lo, hi = limits
        parts.append(f'        <limit lower="{lo}" upper="{hi}" effort="{effort}" velocity="{velocity}"/>')
    if dynamics is not None:
        parts.append(f'        <dynamics {dynamics}/>')
    parts.append('    </joint>')
    return "\n".join(parts)


def motor_xml(name: str, joint_name: str, gear, lo, hi) -> str:
    return f'        <motor name="{name}" joint="{joint_name}" gear="{gear}" lowLimit="{lo}" highLimit="{hi}"/>'


def sensor_xml(name: str, link: str, offset: str, flags: str = "contact ") -> str:
    return f'        <sensor name="{name}" link="{link}" offset="{offset}" flags="{flags}"/>'


def write_vsim(xml: str, index: int) -> Path:
    """Write an already-assembled vsim XML string to a per-index path in `generated_dir()`."""
    path = generated_dir() / f"ant_morph_{index}.vsim"
    path.write_text(xml)
    return path
