"""Body emission: the emitter mints every name, the library supplies every number.

A `BodyEmitter` walks a `Morphology` up front and assigns each module its canonical `(slot, depth)`
key, link name and joint name. A `ModuleLibrary.construct_robot` then only fills in geometry for
entities that already exist, addressed by that key, and gets back a `BodyRecord`: the XML plus the
structure the backend needs to interpret what the simulator reports.

Nothing here knows about rings, torsos, limbs-as-shapes or caps-as-shapes. Origins, axes,
rotations, limits and collision XML all arrive already resolved to absolute values.

**Why this layer exists.** The backend needs to know, for every DOF, link and sensor the simulator
reports, which module of which limb it belongs to. Before this it recovered that by parsing the
strings a library happened to choose -- `joint_{n}_{d}` split on underscores, `startswith("mod_")`,
`removeprefix("root_")` -- so a library that named a joint anything else produced not an error but a
plausible-looking wrong answer: a transposed gather index, a training curve that still goes up. That
failure mode is what this layer removes. A library cannot mis-key, cannot skip a module and cannot
invent a name, because it never chooses one.

**Where the line falls.** The emitter owns names, `(slot, depth)` keys, declaration order and the
record. The library owns every *number* -- origins, axes, rotations, limits, densities, collision
shapes. So a non-ring topology, or one whose slots are not evenly spaced, stays name-correct for
free. The one policy the emitter keeps is which link a limb's sensor rides (the deepest module in
that slot that actually emitted a link): that is structural, depending only on which modules have
geometry, and getting it wrong silently mismaps sensor-to-limb.

Modules with no physical presence -- a `bare` cap emits no link and no joint -- are still recorded,
with `link = None`. They carry no simulator entity but do carry an observation slot (`is_cap`, the
subtype one-hot), so leaving them out would push the backend back into deriving structure by a
second route. One source, always.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple, Union

from codesigner.backend.build_vsim import joint_xml, link_xml, massless_link_xml, motor_xml, sensor_xml
from codesigner.interfaces.modlib import (Module, ModuleLibrary, ModuleType, Morphology, RootAxis)


@dataclass
class ModuleRecord:
    """One module of the morphology, physical or not.

    `link` is None for a module that emitted no simulator entity -- a `bare` cap terminates the
    chain in the grammar only. It is still recorded: it owns an observation slot (is_cap, subtype
    one-hot), and deriving that by a second route is what this record exists to stop.
    """
    slot: int                       # 0-based attachment slot (position in the Morphology)
    depth: int                      # 0-based index within the chain
    module: Module
    type: ModuleType
    subtype: int                    # index within its own type's vocabulary
    length: float
    link: Union[str, None] = None
    parent_link: Union[str, None] = None
    joint: Union[str, None] = None
    joint_type: Union[str, None] = None
    dofs: Tuple[str, ...] = ()      # DOF-carrying joint names contributed by this module

    @property
    def emitted(self) -> bool:
        return self.link is not None

    @property
    def n_dofs(self) -> int:
        return len(self.dofs)


@dataclass(frozen=True)
class DofRecord:
    joint: str
    slot: int
    depth: int
    index: int                      # index within the module's own DOFs


@dataclass(frozen=True)
class RootDofRecord:
    joint: str
    axis: RootAxis
    index: int                      # position in the task's root_axes


@dataclass(frozen=True)
class SensorRecord:
    name: str
    slot: int
    depth: int          # which module in the chain carries it -- a sensor is placed on a module
    link: str


def _sensor_order(entry) -> tuple:
    """XML declaration order for sensors, which is the order vsim reports them and therefore the
    order the backend's scatter index assumes. (slot, depth), so a limb with sensors at several
    depths still has one stable order both sides agree on."""
    return entry[0].slot, entry[0].depth


@dataclass(frozen=True)
class BodyRecord:
    """What crosses back to the backend. The only legitimate way to interpret simulator names."""
    xml: str
    articulation: str               # <robot name=...>, for get_articulation_def_handle_by_name
    root_link: str                  # link the depth-0 modules attach to (parent in the rel-geom obs)
    n_slots: int
    max_depth: int
    modules: Tuple[ModuleRecord, ...]
    dofs: Tuple[DofRecord, ...]
    root_dofs: Tuple[RootDofRecord, ...]
    sensors: Tuple[SensorRecord, ...]

    def dof_index(self) -> Dict[str, Tuple[int, int, int]]:
        """joint name -> (slot, depth, index within module)."""
        return {d.joint: (d.slot, d.depth, d.index) for d in self.dofs}

    def root_dof_index(self) -> Dict[str, int]:
        """joint name -> position in root_axes."""
        return {d.joint: d.index for d in self.root_dofs}

    def actuated_root_positions(self) -> Tuple[int, ...]:
        """Positions in root_axes that carry a motor, ascending. The action width counts these; the
        observation's root block covers every axis, passive ones included."""
        return tuple(d.index for d in self.root_dofs if d.axis.actuated)

    def link_index(self) -> Dict[str, Tuple[int, int]]:
        """link name -> (slot, depth), emitted modules only."""
        return {m.link: (m.slot, m.depth) for m in self.modules if m.emitted}

    def module_at(self, slot: int, depth: int) -> ModuleRecord:
        return self._by_key[(slot, depth)]

    @property
    def _by_key(self) -> Dict[Tuple[int, int], ModuleRecord]:
        return {(m.slot, m.depth): m for m in self.modules}


@dataclass
class _Pending:
    """Buffered XML for one module, flushed in canonical order by `build`."""
    link: str = ""
    joint: str = ""
    motor: str = ""


class BodyEmitter:
    """Mints names and canonical order for one body; the library fills in geometry.

    Construct, call the `set_*` methods in any order, then `build()`.
    """

    def __init__(self, library: ModuleLibrary, morphology: Morphology,
                 root_axes: Union[Sequence[RootAxis], None] = None,
                 root_link: str = "torso"):
        if len(morphology) != library.n_slots:
            raise ValueError(
                f"morphology has {len(morphology)} slots, library {library.name!r} has "
                f"{library.n_slots}")
        self.library = library
        self.morphology = morphology
        self.root_axes: List[RootAxis] = list(root_axes or [])
        self.root_link = root_link

        # A mount joint's name is a function of the axis alone (`root_x` / `root_rx`), so two axes
        # of the same kind and direction would collide. Rejected here rather than silently emitting
        # duplicate joint names, which the backend would then key one DOF's record onto both.
        seen: Dict[str, int] = {}
        for i, ax in enumerate(self.root_axes):
            if ax.joint_name in seen:
                raise ValueError(
                    f"root_axes[{i}] {ax!r} has the same joint name {ax.joint_name!r} as "
                    f"root_axes[{seen[ax.joint_name]}]; a mount cannot repeat an axis")
            seen[ax.joint_name] = i

        self._vocab = {t: library.names(t) for t in ModuleType}
        self.modules: List[ModuleRecord] = []
        for slot, chain in enumerate(morphology):
            if len(chain) > library.max_depth:
                raise ValueError(
                    f"slot {slot}: chain of {len(chain)} exceeds max_depth={library.max_depth}")
            n_eff = sum(1 for m in chain if m.type is ModuleType.EFFECTOR)
            if n_eff > library.max_effectors:
                raise ValueError(
                    f"slot {slot}: {n_eff} effectors exceeds max_effectors="
                    f"{library.max_effectors} (the grammar forces a cap at the deepest slot)")
            for depth, module in enumerate(chain):
                self.modules.append(ModuleRecord(
                    slot=slot, depth=depth, module=module, type=module.type,
                    subtype=self._vocab[module.type].index(module.name),
                    length=library.module_length(module),
                ))
        self._by_key = {(m.slot, m.depth): m for m in self.modules}

        self._pending: Dict[Tuple[int, int], _Pending] = {}
        self._root_xml = ""
        self._mount_links: List[str] = [""] * len(self.root_axes)
        self._mount_joints: List[str] = [""] * len(self.root_axes)
        self._mount_motors: List[str] = [""] * len(self.root_axes)
        self._sensors: List[Tuple[SensorRecord, str]] = []
        self._dofs: List[DofRecord] = []

    # ---- names (the emitter's, and nobody else's) ------------------------------

    def link_name(self, rec: ModuleRecord) -> str:
        """`mod_{slot}_{depth}` / `cap_{slot}_{depth}`, both 1-based in XML only."""
        stem = "cap" if rec.type is ModuleType.CAP else "mod"
        return f"{stem}_{rec.slot + 1}_{rec.depth + 1}"

    def joint_name(self, rec: ModuleRecord) -> str:
        stem = "capjoint" if rec.type is ModuleType.CAP else "joint"
        return f"{stem}_{rec.slot + 1}_{rec.depth + 1}"

    def _parent_link(self, rec: ModuleRecord) -> str:
        if rec.depth == 0:
            return self.root_link
        return self.link_name(self._by_key[(rec.slot, rec.depth - 1)])

    # ---- what a library calls ---------------------------------------------------

    def chain(self, slot: int) -> List[ModuleRecord]:
        return [m for m in self.modules if m.slot == slot]

    def set_root(self, density, collisions: List[str]) -> None:
        """Geometry of the link every depth-0 module hangs off."""
        self._root_xml = link_xml(self.root_link, density, collisions)

    def set_root_mount(self, index: int, mass: float, inertia: float, axis: str,
                       limits: Union[Tuple[str, str], None], effort=None, velocity=None,
                       dynamics: str = None) -> None:
        """One link+joint of the world-mount chain, for root_axes[index] -- prismatic or revolute,
        whichever that `RootAxis` is.

        The chain runs `root_mount_0 -> ... -> root_mount_{k-1} -> root_link`, so the last mount
        joint's child is the root link itself.

        A motor is emitted only for an **actuated** axis. A passive one still gets its link and
        joint, so it carries a DOF the backend observes and the simulator integrates -- it simply
        cannot be driven. `limits=None` (an axis with no `range`) emits no `<limit>` either, which is
        what an unbounded slider needs.

        The link carries explicit `mass`/`inertia` and no collision geometry -- an articulated DOF
        still needs real mass, but this stage represents no physical part, so it should have no
        visible or collidable presence. A real collision geom (however small) would render, since
        this codebase never supplies a separate visual mesh -- that was previously a floating dot at
        every mount stage.
        """
        name = f"root_mount_{index}"
        ax = self.root_axes[index]
        joint = ax.joint_name
        child = (f"root_mount_{index + 1}" if index + 1 < len(self.root_axes) else self.root_link)
        self._mount_links[index] = massless_link_xml(name, mass, inertia)
        self._mount_joints[index] = joint_xml(
            joint, ax.joint_type, name, child, "0.0 0.0 0.0", axis=axis, limits=limits,
            effort=effort, velocity=velocity, dynamics=dynamics)
        self._mount_motors[index] = (
            motor_xml(joint, joint, "150.0", "-1.0", "1.0") if ax.actuated else "")

    def set_module(self, rec: ModuleRecord, density, collisions: List[str], origin: str,
                   rot: str = "0.0 0.0 0.0 1.0", axis: str = None,
                   limits: Tuple[str, str] = None, effort=None, velocity=None,
                   dynamics: str = None, motor_gear: str = "150.0") -> None:
        """Give a module physical presence: one link, and the joint attaching it to its parent.

        A module `set_module` is never called for emits nothing -- it stays in the record with
        `link = None`. `axis`/`limits` absent means a fixed joint (no DOF), which is what a cap
        rides.
        """
        if rec.type is ModuleType.EFFECTOR and rec.module.definition.action_dimensions != 1:
            raise ValueError(
                f"{rec.module.name!r} declares action_dimensions="
                f"{rec.module.definition.action_dimensions}; the padded layout gives one DOF per "
                "module, so multi-DOF modules need the layout rework (migration plan phase 4)")

        link = self.link_name(rec)
        joint = self.joint_name(rec)
        parent = self._parent_link(rec)
        jtype = "revolute" if axis is not None else "fixed"

        rec.link, rec.parent_link, rec.joint, rec.joint_type = link, parent, joint, jtype
        p = self._pending.setdefault((rec.slot, rec.depth), _Pending())
        p.link = link_xml(link, density, collisions)
        p.joint = joint_xml(joint, jtype, parent, link, origin, rot=rot, axis=axis, limits=limits,
                            effort=effort, velocity=velocity, dynamics=dynamics)
        if jtype != "fixed":
            rec.dofs = (joint,)
            self._dofs.append(DofRecord(joint=joint, slot=rec.slot, depth=rec.depth, index=0))
            p.motor = motor_xml(joint, joint, motor_gear, "-1.0", "1.0")

    def terminal(self, slot: int) -> Union[ModuleRecord, None]:
        """Deepest module in `slot` that actually emitted a link -- where a sensor may ride.

        Structural, so the emitter decides it: a `bare` cap leaves contact on the terminal effector.
        """
        emitted = [m for m in self.chain(slot) if m.emitted]
        return emitted[-1] if emitted else None

    def set_sensor(self, rec: ModuleRecord, offset: str, flags: str = "contact ") -> None:
        """One contact sensor on a MODULE's link. The offset is the library's.

        Addressed by module, not by slot: the observation reports a sensor on the module carrying it,
        so a library that wants readings at several depths just calls this several times. Placing one
        per limb (on `terminal(slot)`) is a library's choice, not the emitter's rule.
        """
        if rec is None or not rec.emitted:
            raise ValueError("a sensor needs a module that emitted a link; got "
                             f"{'None' if rec is None else f'slot {rec.slot} depth {rec.depth}'}")
        name = f"{rec.link}_sensor"
        self._sensors.append((SensorRecord(name=name, slot=rec.slot, depth=rec.depth, link=rec.link),
                              sensor_xml(name, rec.link, offset, flags)))

    # ---- flush ------------------------------------------------------------------

    def build(self) -> BodyRecord:
        """Assemble the XML in canonical order and freeze the record.

        Declarations are buffered and flushed in one fixed order, so the order a library happens to
        call the `set_*` methods in is irrelevant. That order is: links depth-major then ascending
        slot, cap links after all effector links; joints depth-major then **descending** slot, cap
        joints then root-mount joints last; motors per-slot; sensors ascending.

        **The descending-slot joint order looks accidental and is not.** Measured against the vlearn
        wheel this repo builds on: vsim reports DOFs and links in a *reverse*-DFS of the joint tree,
        with a link's children taken in reverse joint-declaration order. Declaring joints ascending
        yields DOFs `8_1, 8_2, 7_1, ...`; declaring them descending yields `1_1, 1_2, 2_1, ...`.
        Link declaration order has no effect at all. So joint order is the single lever on the
        packed DOF layout, and the recorded baseline reversed it precisely to get an ascending,
        depth-major report.

        That is why the emitter owns it rather than the library. A library reordering its calls
        would silently permute every DOF index in the simulator while every name stayed correct --
        the exact failure this whole layer exists to prevent, arriving through the back door. Frozen
        here, the golden gather/scatter tensors captured at `b119683` stay a live detector for it.
        """
        if not self._root_xml:
            raise ValueError("set_root was never called; the body has no root link")
        eff = sorted((m for m in self.modules if m.emitted and m.type is not ModuleType.CAP),
                     key=lambda m: (m.depth, m.slot))
        caps = sorted((m for m in self.modules if m.emitted and m.type is ModuleType.CAP),
                      key=lambda m: m.slot)

        parts = [f'<robot name="{self.root_link}">']
        parts.extend(self._mount_links)
        parts.append(self._root_xml)
        parts.extend(self._pending[(m.slot, m.depth)].link for m in eff)
        parts.extend(self._pending[(m.slot, m.depth)].link for m in caps)

        joints = sorted(eff, key=lambda m: (m.depth, -m.slot))
        parts.extend(self._pending[(m.slot, m.depth)].joint for m in joints)
        parts.extend(self._pending[(m.slot, m.depth)].joint for m in caps)
        parts.extend(self._mount_joints)

        motors = [self._pending[(m.slot, m.depth)].motor
                  for m in sorted(eff, key=lambda m: (m.slot, m.depth))
                  if self._pending[(m.slot, m.depth)].motor]
        parts.append('    <actuator>')
        parts.extend(motors)
        parts.extend(x for x in self._mount_motors if x)   # "" for a passive axis
        parts.append('    </actuator>')

        if self._sensors:
            parts.append('    <forceSensor>')
            parts.extend(x for _, x in sorted(self._sensors, key=_sensor_order))
            parts.append('    </forceSensor>')
        parts.append('</robot>')

        root_dofs = tuple(RootDofRecord(joint=ax.joint_name, axis=ax, index=i)
                          for i, ax in enumerate(self.root_axes))
        return BodyRecord(
            xml="\n".join(parts),
            articulation=self.root_link,
            root_link=self.root_link,
            n_slots=self.library.n_slots,
            max_depth=self.library.max_depth,
            modules=tuple(self.modules),
            dofs=tuple(self._dofs),
            root_dofs=root_dofs,
            sensors=tuple(s for s, _ in sorted(self._sensors, key=_sensor_order)),
        )
