"""Height-field terrain: authoring a PNG in the convention VSim actually reads it in.

`EnvironmentDef.import_height_field_def` is documented only as "the origin of the height field will
be at the top-left corner of the PNG image and zero height", which leaves the three things a caller
needs unresolved. Measured against the vlearn wheel this repo builds on, by importing calibration
PNGs and dropping probe spheres onto them (`tests/test_heightfield.py` re-checks all three):

    x      = (rows - 1 - row) * scale.x      -- rows run along +x, LAST row first
    z      = col * scale.z                   -- columns run along +z
    height = min_height + (max_height - min_height) * ALPHA / 255

The two surprises are the row reversal and the channel. **Height is the alpha channel**, not
luminance and not red: a PNG with no alpha, or the opaque alpha every ordinary image has, imports as
a flat slab at `max_height` with no error and no warning -- terrain that looks like terrain, is
collided with like terrain, and is perfectly level. That is how BodyGen's own `gap_terrain.png`
imports, which is why this module authors the course from an explicit profile instead of converting
it: the profile becomes a number in source rather than a channel in a binary blob, and it cannot
silently disagree with the phase observation computed from the same period.

`build_profile_png` takes a 1-D profile *already in world +x order* and handles the reversal, so no
caller has to remember it.
"""
from pathlib import Path

import numpy as np

_GENERATED_DIR = Path(__file__).parent / "assets" / "generated"


def build_profile_png(name: str, profile: np.ndarray, width_px: int) -> Path:
    """Write a height-field PNG whose surface follows `profile` along +x and is constant along z.

    `profile` is normalized height in `[0, 1]`, sample 0 at the terrain's own x=0 and running in
    **+x** -- the row reversal is applied here. `width_px` is the sample count across z; the terrain
    only has to be wide enough for the robot to stand on, since a planar task cannot leave its
    plane.

    Returns the written path. The caller supplies `min_height`/`max_height` to
    `import_height_field_def`, which is what turns `[0, 1]` back into metres.
    """
    if profile.ndim != 1:
        raise ValueError(f"profile must be 1-D, got shape {profile.shape}")
    alpha = np.clip(np.rint(profile * 255.0), 0, 255).astype(np.uint8)

    img = np.zeros((profile.size, width_px, 4), dtype=np.uint8)
    img[..., 0:3] = 180                                  # visible colour only; unread as height
    # Row 0 is the FARTHEST point in +x, so the profile is stored reversed. Getting this wrong
    # mirrors the course about its own midpoint -- which, for a periodic course, still looks
    # entirely correct.
    img[..., 3] = alpha[::-1, None]

    import imageio.v2 as imageio
    _GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    path = _GENERATED_DIR / f"{name}.png"
    imageio.imwrite(path, img)
    return path


def gap_profile(period: float, gap_width: float, resolution: float,
                start: float, length: float) -> tuple:
    """BodyGen's gap course: flat platforms of height 1, separated by gaps of height 0.

    Returns `(profile, n_samples)`. `start` is the terrain's own x=0 in course coordinates, so a
    robot spawning at course x=0 stands at profile position `-start`. Gap centres sit at odd
    multiples of `period / 2`, which puts **platform centres on multiples of `period`** -- so a
    robot spawning at x=0 starts in the middle of a platform rather than over a hole.
    """
    n = int(round(length / resolution))
    x = start + np.arange(n) * resolution
    # Distance to the nearest gap centre. Gap centres sit half a period off every multiple of the
    # period, so x = 0 -- where the robot spawns -- is a platform centre, the furthest point from
    # any hole. Inverting this puts the spawn point over open air, which trains perfectly well for
    # a few hundred steps of falling.
    to_gap = np.abs((x % period) - 0.5 * period)
    profile = (to_gap > 0.5 * gap_width).astype(np.float32)
    return profile, n
