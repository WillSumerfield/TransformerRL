"""The modular-robot layer: the padded per-module tensor layout over the simulation base.

The upper of the two package-owned backend layers (see CONTEXT.md's Architecture). Owns the padded depth-major
module layout, its gather/scatter indices, and scene rebuilds. Kept separate from
`simulation.py` so the simulation base carries no body-plan assumption, and separate from `Task`
so a user implementing a task is not buried in index math. Users inherit this; they never
override it.
"""
import gc
from math import ceil

import numpy as np
import torch
import vlearn as v
from vlearn.spaces import Box

from codesigner.interfaces.modlib import ModuleType
from codesigner.backend.simulation import MultiGroupEnvironmentGpu
from codesigner.backend.vlearn_helpers import store_initial_conditions_helper
from codesigner.backend.build_vsim import write_vsim
from codesigner.backend import obs_spec
from codesigner.backend.obs_spec import GlobalField, ModuleField

_SENSOR_COMPS  = 6                               # force-sensor components per module
_SET_GAP_CELLS = 4                               # gap between env groups in the grid (multiples of spacing)


@torch.jit.script
def _quat_to_rotmat(q: torch.Tensor) -> torch.Tensor:
    """(...,4) quaternion (x,y,z,w, normalized) -> (...,3,3) rotation matrix (columns = body axes
    in world frame). Used for the 6D rotation (first two columns) + relative-geometry obs (2a)."""
    x, y, z, w = q.unbind(-1)
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    R = torch.stack([
        1 - 2 * (yy + zz), 2 * (xy - wz),     2 * (xz + wy),
        2 * (xy + wz),     1 - 2 * (xx + zz), 2 * (yz - wx),
        2 * (xz - wy),     2 * (yz + wx),     1 - 2 * (xx + yy),
    ], dim=-1)
    if q.ndim == 2:
        return R.reshape(q.shape[0], 3, 3)
    if q.ndim == 3:
        return R.reshape(q.shape[0], q.shape[1], 3, 3)
    else:
        raise ValueError(f"Unexpected q.ndim={q.ndim}")


def _np(x):
    return x.detach().cpu().numpy() if torch.is_tensor(x) else x


class CodesignEnvironmentGpu(MultiGroupEnvironmentGpu):
    """One EnvironmentGroup per morphology. The 32-slot depth-major limb layout (only active
    EFFECTOR slots carry a DOF) is padded to a fixed width; the root block on top of it is not --
    its width is exact, computed once per instance from the task's root_axes (see __init__'s
    self._o_* offsets)."""

    # `compute_reward_termination_truncation`, `reward_term_trunc_helper`, `create_scene` and
    # `set_root_pose` are declared abstract on `Task` (codesigner.interfaces.task) -- they are the
    # user's to implement, so they belong on the interface rather than in the backend.

    # `obs_fields` and `compute_observations` are the observation pair: the standard fields are
    # declared here and a Task extends them, then fills its own by name. Width, offsets and the
    # published layout all derive from the declaration (see `backend.obs_spec`). Contract documented
    # on `Task`, which carries a forwarding stub for each.

    auto_reset = True
    """Whether `post_physics_step` resets envs that terminated or truncated on this step.

    On for the usual episodic loop. A planner that rolls the simulator forward as a *model* -- MPPI
    sampling a horizon, say -- turns it off: a sample that falls over must stay fallen for the rest
    of the horizon, and an auto-reset would instead hand it a fresh robot and let it keep scoring.
    The buffers are still written either way, so `term_buf`/`trunc_buf` still report what happened.
    """

    # ------------------------------------ Construction ------------------------------------

    @property
    def unwrapped(self):
        return self

    @property
    def design_layout(self):
        """One contiguous block of `envs_per_morph` envs per body, in `_morphologies` order.

        `None` before `setup`, when there is no scene and so nothing to attribute to.
        """
        if not self.n_morphs or not self.envs_per_morph:
            return None
        return self.n_morphs, self.envs_per_morph

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int,
        gravity: v.Vec3,
        timestep: float,
        frame_skip: int,
        spacing: float,
        max_contact_pairs_per_env: int,
        value_size: int = 1,
        reset_noise_scale: float = 1.0,
        dof_reset_pos_bias:  float = -0.2,
        dof_reset_pos_scale: float = 0.4,
        dof_reset_vel_bias:  float = -0.1,
        dof_reset_vel_scale: float = 0.2,
        root_axes: list = None,
        spawn_height: float = 0.75,
        **kwargs,
    ):
        # Simulation parameters and root mounting only -- no library, no bodies, no env count, and
        # so no gym. Everything that depends on those happens in setup() (D7).
        #
        # Root mounting is a TASK property, not a library one: the scene decides whether the robot
        # walks or is bolted above a table (D6, superseding ADR-0016's first clause).
        self.root_axes = root_axes
        self.spawn_height = spawn_height        # placement of every articulation, before per-body lift
        self.value_size = value_size            # reported to rl_games env_info (always 1)
        self.reset_noise_scale = reset_noise_scale
        self.dof_reset_pos_bias  = dof_reset_pos_bias
        self.dof_reset_pos_scale = dof_reset_pos_scale
        self.dof_reset_vel_bias  = dof_reset_vel_bias
        self.dof_reset_vel_scale = dof_reset_vel_scale

        self.module_library = None
        self.groups = []
        # Opt-in per-link external forces (see enable_link_external_forces). Reset on every rebuild,
        # since the commands wrap buffers tied to the gym that is about to be torn down.
        self._link_force_buf = None
        self._link_force_cmds = None
        self._link_force_views = []
        self._morphologies = []
        self.n_morphs = 0
        self.envs_per_morph = 0

        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            **kwargs,
        )

    # ------------------------------------ Lifecycle ------------------------------------

    def setup(self, module_library, num_envs: int, num_morphs: int, morphologies: list,
              seed: int = None) -> int:
        """Stand the task up: layout from the library, scene from the bodies, buffers from both.

        `num_morphs` bodies run across `num_envs` envs, so a body is scored on the average of
        `num_envs // num_morphs` parallel envs. **The division rounds down**, so the true env count
        can be lower than asked for -- it is returned, and callers must read it back. The Algorithm
        sets rl_games' `num_actors` from it, which sizes rollout buffers, so using the requested
        count instead produces shape mismatches or silently misaligned rollouts (D15, D16, D17).
        """
        if num_morphs < 1:
            raise ValueError(f"num_morphs must be >= 1, got {num_morphs}")
        if len(morphologies) != num_morphs:
            raise ValueError(
                f"setup got {len(morphologies)} morphologies but num_morphs={num_morphs}")
        epm = num_envs // num_morphs
        if epm < 1:
            raise ValueError(
                f"num_envs={num_envs} over num_morphs={num_morphs} leaves no envs per body")

        self.module_library = module_library
        self._derive_layout(module_library)
        self.n_morphs = num_morphs
        self.envs_per_morph = epm
        self._morphologies = list(morphologies)
        self._build_spaces()

        self.setup_simulation(num_morphs * epm, seed)
        self._build_scene()
        return self.total_num_envs

    def resample(self, morphologies: list):
        """Replace the bodies in play and rebuild the sim in place (full gym rebuild).

        vsim bakes link geometry at finalize, so new bodies require tearing the gym down and
        recreating it -- this is not a mutation and not a cheap path. The caller must reset
        afterwards (the env is left rebuilt-but-unreset).
        """
        if len(morphologies) != self.n_morphs:
            raise ValueError(
                f"resample got {len(morphologies)} morphologies but the task runs {self.n_morphs}")
        self._morphologies = list(morphologies)
        self._rebuild()

    def resize(self, num_envs: int, num_morphs: int, morphologies: list) -> int:
        """Change the env or body count. Returns the true env count, which rounds down.

        Mechanically identical to `resample` -- both tear the scene down and reallocate everything.
        The split is call-site clarity, not a cheap path versus an expensive one (D17b).
        """
        if len(morphologies) != num_morphs:
            raise ValueError(
                f"resize got {len(morphologies)} morphologies but num_morphs={num_morphs}")
        epm = num_envs // num_morphs
        if epm < 1:
            raise ValueError(
                f"num_envs={num_envs} over num_morphs={num_morphs} leaves no envs per body")
        self.n_morphs = num_morphs
        self.envs_per_morph = epm
        self.num_envs = num_morphs * epm        # contact buffers are resized off this at _create_gym
        self._morphologies = list(morphologies)
        self._rebuild()
        return self.total_num_envs

    def _derive_layout(self, ml) -> None:
        """The padded tensor grammar, taken from the live library rather than compiled in.

        Slot count, chain depth and subtype width are library-owned facts; duplicating them onto the
        Task would recreate the one-fact-in-four-places problem in a new place (D9). Nothing here is
        baked into the jit helpers -- they take every offset as an argument -- so this is free.
        """
        self._n_limbs     = ml.n_slots
        self._max_len     = ml.max_depth
        self._n_dofs_full = ml.n_slots * ml.max_depth
        self._n_sensor    = self._n_dofs_full * _SENSOR_COMPS   # per MODULE slot, not per limb
        self._n_sub       = ml.subtype_width

    def _slot(self, slot: int, depth: int) -> int:
        """Canonical padded slot for attachment slot at chain depth. Depth-major.

        Both arguments are 0-based, as `(slot, depth)` is everywhere inside the package; the 1-based
        numbers in XML names are the emitter's convention.
        """
        return depth * self._n_limbs + slot

    def _build_spaces(self) -> None:
        """Observation and action widths, derived in setup because the library fixes them (D9).

        The root block's width and the action width additionally depend on the task's root_axes,
        which are fixed per env and never resampled. **They do not depend on it the same way.** The
        canonical DOF space and the observation cover *every* root axis, so a planar task can see
        its own height and pitch; the action covers only the **actuated** ones, so a policy cannot
        drive a passive axis that exists to constrain the body rather than to be commanded.
        """
        D = self._n_dofs_full
        axes = self.root_axes or ()
        self._n_root_axes = len(axes)
        self._n_root_actuated = sum(1 for ax in axes if ax.actuated)
        self._n_dofs_ext = D + self._n_root_axes          # +1 canonical slot per root axis
        self._n_act = D + self._n_root_actuated           # what the policy emits

        # Declared fields -> regions -> offsets. `obs_fields` is the only place a width is written
        # down; every offset below is read back out of the resolution, so a field cannot be declared
        # one width and written at another.
        self._obs_groups, self._obs_total = obs_spec.resolve(self.obs_fields(), D)
        gl, mod = self._obs_groups[obs_spec.GLOBAL], self._obs_groups[obs_spec.MODULE]
        # Starts cached as plain ints for the jit helper, which cannot read attributes off `self`.
        # Derived, never authored -- change a width in `obs_fields` and these follow.
        self._o_root       = gl["root_height"]["off"]
        self._o_root_axes  = gl["root_axis_pos"]["off"]
        self._o_sin        = mod["sin"]["off"]
        self._o_cos        = mod["cos"]["off"]
        self._o_vel        = mod["vel"]["off"]
        self._o_act        = mod["act"]["off"]
        self._o_relpos     = mod["relpos"]["off"]
        self._o_relrot     = mod["relrot"]["off"]
        self._o_relvel     = mod["relvel"]["off"]
        self._o_sensor     = mod["sensor"]["off"]
        self._o_sensor_end = self._o_sensor + self._n_sensor
        self._o_has_sensor = mod["has_sensor"]["off"]
        self._o_length     = mod["length"]["off"]
        self._o_mask       = mod["mask"]["off"]
        self._o_cap        = mod["cap"]["off"]
        self._o_sub        = mod["sub"]["off"]

        self.observation_space = Box(
            low=np.full(self._obs_total, np.finfo("f").min, dtype=np.float32),
            high=np.full(self._obs_total, np.finfo("f").max, dtype=np.float32),
            dtype=np.float32,
        )
        self.action_space = Box(
            low=np.full(self._n_act, -1.0, dtype=np.float32),
            high=np.full(self._n_act, 1.0, dtype=np.float32),
            dtype=np.float32,
        )

    def _build_scene(self) -> None:
        """Bodies, buffers, scene, finalize -- the sequence `_rebuild` already used, which is why
        the two-phase seam was safe to declare (D7). Shared by setup and every rebuild."""
        self.groups = []
        self.create_envs()
        self.allocate_buffers()
        self.create_scene()
        self.gym.set_num_solver_iterations(8)
        self.gym.finalize()

        # Compile the jit helpers. Attribute checker stops for vectorized envs from recompiling each instance.
        if not hasattr(self.reward_term_trunc_helper, "_jit_compiled"):
            self.reward_term_trunc_helper._jit_compiled = torch.jit.script(self.reward_term_trunc_helper)
        self.reward_term_trunc_helper_jit = staticmethod(self.reward_term_trunc_helper._jit_compiled)

        if not hasattr(self.obs_helper, "_jit_compiled"):
            self.obs_helper._jit_compiled = torch.jit.script(self.obs_helper)
        self.obs_helper_jit = staticmethod(self.obs_helper._jit_compiled)

        if not hasattr(self.reset_helper, "_jit_compiled"):
            self.reset_helper._jit_compiled = torch.jit.script(self.reset_helper)
        self.reset_helper_jit = staticmethod(self.reset_helper._jit_compiled)

        if self.rendering:
            epm = self.envs_per_morph
            cols = max(1, ceil(epm ** 0.5))
            rows = max(1, ceil(epm / cols))
            sx = (cols + 2) * self.spacing
            sz = (rows + 2) * self.spacing
            n_gc = max(1, ceil(len(self._morphologies) ** 0.5))
            s = n_gc * max(sx, sz) * 0.5
            self.gym_render.reset_camera(v.Vec3(s, 2 * s, s), v.Vec3(1e-5, -1, 0))

    def create_envs(self):
        up_axis     = v.Vec3(0, 1, 0)
        rot0        = v.shortest_rotation(v.Vec3(0, 0, 1), up_axis)
        init_tf     = v.Transform(rot0, self.spawn_height * up_axis)

        epm          = self.envs_per_morph
        cols         = max(1, ceil(epm ** 0.5))
        rows_per_grp = max(1, ceil(epm / cols))
        stride_x     = (cols + _SET_GAP_CELLS) * self.spacing
        stride_z     = (rows_per_grp + _SET_GAP_CELLS) * self.spacing
        n_grp_cols   = max(1, ceil(len(self._morphologies) ** 0.5))

        for gi, morph in enumerate(self._morphologies):
            # The library emits through a BodyEmitter, so the record -- not the shape of a name --
            # is what tells us which module every DOF, link and sensor belongs to.
            record  = self.module_library.construct_robot(morph, root_axes=self.root_axes)
            tmpfile = write_vsim(record.xml, gi)

            name           = f"morph_{gi}"
            env_def_handle = self.gym.create_environment_def(name)
            env_def        = self.gym.get_environment_def(env_def_handle)
            # fixed=True pins the articulation's base link to its placement transform instead of
            # leaving it free-floating -- needed whenever the root is world-mounted (root_axes is
            # not None), whether or not any prismatic root-mount joints exist (root_axes=[]).
            env_def.import_definitions(str(tmpfile), fixed=self.root_axes is not None)

            arti_def_handle = env_def.get_articulation_def_handle_by_name(record.articulation)
            arti_handle     = env_def.create_articulation(arti_def_handle, init_tf, "robot")
            art_def         = env_def.get_articulation_def(arti_def_handle)
            art_def.enable_control_type(v.ArticulationControlType.MOTOR, True)

            # A task's Props (CONTEXT.md's glossary entry) must land here, not in create_scene: this
            # env def is finalized two lines down, and every group's is finalized by the time
            # create_scene runs at all (create_scene is for genuinely global state, like a ground
            # plane -- see its docstring). Default no-op; only tasks with props override it.
            self.create_props(env_def, gi, morph)

            env_def.finalize()

            group_offset = v.Vec3((gi % n_grp_cols) * stride_x, 0, (gi // n_grp_cols) * stride_z)
            env_group    = self.create_env_group(env_def_handle, epm, group_offset)

            # Canonical padded slot (32 limb slots + one per root axis) for a joint, by name. We
            # assume neither vsim's packed order nor any naming scheme: look the joint up in the
            # record, which the emitter keyed by (slot, depth) before any XML existed. -1 means no
            # emitter recorded it -- unreachable in a sane build, and left unmapped and force-zeroed
            # rather than aliased onto a real slot (D10b).
            dof_key, root_key = record.dof_index(), record.root_dof_index()

            def canonical_slot(joint_name: str) -> int:
                if joint_name in dof_key:
                    s, d, _ = dof_key[joint_name]
                    return self._slot(s, d)
                if joint_name in root_key:
                    return self._n_dofs_full + root_key[joint_name]
                return -1

            # DOF scatter, in vsim's packed DOF order.
            n_dofs = art_def.get_num_joint_dof_defs()
            dof_names = [art_def.get_joint_dof_def_name(k) for k in range(n_dofs)]
            slots = [canonical_slot(nm) for nm in dof_names]
            unrecorded = [nm for nm, c in zip(dof_names, slots) if c < 0]
            if unrecorded:
                print(f"[emit] WARNING: morph_{gi} reports {len(unrecorded)} DOF(s) no emitter "
                      f"recorded: {unrecorded}. Left unactuated.", flush=True)
            dof_indices = torch.tensor(slots, dtype=torch.long, device=self.device)  # (n_dofs,)

            # Motor scatter, in vsim's MOTOR order -- which is not the DOF order. A motor-control
            # buffer is indexed by motor (`index_range` defaults to `[0, num_motors)`), and vsim
            # numbers motors in XML `<actuator>` declaration order while it reports DOFs in a
            # reverse-DFS of the joint tree (see BodyEmitter.build). Those agree for limb joints and
            # disagree the moment a root mount exists: the mount's motors are declared last but its
            # DOFs come first, so reusing `dof_indices` here fed every root-mounted task a rotated
            # action vector. Built from the motor's own `joint_name` instead, so the two orders
            # never have to coincide.
            n_motors = art_def.get_num_motor_defs()
            motor_joints = [art_def.get_motor_def(i).joint_name for i in range(n_motors)]
            motor_slots = [canonical_slot(nm) for nm in motor_joints]
            unrecorded = [nm for nm, c in zip(motor_joints, motor_slots) if c < 0]
            if unrecorded:
                print(f"[emit] WARNING: morph_{gi} has {len(unrecorded)} motor(s) on joints no "
                      f"emitter recorded: {unrecorded}. Held at zero torque.", flush=True)
            motor_indices = torch.tensor(motor_slots, dtype=torch.long, device=self.device)

            # Sensor scatter into the per-MODULE block (n_modules x 6 components), in the order vsim
            # reports sensors, which is the order the emitter declared them. A sensor lands on the
            # module the library placed it on; slots with no sensor stay zero and are told apart from
            # a zero reading by the `has_sensor` field.
            n_sensors = art_def.get_num_force_sensor_defs()
            if n_sensors != len(record.sensors):
                print(f"[emit] WARNING: morph_{gi} has {n_sensors} force sensors but the record "
                      f"holds {len(record.sensors)}; the extras map nowhere.", flush=True)
            sensor_indices = torch.tensor(
                [6 * self._slot(s.slot, s.depth) + j
                 for s in record.sensors[:n_sensors] for j in range(6)],
                dtype=torch.long, device=self.device,
            )  # (n_sensors * 6,)

            # DOF mask: 1 for active DOFs, 0 otherwise. Root-axis slots always land here too (every
            # group's articulation has the same root-mount joints), so they read back as always-1
            # with no special-casing.
            dof_mask = torch.zeros(self._n_dofs_ext, dtype=torch.float32, device=self.device)
            dof_mask[dof_indices[dof_indices >= 0]] = 1.0

            # The group's longest chain, as its per-module lengths proximal -> distal, from the
            # emitter's record. A Task's set_root_pose uses it to lift long-limbed bodies clear of
            # the ground at reset: how far the robot stands off the floor is library-dependent, so
            # it is derived here rather than taken as a constructor argument (D6). Lengths rather
            # than a module count, because "one module longer" is only a distance if they are all
            # the same size.
            chains = [[m.length for m in record.modules if m.slot == s]
                      for s in range(record.n_slots)]
            deepest = max(chains, key=sum)

            self.groups.append({
                "morph":           morph,
                "record":          record,
                "deepest_chain":   tuple(deepest),
                "reach":           sum(deepest),
                "n_dofs":          n_dofs,
                "n_motors":        n_motors,
                "env_group":       env_group,
                "art_def":         art_def,
                "arti_def_handle": arti_def_handle,
                "arti_handle":     arti_handle,
                "env_def_handle":  env_def_handle,
                "dof_indices":     dof_indices,
                "motor_indices":   motor_indices,
                "sensor_indices":  sensor_indices,
                "dof_mask":       dof_mask,
            })

    def allocate_buffers(self):
        super().allocate_buffers()
        N   = self.total_num_envs
        EPM = self.envs_per_morph

        # `_act_buf` is the CANONICAL action buffer -- one slot per padded DOF, root axes included,
        # passive ones too. The action *space* is narrower whenever a passive axis exists, so the
        # base class's action-space-shaped buffer is replaced here. Everything downstream (the
        # motor gather, the `act` observation block, the root block) indexes canonical slots, so
        # nothing else has to know the two widths differ.
        if self._n_act != self._n_dofs_ext:
            self._act_buf = torch.zeros((N, self._n_dofs_ext), dtype=torch.float32,
                                        device=self.device)
        # Canonical slots the incoming action's root-axis tail feeds, ascending. Empty (and unused)
        # when every axis is actuated, which is the only case the fast path in pre_physics_step runs.
        self._act_root_cols = torch.tensor(
            [self._n_dofs_full + i for i, ax in enumerate(self.root_axes or ()) if ax.actuated],
            dtype=torch.long, device=self.device)

        self.old_root_pos_buf = torch.zeros((N, 7), dtype=torch.float32, device=self.device)

        # Root pose/vel are uniform-width across morphologies, so they live in single global
        # tensors; each group's command is backed by a contiguous row-slice (a vsim command can
        # wrap a tensor view). Downstream obs/reward then read them whole-tensor.
        self._get_root_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._get_root_vel  = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        # Root reset is constant (init pose, no noise), so these set buffers are filled once here
        # and never touched in the step loop. _set_root_vel stays zero.
        self._set_root_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._set_root_vel  = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        # Per-env spawn-height lift (offset added to the reset Y for long-limbed bodies). Used to make
        # the healthy_y_range CEILING relative to standing height so taller ants aren't killed at spawn
        # (the floor stays absolute — see compute_reward_termination_truncation).
        self._height_offset = torch.zeros(N, dtype=torch.float32, device=self.device)
        # Extended canonical DOF width: 32 limb slots + one per configured root axis (always active,
        # no padding -- root_axes is fixed per env, unlike limb presence).
        self._global_dof_mask = torch.zeros((N, self._n_dofs_ext), dtype=torch.float32, device=self.device)
        # Per-env segment lengths, constant per body: [hip_leg1..8, ankle_leg1..8], 0 for inactive limbs.
        self._global_lengths = torch.zeros((N, self._n_dofs_full), dtype=torch.float32, device=self.device)
        # Phase-5 per-module type ids, also constant per body (see self._o_cap / self._o_sub).
        self._global_is_cap = torch.zeros((N, self._n_dofs_full), dtype=torch.float32, device=self.device)
        self._global_sub_oh = torch.zeros((N, self._n_dofs_full * self._n_sub), dtype=torch.float32,
                                          device=self.device)
        # Which slots the library put a sensor on -- constant per body, and the only thing separating
        # "no sensor here" from "a sensor reading zero" (see the `has_sensor` field).
        self._global_has_sensor = torch.zeros((N, self._n_dofs_full), dtype=torch.float32,
                                              device=self.device)

        # DOF/sensor data is ragged (per-morphology width + a per-morphology slot permutation), so
        # it can't share a rectangular tensor. Each quantity gets ONE flat buffer holding every
        # group's data end-to-end; each group's command wraps a reshaped contiguous slice of it.
        # Precomputed indices map flat <-> padded obs slots so the per-step scatter/gather is one
        # whole-tensor op:
        #   _dof_gather_idx[e,c] : flat index feeding canonical DOF slot c of env e (inactive slots
        #                          gather index 0 and are zeroed by _global_dof_mask; serves pos+vel)
        #   _motor_src_idx[p]    : index into act.view(-1) feeding flat-MOTOR slot p
        #   _sensor_gather_idx / _sensor_mask : the same for the 48 force-sensor slots
        # The motor buffer gets its own offsets rather than sharing the DOF ones: it is indexed by
        # motor, and a passive root axis is a DOF with no motor, so the two counts differ.
        n_sensors_per = [g["art_def"].get_num_force_sensor_defs() for g in self.groups]
        n_links_per   = [g["art_def"].get_num_link_defs() for g in self.groups]  # 1 root + 1/module
        dof_off, mot_off, sen_off, link_off, d, m, s, L = [], [], [], [], 0, 0, 0, 0
        for gi, g in enumerate(self.groups):
            dof_off.append(d); d += EPM * g["n_dofs"]
            mot_off.append(m); m += EPM * g["n_motors"]
            sen_off.append(s); s += EPM * n_sensors_per[gi] * 6
            link_off.append(L); L += EPM * n_links_per[gi]   # in ROWS (1 row = one link's pose/vel)
        FLAT_DOF, FLAT_MOT, FLAT_SEN, FLAT_LINK = d, m, s, L

        self._flat_get_dof_pos = torch.zeros(FLAT_DOF, dtype=torch.float32, device=self.device)
        self._flat_get_dof_vel = torch.zeros(FLAT_DOF, dtype=torch.float32, device=self.device)
        self._flat_set_dof_pos = torch.zeros(FLAT_DOF, dtype=torch.float32, device=self.device)
        self._flat_set_dof_vel = torch.zeros(FLAT_DOF, dtype=torch.float32, device=self.device)
        self._flat_motor       = torch.zeros(FLAT_MOT, dtype=torch.float32, device=self.device)
        self._flat_dof_init    = torch.zeros(FLAT_DOF, dtype=torch.float32, device=self.device)
        self._flat_sensor      = torch.zeros(FLAT_SEN, dtype=torch.float32, device=self.device)
        self._has_sensors      = FLAT_SEN > 0
        # Per-link pose (7 = quat xyzw + pos xyz) / velocity (6 = ang xyz + lin xyz) in ENV frame, one
        # ROW per (env, link), groups concatenated. Feeds the relative-to-parent geometry obs (2a).
        self._flat_get_link_pose = torch.zeros(FLAT_LINK * 7, dtype=torch.float32, device=self.device)
        self._flat_get_link_vel  = torch.zeros(FLAT_LINK * 6, dtype=torch.float32, device=self.device)

        self._dof_gather_idx    = torch.zeros((N, self._n_dofs_ext), dtype=torch.long, device=self.device)
        # True where canonical slot c of env e is backed by a real packed DOF. `_global_dof_mask` is
        # nearly this but not exactly -- it comes off the library's mask, while the gather index is
        # keyed on whether the record named that DOF -- and restoring state must write back through
        # exactly the slots the gather read, so it gets its own flag rather than reusing the mask.
        self._dof_active        = torch.zeros((N, self._n_dofs_ext), dtype=torch.bool, device=self.device)
        self._motor_src_idx     = torch.zeros(FLAT_MOT, dtype=torch.long, device=self.device)
        self._sensor_gather_idx = torch.zeros((N, self._n_sensor), dtype=torch.long, device=self.device)
        self._sensor_mask       = torch.zeros((N, self._n_sensor), dtype=torch.float32, device=self.device)
        # Canonical module slot -> flat link ROW for the module's own link (_link_gather_idx) and its
        # PARENT link (_parent_gather_idx; parent of depth-1 = root). Inactive slots gather row 0 and
        # are zeroed by _global_dof_mask. gather via _flat_get_link_pose.view(-1,7)[idx].
        self._link_gather_idx   = torch.zeros((N, self._n_dofs_full), dtype=torch.long, device=self.device)
        self._parent_gather_idx = torch.zeros((N, self._n_dofs_full), dtype=torch.long, device=self.device)

        all_motor_cmds, all_sensor_cmds, all_get_cmds, all_set_cmds, all_get_link_cmds = [], [], [], [], []
        motor_zero = []          # flat-motor positions fed by no canonical slot (unrecorded DOFs)
        ar_epm = torch.arange(EPM, device=self.device)
        zero_l = torch.zeros((), dtype=torch.long, device=self.device)

        def chunk(flat, off, w):
            return flat[off:off + EPM * w].view(EPM, w)

        for gi, g in enumerate(self.groups):
            start = gi * EPM
            end   = start + EPM
            n_dofs = g["n_dofs"]
            n_motors = g["n_motors"]
            doff = dof_off[gi]
            moff = mot_off[gi]

            # Initial conditions
            dof_pos_init, root_trans_init, _ = store_initial_conditions_helper(
                g["art_def"], self.device
            )
            g["dof_pos_init"] = torch.tile(dof_pos_init, (EPM, 1))  # (EPM, n_dofs)
            g["dof_vel_init"] = torch.zeros_like(g["dof_pos_init"])

            self._set_root_pose[start:end] = torch.tensor(
                [root_trans_init.q.x, root_trans_init.q.y,
                 root_trans_init.q.z, root_trans_init.q.w,
                 root_trans_init.p.x, root_trans_init.p.y,
                 root_trans_init.p.z],
                dtype=torch.float32, device=self.device,
            )

            self.set_root_pose(g, start, end)
            self._global_dof_mask[start:end] = g["dof_mask"]

            # Constant-per-body obs blocks, straight off the record: every module is there, the
            # non-physical ones (a bare cap emits no link) included, so nothing has to be inferred
            # a second time from the morphology.
            record = g["record"]
            lvec = torch.zeros(self._n_dofs_full, dtype=torch.float32, device=self.device)
            capvec = torch.zeros(self._n_dofs_full, dtype=torch.float32, device=self.device)
            subvec = torch.zeros((self._n_dofs_full, self._n_sub), dtype=torch.float32, device=self.device)
            senvec = torch.zeros(self._n_dofs_full, dtype=torch.float32, device=self.device)
            for m in record.modules:
                c = self._slot(m.slot, m.depth)
                lvec[c] = m.length
                subvec[c, m.subtype] = 1.0
                if m.type is ModuleType.CAP:
                    capvec[c] = 1.0
            for s in record.sensors:
                senvec[self._slot(s.slot, s.depth)] = 1.0
            self._global_lengths[start:end] = lvec
            self._global_is_cap[start:end] = capvec
            self._global_sub_oh[start:end] = subvec.reshape(-1)
            self._global_has_sensor[start:end] = senvec

            self._flat_dof_init[doff:doff + EPM * n_dofs] = g["dof_pos_init"].reshape(-1)

            # Commands aliased to reshaped flat slices (root buffers stay global row-slices).
            all_motor_cmds.append(g["env_group"].create_motor_control_command(
                v.wrap_gpu_buffer(chunk(self._flat_motor, moff, n_motors)), g["arti_handle"]
            ))
            all_get_cmds.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(chunk(self._flat_get_dof_pos, doff, n_dofs)),
                v.wrap_gpu_buffer(chunk(self._flat_get_dof_vel, doff, n_dofs)),
                v.wrap_gpu_buffer(self._get_root_pose[start:end]),
                v.wrap_gpu_buffer(self._get_root_vel[start:end]),
                g["arti_handle"], link_index_range=(0, 1),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            # Separate ALL-link GET for the relative-geometry obs (root path above stays untouched).
            # dof buffers are required args but re-fetch the same values (harmless); we only read the
            # link pose/vel slices. Rows [lo : lo+EPM*n_links) of the flat link buffers.
            nl = n_links_per[gi]
            lo = link_off[gi]
            # Kept for anything that needs to address the ragged flat link buffers by (env, link)
            # rather than by canonical module slot -- link_external_force_index, chiefly.
            g["n_links"], g["link_off"] = nl, lo
            all_get_link_cmds.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(chunk(self._flat_get_dof_pos, doff, n_dofs)),
                v.wrap_gpu_buffer(chunk(self._flat_get_dof_vel, doff, n_dofs)),
                v.wrap_gpu_buffer(self._flat_get_link_pose[lo * 7:(lo + EPM * nl) * 7].view(EPM, nl * 7)),
                v.wrap_gpu_buffer(self._flat_get_link_vel[lo * 6:(lo + EPM * nl) * 6].view(EPM, nl * 6)),
                g["arti_handle"], link_index_range=(0, nl),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            all_set_cmds.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(chunk(self._flat_set_dof_pos, doff, n_dofs)),
                v.wrap_gpu_buffer(chunk(self._flat_set_dof_vel, doff, n_dofs)),
                v.wrap_gpu_buffer(self._set_root_pose[start:end]),
                v.wrap_gpu_buffer(self._set_root_vel[start:end]),
                g["arti_handle"], link_index_range=(0, 1),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
                masks_buffer=v.wrap_gpu_buffer(self._reset_buf[start:end]),
            ))

            # DOF gather index (canonical slot -> flat DOF).
            dof_idx = g["dof_indices"]                       # (n_dofs,) canonical slot per packed k
            keep = dof_idx >= 0                              # -1 == recorded by nobody, see above
            col_k = torch.full((self._n_dofs_ext,), -1, dtype=torch.long, device=self.device)
            packed = torch.arange(n_dofs, device=self.device)
            col_k[dof_idx[keep]] = packed[keep]               # canonical -> packed k (-1 if absent)
            self._dof_gather_idx[start:end] = torch.where(
                (col_k >= 0).unsqueeze(0),
                doff + ar_epm.unsqueeze(1) * n_dofs + col_k.clamp(min=0).unsqueeze(0),
                zero_l,
            )
            self._dof_active[start:end] = (col_k >= 0).unsqueeze(0)

            # Motor source index (flat MOTOR -> act), over the motor order, not the DOF order.
            mot_idx = g["motor_indices"]                     # (n_motors,) canonical slot per motor i
            mot_keep = mot_idx >= 0
            motor_block = ((start + ar_epm).unsqueeze(1) * self._n_dofs_ext
                           + mot_idx.clamp(min=0).unsqueeze(0))
            self._motor_src_idx[moff:moff + EPM * n_motors] = motor_block.reshape(-1)
            if not bool(mot_keep.all()):
                motor_zero.append(
                    (moff + ar_epm.unsqueeze(1) * n_motors
                     + (~mot_keep).nonzero().flatten().unsqueeze(0)).reshape(-1))

            # Link gather (canonical module slot -> flat link ROW) + parent-link gather. Both come
            # off the record: it names each module's own link and its parent's, so the root link and
            # the root-mount chain need no special case. Caps are skipped -- a cap rides a FIXED
            # joint, so its pose is constant, and every rel-* block is masked by the DOF mask, which
            # is 0 at a cap slot.
            names  = [g["art_def"].get_link_def_name(k) for k in range(nl)]
            name_k = {nm: k for k, nm in enumerate(names)}
            root_k = name_k[record.root_link]
            slot_to_k = torch.full((self._n_dofs_full,), -1, dtype=torch.long, device=self.device)
            parent_k  = torch.full((self._n_dofs_full,), root_k, dtype=torch.long, device=self.device)
            for m in record.modules:
                if not m.emitted or m.type is ModuleType.CAP:
                    continue
                c = self._slot(m.slot, m.depth)
                slot_to_k[c] = name_k[m.link]
                parent_k[c]  = name_k[m.parent_link]
            active_c   = (slot_to_k >= 0).unsqueeze(0)
            child_row  = lo + ar_epm.unsqueeze(1) * nl + slot_to_k.clamp(min=0).unsqueeze(0)  # (EPM, n_dof)
            parent_row = lo + ar_epm.unsqueeze(1) * nl + parent_k.unsqueeze(0)
            self._link_gather_idx[start:end]   = torch.where(active_c, child_row,  zero_l)
            self._parent_gather_idx[start:end] = torch.where(active_c, parent_row, zero_l)

            # Force-sensor commands (one per sensor) + sensor gather index.
            env_def      = self.gym.get_environment_def(g["env_def_handle"])
            articulation = env_def.get_articulation(g["arti_handle"])
            soff = sen_off[gi]
            for si in range(n_sensors_per[gi]):
                sensor_handle = articulation.get_force_sensor_handle(si)
                all_sensor_cmds.append(g["env_group"].create_force_sensor_command(
                    v.wrap_gpu_buffer(chunk(self._flat_sensor, soff + si * EPM * 6, 6)), sensor_handle
                ))
            g["n_sensors"] = n_sensors_per[gi]
            sen_idx = g["sensor_indices"]              # (n_sensors*6,) canonical module slot per (si,comp)
            base_sen = torch.full((self._n_sensor,), -1, dtype=torch.long, device=self.device)
            p = torch.arange(sen_idx.numel(), device=self.device)
            base_sen[sen_idx] = (p // 6) * (EPM * 6) + (p % 6)  # canonical slot -> within-group flat base
            self._sensor_mask[start:end] = (base_sen >= 0).float().unsqueeze(0)
            self._sensor_gather_idx[start:end] = torch.where(
                (base_sen >= 0).unsqueeze(0),
                soff + base_sen.clamp(min=0).unsqueeze(0) + ar_epm.unsqueeze(1) * 6,
                zero_l,
            )

        # Constant length + dof_mask + type + sensor-placement blocks in obs; whole-tensor, set once.
        # The reported DOF mask feature is limb-only: root-axis slots aren't modules, so
        # they're excluded here even though _global_dof_mask itself is extended for gather/motor use.
        D = self._n_dofs_full
        self._obs_buf[:, self._o_length:self._o_length + D]         = self._global_lengths
        self._obs_buf[:, self._o_mask:self._o_mask + D]             = self._global_dof_mask[:, :D]
        self._obs_buf[:, self._o_cap:self._o_cap + D]               = self._global_is_cap
        self._obs_buf[:, self._o_sub:self._o_sub + self._n_sub * D] = self._global_sub_oh
        self._obs_buf[:, self._o_has_sensor:self._o_has_sensor + D] = self._global_has_sensor

        # Motors on unrecorded joints alias onto canonical slot 0 in _motor_src_idx (a gather needs
        # some index); this forces their torque back to zero. Empty in every sane build, so the step
        # loop skips it.
        self._motor_zero_idx = torch.cat(motor_zero) if motor_zero else None

        # The root pose the task mounted the robot at, kept because `restore_state` writes the live
        # robot's pose into the same `_set_root_pose` the reset path uses -- without a copy of the
        # spawn pose, one rewind would silently redefine where every later reset puts the robot.
        self._root_pose_init = self._set_root_pose.clone()

        # Scatter plan for `restore_state`: the flat-DOF destinations of every ACTIVE canonical slot,
        # paired with the (env, slot) they come from. Only active slots appear, so the inactive ones
        # -- which all gather flat index 0 -- can't collide on a write the way a dense scatter would.
        env_i, col_i = self._dof_active.nonzero(as_tuple=True)
        self._dof_restore_flat = self._dof_gather_idx[env_i, col_i]
        self._dof_restore_env, self._dof_restore_col = env_i, col_i

        # Batch commands across all groups into single GPU arrays.
        self.all_motor_cmd_array  = self.gym.create_gpu_array(all_motor_cmds)
        self._get_cmd_array       = self.gym.create_gpu_array(all_get_cmds)
        self._get_link_cmd_array  = self.gym.create_gpu_array(all_get_link_cmds)
        self._set_cmd_array       = self.gym.create_gpu_array(all_set_cmds)
        self.all_sensor_cmd_array = self.gym.create_gpu_array(all_sensor_cmds) \
            if all_sensor_cmds else None

    def pre_physics_step(self, actions: torch.Tensor):
        # Snapshot root pose before physics (used by reward), mask inactive joints, and gather
        # active DOFs into the flat motor buffer via one precomputed index.
        self.old_root_pos_buf[:] = self._get_root_pose
        if self._n_act == self._n_dofs_ext:
            self._act_buf[:] = actions * self._global_dof_mask
        else:
            # Passive root axes: the action's tail covers only the actuated ones, so it is scattered
            # onto their canonical slots and every other root slot stays zero. The limb block is a
            # prefix in both widths, so it copies straight across.
            D = self._n_dofs_full
            self._act_buf[:, :D] = actions[:, :D]
            self._act_buf[:, D:] = 0.0
            self._act_buf[:, self._act_root_cols] = actions[:, D:]
            self._act_buf *= self._global_dof_mask
        self._flat_motor[:] = self._act_buf.reshape(-1)[self._motor_src_idx]
        if self._motor_zero_idx is not None:
            self._flat_motor[self._motor_zero_idx] = 0.0
        self.gym.set_motor_forces(self.all_motor_cmd_array)

    def post_physics_step(self):
        self._progress_buf += 1
        self._reset_buf[:]      = self._next_term_buf | self._next_trunc_buf
        self._term_buf[:]       = self._next_term_buf
        self._trunc_buf[:]      = self._next_trunc_buf
        if self.auto_reset:
            self.reset_idx()
        self.compute_observations()
        self.compute_reward_termination_truncation()

    def obs_fields(self) -> dict:
        """The standard observation, declared. A Task extends this dict; see `Task.obs_fields`.

        Declaration order is placement order within each region, so the standard blocks keep their
        relative order and a task's own fields land after them.
        """
        return {
            # ---- global: the robot's root state, one instance per env ----------------------
            "root_height":   GlobalField(1),                   # height along the up axis
            "root_rot6d":    GlobalField(6),                   # first two columns of R
            "root_linvel":   GlobalField(3),
            "root_angvel":   GlobalField(3),
            # Root mount: position, velocity and last action per configured axis. EVERY axis is
            # observed, including passive ones a policy cannot command -- a planar task should see
            # the height it is falling through. Width 0 on a free-floating robot, which leaves the
            # field describable rather than absent.
            "root_axis_pos": GlobalField(self._n_root_axes),
            "root_axis_vel": GlobalField(self._n_root_axes),
            "root_axis_act": GlobalField(self._n_root_axes),
            # ---- module: one instance per padded slot, depth-major -------------------------
            "sin":        ModuleField(1),                      # joint angle, split to stay continuous
            "cos":        ModuleField(1),
            "vel":        ModuleField(1),
            "act":        ModuleField(1),                      # last action driving this slot
            "relpos":     ModuleField(3),                      # pose/motion relative to the parent
            "relrot":     ModuleField(6),
            "relvel":     ModuleField(6),
            "sensor":     ModuleField(_SENSOR_COMPS),          # force reading, where one is placed
            # Constant per body, but a measurement rather than a {0,1} channel read with a threshold,
            # so it normalizes like any other physical quantity. Declared BEFORE the structural run
            # below deliberately: a consumer that restores unnormalized values wants them in one
            # slice, so structural fields are kept adjacent rather than interleaved with measured
            # ones. Nothing enforces that here -- the algorithm side checks it and refuses.
            "length":     ModuleField(1),
            # TEMPORARY. Which slots carry a sensor is a property of the module and belongs in the
            # module attributes once those exist; it is published here because a consumer otherwise
            # cannot tell "no sensor" from "sensor reading zero" -- both are six zeros -- and any
            # mask built over the sensor block would be a guess.
            "has_sensor": ModuleField(1, structural=True),
            "mask":       ModuleField(1, structural=True),     # slot holds an active effector (a DOF)
            "cap":        ModuleField(1, structural=True),     # slot holds a cap
            "sub":        ModuleField(self._n_sub, structural=True),   # subtype one-hot
        }

    def obs_width(self) -> int:
        """Total observation width, read at setup to size the buffer and the space.

        Derived from `obs_fields` -- declare a field to widen the observation; never override this.
        """
        return self._obs_total

    def obs(self, name: str) -> torch.Tensor:
        """A writable view of one declared field, for `compute_observations` to fill.

        `(num_envs, dim)` for a global field and `(num_envs, n_modules, dim)` for a module field, in
        depth-major slot order. A view, not a copy: assign into it with `[:]` or an index, and the
        observation buffer is what changes.

        Addressing a field by name is what keeps the write and the published offset from drifting --
        they are now the same number, read from the same resolution, instead of two hand-computed
        ones that agreed until someone inserted a field.
        """
        entry = self._obs_groups[obs_spec.GLOBAL].get(name)
        if entry is not None:
            return self._obs_buf[:, entry["off"]:entry["off"] + entry["dim"]]
        entry = self._obs_groups[obs_spec.MODULE].get(name)
        if entry is not None:
            width = entry["dim"] * self._n_dofs_full
            return (self._obs_buf[:, entry["off"]:entry["off"] + width]
                    .view(-1, self._n_dofs_full, entry["dim"]))
        raise KeyError(
            f"{name!r} is not a declared observation field; declare it in obs_fields first "
            f"(have: {sorted(self._obs_groups[obs_spec.GLOBAL]) + sorted(self._obs_groups[obs_spec.MODULE])})")

    def compute_observations(self):
        self.gym.get_articulation_kinematic_states(self._get_cmd_array)       # root pose/vel
        self.gym.get_articulation_kinematic_states(self._get_link_cmd_array)  # all-link pose/vel
        if self.all_sensor_cmd_array is not None:
            self.gym.get_sensor_forces(self.all_sensor_cmd_array)

        self.obs_helper_jit(
            self._obs_buf, self._act_buf,
            self._get_root_pose, self._get_root_vel,
            self._flat_get_dof_pos, self._flat_get_dof_vel,
            self._flat_get_link_pose, self._flat_get_link_vel,
            self._flat_sensor, self._has_sensors,
            self._dof_gather_idx, self._link_gather_idx,
            self._parent_gather_idx, self._sensor_gather_idx,
            self._global_dof_mask, self._sensor_mask,
            self._n_dofs_full, self._n_root_axes,
            self._o_root, self._o_root_axes, self._o_sin, self._o_cos, self._o_vel, self._o_act,
            self._o_relpos, self._o_relrot, self._o_relvel, self._o_sensor, self._o_sensor_end,
        )

    def enable_link_external_forces(self):
        """Allocate a per-link external-force buffer and return it, shaped `(num_envs, n_links, 6)`.

        Idempotent, and **opt-in**: a task that never calls this pays nothing, since the commands
        are only created and only dispatched when the buffer exists. Call from `allocate_buffers`
        after `super()`, then write the buffer each step and call `apply_link_external_forces`.

        Forces are in each link's **own** frame (`FrameType.LOCAL`) and laid out `[torque xyz, force
        xyz]` per link, matching the ang-then-lin order vsim already reports link velocities in.
        Groups are ragged in link count, so the rows are padded to the widest group; the extra rows
        of a narrower group are simply never dispatched.
        """
        if getattr(self, "_link_force_buf", None) is not None:
            return self._link_force_buf

        n_links = [g["art_def"].get_num_link_defs() for g in self.groups]
        self._max_links = max(n_links)
        self._link_force_buf = torch.zeros(
            (self.total_num_envs, self._max_links, 6), dtype=torch.float32, device=self.device)

        cmds = []
        for gi, g in enumerate(self.groups):
            start = gi * self.envs_per_morph
            end = start + self.envs_per_morph
            rows = self._link_force_buf[start:end, :n_links[gi], :].contiguous()
            self._link_force_views.append((slice(start, end), n_links[gi], rows))
            cmds.append(g["env_group"].create_link_external_force_command(
                v.wrap_gpu_buffer(rows), g["arti_handle"], index_range=(0, n_links[gi]),
                frame_type=v.FrameType.LOCAL, force_type=v.ForceType.FORCE_TORQUE))
        self._link_force_cmds = self.gym.create_gpu_array(cmds)
        return self._link_force_buf

    def apply_link_external_forces(self):
        """Push whatever is in the external-force buffer into the simulation. No-op if unused."""
        if getattr(self, "_link_force_cmds", None) is None:
            return
        # `create_link_external_force_command` needs a contiguous per-group buffer, so each group's
        # rows are a separate tensor rather than a view; copy the padded buffer into them.
        for sl, nl, rows in self._link_force_views:
            rows.copy_(self._link_force_buf[sl, :nl, :])
        self.gym.set_link_external_forces(self._link_force_cmds)

    def link_external_force_index(self, body_only: bool = True):
        """`(rows, mask)` addressing every link of every env in the ragged flat link buffers.

        `rows` is `(num_envs, max_links)` of row indices into `_flat_get_link_pose.view(-1, 7)` and
        `_flat_get_link_vel.view(-1, 6)`; `mask` is `(num_envs, max_links, 1)`, zero where a link
        should take no force. Padded rows index row 0 and are masked, the same convention the DOF
        and sensor gathers already use.

        `body_only` (the default) masks out the **root-mount chain**. Those links exist to carry the
        mount's DOFs and represent no physical part -- they have no collision geometry for exactly
        that reason. They do have mass and inertia, though, so anything deriving a force from those
        (a fluid model, chiefly) would apply it to three phantom bodies riding at the root, damping
        precisely the root motion such a task is usually scoring. The record names them, so they can
        be excluded rather than left to a name check at the call site.
        """
        width = max(g["n_links"] for g in self.groups)
        rows = torch.zeros((self.total_num_envs, width), dtype=torch.long, device=self.device)
        mask = torch.zeros((self.total_num_envs, width, 1), dtype=torch.float32,
                           device=self.device)
        ar = torch.arange(self.envs_per_morph, device=self.device).unsqueeze(1)
        for gi, g in enumerate(self.groups):
            start, end = gi * self.envs_per_morph, (gi + 1) * self.envs_per_morph
            nl, lo = g["n_links"], g["link_off"]
            k = torch.arange(nl, device=self.device).unsqueeze(0)
            rows[start:end, :nl] = lo + ar * nl + k

            record = g["record"]
            body = {record.root_link} | {m.link for m in record.modules if m.emitted}
            for j in range(nl):
                name = g["art_def"].get_link_def_name(j)
                if not body_only or name in body:
                    mask[start:end, j, 0] = 1.0
        return rows, mask

    def link_inertia_boxes(self):
        """Per-link `(mass, box, inertia)` -- `(num_envs, n_links)` and two `(num_envs, n_links, 3)`,
        padded to the widest group and zero where a group is narrower.

        `box` is the equivalent-inertia-box side lengths; `inertia` is the link's own diagonal
        inertia, which a caller needs to bound an applied torque by the angular momentum available.

        Constant per body, so this is computed once per rebuild rather than per step. The box is
        MuJoCo's: the box of uniform density with the same mass and the same diagonal inertia as the
        link. It is what makes a fluid model possible without asking `ModuleLibrary` for anything --
        `ModuleDefinition.geometry` is opaque to this layer by design, but mass and inertia are not.
        """
        n_links = [g["art_def"].get_num_link_defs() for g in self.groups]
        width = max(n_links)
        mass = torch.zeros((self.total_num_envs, width), dtype=torch.float32, device=self.device)
        box = torch.zeros((self.total_num_envs, width, 3), dtype=torch.float32, device=self.device)
        diag = torch.zeros((self.total_num_envs, width, 3), dtype=torch.float32, device=self.device)
        for gi, g in enumerate(self.groups):
            start, end = gi * self.envs_per_morph, (gi + 1) * self.envs_per_morph
            for k in range(n_links[gi]):
                ld = g["art_def"].get_link_def(k)
                m = float(ld.mass)
                di = ld.diag_inertia
                inertia = [float(di.x), float(di.y), float(di.z)]
                mass[start:end, k] = m
                for j in range(3):
                    diag[start:end, k, j] = inertia[j]
                if m <= 0.0:
                    continue
                for j in range(3):
                    a, b = inertia[(j + 1) % 3], inertia[(j + 2) % 3]
                    box[start:end, k, j] = (max(1e-15, a + b - inertia[j]) / m * 6.0) ** 0.5
        return mass, box, diag

    def root_dof_state(self):
        """`(pos, vel)` of every root-mount axis, `(num_envs, n_root_axes)` each, in `root_axes`
        order -- passive axes included.

        The one thing a world-mounted Task cannot read any other way. With `root_axes` non-`None`
        the base link is welded to its placement (`import_definitions(..., fixed=True)`), so
        `_get_root_pose` never moves and the whole of the robot's gross motion lives in the mount
        chain instead. A positional axis reads as displacement from the spawn placement, since every
        mount joint starts at zero.

        Valid after `compute_observations` has run for the step; it reads the same fetched buffers.
        """
        idx = self._dof_gather_idx[:, self._n_dofs_full:]
        return self._flat_get_dof_pos[idx], self._flat_get_dof_vel[idx]

    def obs_layout(self) -> dict:
        """Which bytes of the observation mean what.

        The package owns this; the algorithm owns how bytes become tokens (D23). Published so
        nothing recomputes the layout on the far side of the boundary -- the same fact derived twice
        is the same fact wrong twice. Plain ints and tuples, so a checkpoint can carry it and an
        offline consumer can decode an observation with no live Task.

        The declaration of `obs_fields` with the offsets filled in, plus the counts a consumer needs
        to size anything off it. Every task's own fields are in here too, in whichever group they
        were declared -- there is no separate "the task's part", because which fields are whose is
        not a fact any reader needs. What a reader needs is where a field is and how it repeats.

        Two groups, each a contiguous region of the buffer:

          `global` -- one instance per env; `dim` is the field's whole width.
          `module` -- one instance per padded module slot, depth-major; `dim` is the width of ONE
                      instance, so the block spans `dim * n_modules`.

        Each entry is `{off, dim, structural}`. `structural` marks a field read exactly rather than
        measured, which an input normalizer must leave alone -- see `backend.obs_spec`.
        """
        return {
            "n_slots": self._n_limbs, "max_depth": self._max_len,
            "n_modules": self._n_dofs_full, "n_sub": self._n_sub,
            "n_root_axes": self._n_root_axes,
            # actuated axes only; the root observation above still covers every axis
            "n_root_actuated": self._n_root_actuated, "action_dim": self._n_act,
            "obs_total": self._obs_total,
            obs_spec.GLOBAL: dict(self._obs_groups[obs_spec.GLOBAL]),
            obs_spec.MODULE: dict(self._obs_groups[obs_spec.MODULE]),
        }

    def reset_idx(self):
        # Set buffers are filled for every env; each set command's reset_buf mask makes vsim apply
        # the write only to resetting envs, so no per-env gather or branch is needed. Root reset is
        # constant (the spawn pose snapshotted at allocate); only DOF gets fresh noise.
        self._set_root_pose[:] = self._root_pose_init
        self._set_root_vel.zero_()

        self.reset_helper_jit(
            self._reset_buf, self._act_buf,
            self._flat_set_dof_pos, self._flat_set_dof_vel,
            self._flat_dof_init, self._progress_buf,
            self.reset_noise_scale,
            self.dof_reset_pos_bias, self.dof_reset_pos_scale, 
            self.dof_reset_vel_bias, self.dof_reset_vel_scale
        )

        self.gym.set_articulation_kinematic_states(self._set_cmd_array)

        # Put the resetting envs' PREVIOUS root pose at the spawn too. `post_physics_step` resets
        # and THEN computes the reward, while `old_root_pos_buf` was snapshotted in
        # `pre_physics_step` from the pre-reset pose -- so without this the teleport back to spawn
        # is priced as motion. A velocity reward reading (root - old_root)/dt is charged
        # x_vel = (x_spawn - x_final)/dt on the terminal step, which EXACTLY cancels the episode's
        # accumulated forward reward (verified: sum of x_vel over an episode was 0.000000, and the
        # ant learns to stand still because locomotion is worth nothing). vlearn's own ant env does
        # the same rewrite in its reset path; it was dropped when the reward was vendored here.
        # Deliberately not in `state_fields`: the step loop overwrites this buffer before reading
        # it EXCEPT on a reset step, which is precisely the case handled here.
        self.old_root_pos_buf[:] = torch.where(self._reset_buf.unsqueeze(1),
                                               self._root_pose_init, self.old_root_pos_buf)

    def reset(self):
        self._reset_buf[:] = True
        self.reset_idx()
        self.gym.compute_kinematics()
        self.compute_observations()
        return self.obs_buf.clone(), {}

    # ------------------------------- Restorable state -------------------------------
    #
    # A **restorable state** (CONTEXT.md) is everything that has to travel with an env for the next
    # step to come out the same: the physics state, plus the cross-step buffers the reward and the
    # observation read. The physics half the backend handles itself, because it alone knows the
    # ragged flat DOF layout; the rest is declared field by field in `state_fields`, which a Task
    # extends the same way it extends `obs_fields`.
    #
    # Restore is a GATHER, not a copy: `restore_state(state, src)` fills env `e` from row `src[e]`
    # of the saved state. Rewinding is `src = arange`, and fanning one env's state out across a
    # whole morphology group is the same call with a constant `src` -- one op, not two code paths.

    def state_fields(self) -> dict:
        """Name -> the live per-env buffer that must be saved and restored with the physics state.

        Every tensor's first dimension is the env, so `save_state`/`restore_state` can index them
        uniformly. Extend from a Task with `{**super().state_fields(), "target": self._target}` for
        anything the task carries across steps -- a target that only re-randomizes on reset, a
        contact counter, a phase. Anything the step loop overwrites before reading (`_act_buf` at
        `pre_physics_step`, `old_root_pos_buf` right beside it) does NOT belong here.

        Getting this wrong fails silently: physics rewinds correctly and the task's own state does
        not, so a replayed rollout diverges slowly rather than crashing.
        """
        return {
            "progress":   self._progress_buf,
            "obs":        self._obs_buf,
            "rew":        self._rew_buf,
            "term":       self._term_buf,
            "next_term":  self._next_term_buf,
            "trunc":      self._trunc_buf,
            "next_trunc": self._next_trunc_buf,
            "reset":      self._reset_buf,
            # Last action, which the `act` observation block reports and a task may shape on.
            "act":        self._act_buf,
        }

    def save_state(self) -> dict:
        """Snapshot every env's restorable state. Rows are global env indices.

        DOF position and velocity are stored per CANONICAL slot, `(num_envs, n_dofs_ext)`, not in
        the ragged flat packing -- that is what makes a saved row indexable, so `restore_state` can
        gather it. Inactive slots hold junk and are never written back.

        A saved state is only valid against the scene it came from: `resample`/`resize` rebuild the
        articulations and invalidate it.
        """
        self.gym.get_articulation_kinematic_states(self._get_cmd_array)
        return {
            "root_pose": self._get_root_pose.clone(),
            "root_vel":  self._get_root_vel.clone(),
            "dof_pos":   self._flat_get_dof_pos[self._dof_gather_idx].clone(),
            "dof_vel":   self._flat_get_dof_vel[self._dof_gather_idx].clone(),
            **{k: t.clone() for k, t in self.state_fields().items()},
        }

    def restore_state(self, state: dict, src: torch.Tensor = None):
        """Put env `e` back into the state saved for env `src[e]` (`src=None` means env `e` itself).

        `src` is a `(num_envs,)` long tensor. It may repeat -- that is the fan-out case, one env's
        state copied across a whole morphology group -- but each entry must name an env of the SAME
        morphology as the env receiving it, since the two share a DOF layout and nothing else.
        """
        pose, vel = state["root_pose"], state["root_vel"]
        dof_pos, dof_vel = state["dof_pos"], state["dof_vel"]
        if src is not None:
            pose, vel = pose[src], vel[src]
            env_src = src[self._dof_restore_env]
        else:
            env_src = self._dof_restore_env

        self._set_root_pose[:] = pose
        self._set_root_vel[:]  = vel
        col = self._dof_restore_col
        self._flat_set_dof_pos[self._dof_restore_flat] = dof_pos[env_src, col]
        self._flat_set_dof_vel[self._dof_restore_flat] = dof_vel[env_src, col]

        # The set commands are masked by `_reset_buf`, so it has to read "every env" for the write
        # to land -- its saved value is put back below, with the other declared fields.
        self._reset_buf[:] = True
        self.gym.set_articulation_kinematic_states(self._set_cmd_array)
        self.gym.compute_kinematics()
        # Re-read, so the get buffers a subsequent step reads agree with what was just written.
        self.gym.get_articulation_kinematic_states(self._get_cmd_array)
        self.gym.get_articulation_kinematic_states(self._get_link_cmd_array)

        for name, buf in self.state_fields().items():
            saved = state[name]
            buf[:] = saved if src is None else saved[src]

    def _rebuild(self):
        # DRAIN all in-flight async work before delete_gym frees vsim's pinned host buffers.
        # A lingering async op referencing a just-freed buffer causes a rare rebuild-time
        # use-after-free: vsim "FATAL: Error deallocating pinned host memory". torch.cuda.synchronize()
        # alone is insufficient (vsim drives its own pipeline), so also drain vsim via a device
        # error-check. Cost ~0.2ms vs ~14s per rebuild. (end_streaming was dropped: we never
        # start_streaming, so it only hit vsim's "never started" early-return + printed a WARN.)
        torch.cuda.synchronize()
        for _fn in ("_check_for_cuda_errors",):
            try:
                getattr(self.gym, _fn)()
            except Exception as _e:
                print(f"[rebuild-drain] {_fn}() skipped: {_e!r}", flush=True)
        # Drop every gym-backed reference so delete_gym frees cleanly, then stand the scene back up
        # through the same path setup uses.
        self._get_cmd_array = self._set_cmd_array = self._get_link_cmd_array = None
        self.all_motor_cmd_array = self.all_sensor_cmd_array = None
        self._link_force_buf = self._link_force_cmds = None
        self._link_force_views = []
        self.groups = []
        self.env_groups = []
        self.gym = self.gym_render = None
        gc.collect()

        v.delete_gym()
        self._create_gym()          # contact buffers re-sized from the current env count
        self._build_scene()

    def follow_sets(self) -> list[list[int]]:
        EPM = self.envs_per_morph
        return [list(range(gi * EPM, (gi + 1) * EPM)) for gi in range(len(self.groups))]

    def follow_world_pos(self, idx: int) -> v.Vec3:
        EPM = self.envs_per_morph
        gi, i = idx // EPM, idx % EPM
        g = self.groups[gi]
        if "env_transforms" not in g:
            env_set = list(g["env_group"].get_environment_sets())[0]
            g["env_transforms"] = [
                env_set.get_environment(env_set.get_environment_handle(j)).get_transform()
                for j in range(EPM)
            ]
        p = self._get_root_pose[idx, 4:7]  # idx is the global env index
        local = v.Vec3(float(p[0]), float(p[1]), float(p[2]))
        return g["env_transforms"][i].transform(local)

    # ------------------------------------ JIT Helpers ------------------------------------
    
    @staticmethod
    def obs_helper(obs_buf: torch.Tensor, act_buf: torch.Tensor,
                   get_root_pose: torch.Tensor, get_root_vel: torch.Tensor,
                   get_dof_pos: torch.Tensor, get_dof_vel: torch.Tensor,
                   get_link_pose: torch.Tensor, get_link_vel: torch.Tensor,
                   get_sensor: torch.Tensor, has_sensors: bool,
                   dof_gather_idx: torch.Tensor, link_gather_idx: torch.Tensor,
                   parent_gather_idx: torch.Tensor, sensor_gather_idx: torch.Tensor,
                   global_dof_mask: torch.Tensor, sensor_mask: torch.Tensor,
                   n_dofs_full: int, n_root_axes: int,
                   o_root: int, o_root_axes: int, o_sin: int, o_cos: int, o_vel: int, o_act: int,
                   o_relpos: int, o_relrot: int, o_relvel: int, o_sensor: int, o_sensor_end: int,
        ):
        """Compute the full observation buffer from the vsim GET buffers. Must be JIT compilable (no
        Python control flow beyond a plain `if` on a scalar int, no object attributes) -- offsets are
        passed in as plain ints (not baked as compile-time defaults) since they vary per env instance
        (root_axes-dependent), while the compiled graph itself is identical for every instance."""
        m = global_dof_mask                                   # (N, n_dofs_ext) active mask; root-
        m_limb = m[:, :n_dofs_full]                            # axis columns (if any) are always 1
        # ── Root token: y + 6D rotation (first two cols of R) + lin/ang velocity (world frame) ──
        Rr = _quat_to_rotmat(get_root_pose[:, 0:4])           # (N,3,3)
        obs_buf[:, o_root:o_root + 1]       = get_root_pose[:, 5:6]      # y (up-axis)
        obs_buf[:, o_root + 1:o_root + 7]   = torch.cat([Rr[..., 0], Rr[..., 1]], dim=-1)  # rot6d
        obs_buf[:, o_root + 7:o_root + 10]  = get_root_vel[:, 3:6]       # linear velocity
        obs_buf[:, o_root + 10:o_root + 13] = get_root_vel[:, 0:3]       # angular velocity

        # ── Per-module DOF handle: joint sin/cos + velocity + last action (inactive slots -> 0) ──
        dof_pos = get_dof_pos[dof_gather_idx] * m               # (N, n_dofs_ext)
        dof_vel = get_dof_vel[dof_gather_idx] * m
        obs_buf[:, o_sin:o_cos] = torch.sin(dof_pos[:, :n_dofs_full]) * m_limb
        obs_buf[:, o_cos:o_vel] = torch.cos(dof_pos[:, :n_dofs_full]) * m_limb  # cos(0)=1 gated to 0
        obs_buf[:, o_vel:o_act] = dof_vel[:, :n_dofs_full]
        obs_buf[:, o_act:o_relpos] = act_buf[:, :n_dofs_full]     # last actions (already masked)

        # ── Root-axis extension: raw position/velocity/last-action per configured axis, the three
        # root_axis_* fields, declared adjacently and so written as one run from o_root_axes. ──
        if n_root_axes > 0:
            p0 = o_root_axes
            obs_buf[:, p0:p0 + n_root_axes]                       = dof_pos[:, n_dofs_full:]
            obs_buf[:, p0 + n_root_axes:p0 + 2 * n_root_axes]     = dof_vel[:, n_dofs_full:]
            obs_buf[:, p0 + 2 * n_root_axes:p0 + 3 * n_root_axes] = act_buf[:, n_dofs_full:]

        # ── Relative-to-parent geometry (parent-local frame), from the all-link pose/vel buffers ──
        lp = get_link_pose.view(-1, 7)                  # (FLAT_LINK, 7) [quat xyzw, pos]
        lv = get_link_vel.view(-1, 6)                   # (FLAT_LINK, 6) [ang, lin]
        Pc, Pp = lp[link_gather_idx], lp[parent_gather_idx]   # (N, n_dof, 7)
        Vc, Vp = lv[link_gather_idx], lv[parent_gather_idx]   # (N, n_dof, 6)
        Rc, Rp = _quat_to_rotmat(Pc[..., 0:4]), _quat_to_rotmat(Pp[..., 0:4])
        RpT = Rp.transpose(-1, -2)                                 # world -> parent frame
        pc, pp = Pc[..., 4:7], Pp[..., 4:7]
        wc, vc = Vc[..., 0:3], Vc[..., 3:6]
        wp, vp = Vp[..., 0:3], Vp[..., 3:6]
        rel_R = RpT @ Rc                                           # child orientation in parent frame
        rel_rot = torch.cat([rel_R[..., 0], rel_R[..., 1]], dim=-1)                  # 6D (N,n_dof,6)
        rel_pos = (RpT @ (pc - pp).unsqueeze(-1)).squeeze(-1)                        # (N,n_dof,3)
        rel_ang = (RpT @ (wc - wp).unsqueeze(-1)).squeeze(-1)                        # joint ang vel
        rel_lin = (RpT @ (vc - vp - torch.cross(wp, pc - pp, dim=-1)).unsqueeze(-1)).squeeze(-1)
        mm = m_limb.unsqueeze(-1)
        obs_buf[:, o_relpos:o_relrot] = (rel_pos * mm).reshape(obs_buf.shape[0], -1)       # slot-major
        obs_buf[:, o_relrot:o_relvel] = (rel_rot * mm).reshape(obs_buf.shape[0], -1)
        obs_buf[:, o_relvel:o_sensor] = (torch.cat([rel_lin, rel_ang], dim=-1) * mm).reshape(obs_buf.shape[0], -1)

        if has_sensors:
            obs_buf[:, o_sensor:o_sensor_end] = get_sensor[sensor_gather_idx] * sensor_mask
        else:
            obs_buf[:, o_sensor:o_sensor_end].zero_()

        # has_sensor | length | mask | cap | sub are constant per body: set once at allocate and
        # preserved here. A task's own fields are filled by the task, after this returns.

    @staticmethod
    def reset_helper(reset_buf: torch.Tensor, act_buf: torch.Tensor,
                     set_dof_pos: torch.Tensor, set_dof_vel: torch.Tensor,
                     dof_init: torch.Tensor, progress_buf: torch.Tensor, 
                     reset_noise_scale: float,
                     dof_reset_pos_bias: float, dof_reset_pos_scale: float, 
                     dof_reset_vel_bias: float, dof_reset_vel_scale: float
        ):
        """Reset the DOF and root state of all envs flagged in reset_buf. Must be JIT compilable (no Python control flow, no object attributes)."""
        s = reset_noise_scale
        set_dof_pos[:] = dof_init + s * (torch.rand_like(set_dof_pos) * dof_reset_pos_scale + dof_reset_pos_bias)
        set_dof_vel[:] = s * (torch.rand_like(set_dof_vel) * dof_reset_vel_scale + dof_reset_vel_bias)

        m = reset_buf.view(-1, 1)
        act_buf[:]      = torch.where(m, 0.0, act_buf)
        progress_buf[:] = torch.where(reset_buf, 0, progress_buf)
