"""What an observation is made of: named fields, each with a role, declared once and placed here.

A Task declares fields; the package derives everything else. Width is the sum of what was declared,
offsets are where declaration order puts them, and the published layout is the declaration with the
offsets filled in. Nothing hand-computes an offset, which is what used to make the observation three
hooks that had to be kept in step by hand (D11) -- a task that wrote its fields at one offset and
published another was reporting bytes nobody could read, and nothing said so.

**Role.** A field's group is its repeat unit, which is what tells a consumer where the value belongs:

  `GlobalField` -- one instance per env. The robot's root state, and whatever the objective needs
                   that a body does not carry: a handle's position, a target pose, a phase.
  `ModuleField` -- one instance per padded module slot, `dim` wide each, in depth-major slot order
                   (`slot(n, d) == d * n_slots + n`). Joint angles, contact readings, the DOF mask.

The buffer is laid out as one contiguous region per group -- every global field, then every module
field -- so a consumer that wants "the whole global block" takes one slice, and a policy reading a
body part reads one stride. Regions are contiguous by construction, not by convention.

**Structural.** A field is structural when its values are read *exactly* rather than measured: the
DOF mask, the is-cap flag, the subtype one-hot -- {0,1} channels that say what the body IS, constant
for as long as the body is. Physical readings (angles, velocities, forces) are not structural, no
matter how rarely they change.

An algorithm must leave structural fields out of any input normalization. `(x - mu) / sigma` on a
channel that is 1 in every env collapses it to ~0, and a consumer thresholding it at `> 0` then reads
a real module as padding -- wrong masks, wrong actions, no error anywhere. The same arithmetic turns
a one-hot into a smeared vector whose scale drifts with whichever bodies were recently sampled. The
failure is silent and it only appears once a channel becomes constant, so it hides until a morphology
distribution narrows. Label the field; do not make the consumer guess.
"""
from dataclasses import dataclass

GLOBAL = "global"
MODULE = "module"
GROUPS = (GLOBAL, MODULE)


@dataclass(frozen=True)
class ObsField:
    """One named block of the observation. `dim` is the width of a single instance -- the whole
    field is `dim` for a global field and `dim * n_modules` for a module field."""

    dim: int
    group: str
    structural: bool = False

    def __post_init__(self):
        if self.dim < 0:
            raise ValueError(f"field width must be >= 0, got {self.dim}")
        if self.group not in GROUPS:
            raise ValueError(f"unknown field group {self.group!r}; expected one of {GROUPS}")


def GlobalField(dim: int, structural: bool = False) -> ObsField:
    """One instance per env: root state, an objective's own scene fields."""
    return ObsField(dim=dim, group=GLOBAL, structural=structural)


def ModuleField(dim: int, structural: bool = False) -> ObsField:
    """`dim` values per padded module slot, depth-major. Named for the stride, not for the modlib
    `Module` -- this is a block of an observation, not a part of a body."""
    return ObsField(dim=dim, group=MODULE, structural=structural)


def resolve(fields: dict, n_modules: int) -> tuple:
    """Place declared fields into regions and return `(groups, total_width)`.

    `fields` is an ordered name -> ObsField mapping (declaration order is placement order, which is
    why the standard blocks and a task's own additions can share one hook). Returns the published
    form: one dict per group, each name -> `{off, dim, structural}`, where `off` is the start of the
    field's block and `dim` is still the per-instance width.

    Widths of 0 keep their entry. A task whose field is empty on some configuration -- a root-axis
    block on a free-floating robot -- stays describable rather than disappearing from the layout.
    """
    groups = {g: {} for g in GROUPS}
    off = 0
    for group in GROUPS:                                # global region first, then the module region
        stride = 1 if group == GLOBAL else n_modules
        for name, field in fields.items():
            if field.group != group:
                continue
            groups[group][name] = {"off": off, "dim": field.dim, "structural": field.structural}
            off += field.dim * stride
    return groups, off
