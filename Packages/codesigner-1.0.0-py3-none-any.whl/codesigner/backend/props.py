"""Prop assembly: the same link/joint XML primitives a ModuleLibrary builds a robot from
(build_vsim.py), composed into a standalone body a Task adds to its scene for the robot to act on --
a door, a hammer, a target ball (a **Prop**; see CONTEXT.md). No module/slot/depth grammar and no
canonical declaration order to preserve -- a prop is just links and joints, named and shaped by
whichever task builds it. See `interfaces.task.Task.create_props`.

A prop with no joints becomes a rigid body via `env_def.create_rigid_body`; a prop with one or more
joints becomes its own articulation via `env_def.create_articulation` -- same XML shape either way,
just how vlearn interprets the file it is imported from.
"""
from pathlib import Path
from typing import List, Optional, Tuple

from codesigner.backend.build_vsim import generated_dir, joint_xml, link_xml


class PropBuilder:
    """Construct with the prop's name, call `add_link`/`add_joint` any number of times, then
    `build()`. Unlike `BodyEmitter`, nothing here mints names -- the caller supplies every one, since
    a prop has no shared vocabulary another party needs to address it by."""

    def __init__(self, name: str):
        self.name = name
        self._links: List[str] = []
        self._joints: List[str] = []

    def add_link(self, name: str, density, collisions: List[str]) -> None:
        self._links.append(link_xml(name, density, collisions))

    def add_joint(self, name: str, joint_type: str, parent: str, child: str, origin: str,
                 rot: str = "0.0 0.0 0.0 1.0", axis: Optional[str] = None,
                 limits: Optional[Tuple[str, str]] = None, effort=None, velocity=None,
                 dynamics: Optional[str] = None) -> None:
        """A fixed joint (`joint_type='fixed'`, `axis=None`) welds two links rigidly; revolute or
        prismatic gives the prop a free, **unmotored** DOF -- a door swings on contact, it is not an
        actuator the policy drives. Pass `dynamics` for passive damping/friction/stiffness (hinge
        drag, a self-closing latch spring); there is deliberately no motor/gear here, unlike
        `BodyEmitter.set_module`, whose every DOF is policy-actuated.
        """
        self._joints.append(joint_xml(name, joint_type, parent, child, origin, rot=rot, axis=axis,
                                      limits=limits, effort=effort, velocity=velocity,
                                      dynamics=dynamics))

    def build(self) -> str:
        if not self._links:
            raise ValueError(f"prop {self.name!r} has no links")
        parts = [f'<robot name="{self.name}">']
        parts.extend(self._links)
        parts.extend(self._joints)
        parts.append('</robot>')
        return "\n".join(parts)


def write_prop_vsim(xml: str, name: str, index: int) -> Path:
    """Write an assembled prop's XML to a per-morph-group path in `generated_dir()`."""
    path = generated_dir() / f"{name}_prop_{index}.vsim"
    path.write_text(xml)
    return path
