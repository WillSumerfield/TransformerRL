"""Helpers vendored from vlearn's sample environments.

These live in `vlearn-main/train/envs/` in vlearn's source checkout -- its *sample* directory, which
is not part of the installed wheel. The code this backend came from reached them by inserting a
hardcoded sibling path onto `sys.path`, which cannot ship. See docs/decisions.md (D13).

Copied as-is; the only change is this docstring. Drop these if vlearn ever ships them properly.
"""
import numpy as np
import torch
import vlearn as v
from vlearn.constant import GLOBAL_ENV_DEF_HANDLE


def create_plane(
    gym,
    dynamic_friction=0.5,
    static_friction=0.5,
    restitution=0.0,
    damping=0.0,
    roughness=-1,
    frequency=-1,
):
    material = v.RigidMaterial()
    material.dynamic_friction = dynamic_friction
    material.static_friction = static_friction
    material.restitution = restitution
    material.damping = damping
    material.roughness = roughness
    material.frequency = frequency

    global_env_def = gym.get_environment_def(GLOBAL_ENV_DEF_HANDLE)
    material_handle = global_env_def.create_rigid_material(material)

    # Rotate plane so that plane normal is up
    up_axis = gym.get_up_axis()
    rot = v.shortest_rotation(v.Vec3(0, 1, 0), up_axis)
    pos = v.Vec3(0)
    transform = v.Transform(rot, pos)

    gym.create_plane(transform, material_handle)


def store_initial_conditions_helper(art_def, device, up_axis=v.Vec3(0, 1, 0)):
    # Store dof limits and initial values
    dof_pos_init = []
    for dofdef in art_def.get_joint_dof_defs():
        low, high = dofdef.get_limits()
        # vsim reports an INVERTED pair (low > high) for a DOF with no limits -- its own documented
        # sentinel. `np.clip` applies a_min then a_max, so clipping 0 against (1, -1) returns -1:
        # an unlimited joint would start a metre or a radian off its own zero. The clip is only
        # meant to pull 0 inside a real range, so an unlimited DOF simply starts at 0.
        init = 0.0 if low > high else float(np.clip(0.0, low, high))
        dof_pos_init.append(init)

    dof_pos_init = torch.tensor(dof_pos_init, dtype=torch.float32, device=device)

    # Store initial root transform
    rot = v.shortest_rotation(v.Vec3(0, 0, 1), up_axis)
    pos = 0.75 * up_axis
    root_trans_init = v.Transform(rot, pos)

    # Store initial root velocity
    root_vel_init = v.SpatialVector(0)

    return dof_pos_init, root_trans_init, root_vel_init
