"""Checkpoints: what a run hands back, plus enough provenance to read it without the run (D19).

A checkpoint holds an algorithm's payload -- network weights, generator state, whatever it needs to
reconstitute its artifacts -- next to two things the payload alone cannot supply:

**The module library, by name and by content.** Subtype identity is *positional*: a module's id is
its index in the library's declaration order, and the observation encodes it as a one-hot at that
index. Load a policy against a library whose vocabulary is ordered differently and every module
token is misread, silently and plausibly -- the shapes all still match. So the checkpoint records
the registry key and construction args (enough to rebuild the library) *and* the ordered names, slot
count, depth and subtype width (enough to detect that the rebuilt one is not the original). The
first makes a checkpoint self-contained; the second turns a vocabulary mismatch into a refusal.

**The observation offsets.** `Task.obs_layout()` is the package's published layout, and an offline
consumer -- `evaluate`, an analysis script, someone else's notebook -- has no live Task to ask. The
layout is plain ints and tuples precisely so it can travel here.

**The task, by registry key.** The layout catches a task whose *shape* differs, which is most of
them. It cannot catch two tasks that happen to agree on every offset -- same root axes, same extra
width -- and those load into each other silently and score nonsense. The key is the same string a
config names the task with, so it means the same thing in a config, a run's stamp and here.

Distinct from an algorithm's internal *resume* state. This is what a user takes away; resuming an
interrupted run is the algorithm's own business and may well be a bigger file.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Union

import torch

from codesigner.interfaces.modlib import ModuleLibrary

FORMAT_VERSION = 2      # 2 adds the task key; v1 checkpoints are rejected by `load`


class ProvenanceMismatch(RuntimeError):
    """A checkpoint's provenance does not match what it is being loaded against."""


def save(path: Union[str, Path], *, library: ModuleLibrary, task: str, obs_layout: dict,
         payload: dict, library_kwargs: Optional[dict] = None) -> None:
    """Write `payload` with the provenance needed to read it back.

    `task` is the registry key of the Task this was trained on (`tasks.registry_key(...)`).
    `library_kwargs` is how the library was constructed -- the caller's to supply, since only it
    knows what it passed. A library taking no arguments leaves it empty.
    """
    from codesigner.components.modular_libraries import REGISTRY

    key = library.name
    if REGISTRY.get(key) is not type(library):
        # Not fatal: the checkpoint still loads if the reader supplies the library. But it cannot
        # rebuild itself, which is most of the point, so say so at write time rather than leaving it
        # to fail on some other machine months later.
        print(f"[codesigner] warning: module library {key!r} is not the registered class for that "
              f"key, so this checkpoint cannot reconstruct it; readers must pass library=",
              flush=True)

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "format": FORMAT_VERSION,
        "library": {**library.descriptor(), "kwargs": dict(library_kwargs or {})},
        "task": task,
        "obs_layout": dict(obs_layout),
        "payload": payload,
    }, path)


def load(path: Union[str, Path], map_location=None, library: Optional[ModuleLibrary] = None,
         task: Optional[str] = None) -> dict:
    """Read a checkpoint, rebuilding and verifying its module library.

    Returns the stored dict with a live `library` added. Pass `library` to load against one you
    already hold -- it is verified against the recorded provenance rather than replacing it, so a
    mismatch still raises. Pass `task` (a registry key) to assert the checkpoint was trained on the
    task you are about to run it on; omitted, the recorded key is returned unchecked.
    """
    ckpt = torch.load(Path(path), map_location=map_location, weights_only=False)
    version = ckpt.get("format")
    if version != FORMAT_VERSION:
        raise ProvenanceMismatch(
            f"checkpoint format {version}, this build reads {FORMAT_VERSION}")

    prov = ckpt["library"]
    ckpt["library_provenance"] = prov
    ckpt["library"] = rebuild_library(prov) if library is None else library
    verify(ckpt["library"], prov)
    if task is not None and ckpt.get("task") != task:
        raise ProvenanceMismatch(
            f"checkpoint was trained on task {ckpt.get('task')!r}, loading against {task!r}. The "
            "observation layouts may still agree; the objectives do not.")
    return ckpt


def rebuild_library(provenance: dict) -> ModuleLibrary:
    """Reconstruct the recorded library from the registry. Verification is the caller's."""
    from codesigner.components.modular_libraries import REGISTRY

    key = provenance["name"]
    cls = REGISTRY.get(key)
    if cls is None:
        raise ProvenanceMismatch(
            f"checkpoint names module library {key!r}, which this build does not register "
            f"(have: {sorted(REGISTRY)}). Pass library= to load against your own.")
    return cls(**provenance.get("kwargs", {}))


def verify(library: ModuleLibrary, provenance: dict) -> None:
    """Raise if `library` differs from the one the checkpoint was written against.

    Checks content, not just the name: two libraries can share a registry key across a code change
    that reordered or renamed a module, and that change is exactly what silently corrupts a load.
    """
    have = library.descriptor()
    for field in ("name", "n_slots", "max_depth", "subtype_width"):
        if have[field] != provenance.get(field):
            raise ProvenanceMismatch(
                f"module library {field}: checkpoint has {provenance.get(field)!r}, "
                f"loaded library has {have[field]!r}")

    want_names = provenance.get("module_names", {})
    for type_name, names in want_names.items():
        mine = have["module_names"].get(type_name)
        if list(names) != list(mine or []):
            raise ProvenanceMismatch(
                f"module vocabulary for {type_name} differs: checkpoint has {list(names)}, loaded "
                f"library has {list(mine or [])}. Subtype ids are positions in this list, so every "
                f"module token would be misread.")

    # Slot placement is not implied by any field above: two libraries can agree on all of them and
    # still hang their limbs somewhere else entirely, which no shape check would notice.
    # `.get` rather than `[...]` so a checkpoint written before layouts still loads.
    want_layout = provenance.get("root_layout")
    if want_layout is not None and have["root_layout"] != want_layout:
        raise ProvenanceMismatch(
            f"root layout differs: checkpoint has {want_layout}, loaded library has "
            f"{have['root_layout']}. Every slot's placement, and so every limb's geometry, would "
            f"differ while the observation stayed the same shape.")
