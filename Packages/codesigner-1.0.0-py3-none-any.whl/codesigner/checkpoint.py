"""Checkpoints: what a run hands back, plus enough provenance to read it without the run (D19).

A checkpoint holds an algorithm's payload -- network weights, generator state, whatever it needs to
reconstitute its artifacts -- next to what the payload alone cannot supply:

**The module library, by name and by content.** Subtype identity is *positional*: a module's id is
its index in the library's declaration order, and the observation encodes it as a one-hot at that
index. Load a policy against a library whose vocabulary is ordered differently and every module
token is misread, silently and plausibly -- the shapes all still match. So the checkpoint records
the registry key and construction args (enough to rebuild the library) *and* the ordered names, slot
count, depth and subtype width (enough to detect that the rebuilt one is not the original). The
first makes a checkpoint self-contained; the second turns a vocabulary mismatch into a refusal.

**The observation offsets.** `Task.obs_layout()` is the package's published layout, and an offline
consumer -- `evaluate`, an analysis script, someone else's notebook -- has no live Task to ask. The
layout is plain ints and tuples precisely so it can travel here.

**The fixed morphologies, if the run had any.** A control run (`optimize_control`, `refine_control`)
was constrained to a body set, and the checkpoint says which. Nothing gates on it -- scoring a
specialized policy on other bodies is how you *measure* the specialization, and fixing is not what
makes a policy body-specific in the first place. It carries two meanings instead: what the policy
was tuned on, and that this checkpoint holds no designer worth consulting, since a shared trunk may
have moved the generator while the controller trained.

**The run position, and the metrics' carried state.** A **Resume** continues one interrupted run
from `latest.ckpt`, and what it needs beyond the weights is where the run had got to -- samples
spent, ticks taken, run time accumulated, best reward reached -- plus whatever the in-run metrics
were carrying, which lives nowhere else (modes discovered is a pool, travel is the previous
population). Both ride here rather than in the record because the driver writes this file *first*
each tick: on a crash between the two writes this is the only description of the run that agrees
with the weights being loaded.

**The task, by registry key.** The layout catches a task whose *shape* differs, which is most of
them. It cannot catch two tasks that happen to agree on every offset -- same root axes, same extra
width -- and those load into each other silently and score nonsense. The key is the same string a
config names the task with, so it means the same thing in a config, a run's stamp and here.

An algorithm's own continuation state -- its RNG stream above all -- belongs in its payload, and
`Algorithm.checkpoint_payload` says so: a resumed run whose generator re-seeds replays the draws it
already spent.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional, Sequence, Union

import torch

from codesigner.interfaces.modlib import Module, ModuleLibrary, Morphology, Orientation

FORMAT_VERSION = 2      # 2 adds the task key; v1 checkpoints are rejected by `load`
# `fixed_morphologies` was added without a bump, deliberately: absence is unambiguous, since control
# runs postdate v2 and a v2 file therefore cannot be one whose record went missing. Bumping would
# have rejected every existing checkpoint to record a field that reads correctly as `None`.


class ProvenanceMismatch(RuntimeError):
    """A checkpoint's provenance does not match what it is being loaded against."""


def save(path: Union[str, Path], *, library: ModuleLibrary, task: str, obs_layout: dict,
         payload: dict, library_kwargs: Optional[dict] = None,
         fixed_morphologies: Optional[Sequence[Morphology]] = None,
         position: Optional[dict] = None, metric_state: Optional[dict] = None) -> None:
    """Write `payload` with the provenance needed to read it back.

    `task` is the registry key of the Task this was trained on (`tasks.registry_key(...)`).
    `library_kwargs` is how the library was constructed -- the caller's to supply, since only it
    knows what it passed. A library taking no arguments leaves it empty. `fixed_morphologies` is the
    body set a control run was constrained to, `None` for an ordinary `optimize` run.

    `position` is what a **Resume** continues from (`{samples, tick, wall_time, best_reward}`) and
    `metric_state` is what the in-run metrics were carrying. Both are the driver's to supply, since
    only it knows them; `None` writes a checkpoint that can be loaded but not resumed from, which is
    what every checkpoint outside a run directory is.
    """
    from codesigner.components.modular_libraries import REGISTRY

    key = library.name
    if REGISTRY.get(key) is not type(library):
        # Not fatal: the checkpoint still loads if the reader supplies the library. But it cannot
        # rebuild itself, which is most of the point, so say so at write time rather than leaving it
        # to fail on some other machine months later.
        print(f"[codesigner] warning: module library {key!r} is not the registered class for that "
              f"key, so this checkpoint cannot reconstruct it; readers must pass library=",
              flush=True)

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    blob = {
        "format": FORMAT_VERSION,
        "library": {**library.descriptor(), "kwargs": dict(library_kwargs or {})},
        "task": task,
        "obs_layout": dict(obs_layout),
        "fixed_morphologies": encode_morphologies(fixed_morphologies),
        "position": dict(position) if position else None,
        "metric_state": metric_state,
        "payload": payload,
    }

    # Write beside the destination, then rename over it. `os.replace` is atomic within a filesystem,
    # so a reader sees the old checkpoint or the new one and never a half-written file. The rolling
    # checkpoint is rewritten every run tick at the rebuild boundary -- which is exactly where
    # `resample` carries its known intermittent crash -- so writing in place means the most likely
    # moment to die is the moment a good checkpoint is destroyed. Same directory, not a temp dir, so
    # the rename never crosses a filesystem.
    tmp = path.with_name(path.name + ".partial")
    try:
        torch.save(blob, tmp)
        os.replace(tmp, path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def load(path: Union[str, Path], map_location=None, library: Optional[ModuleLibrary] = None,
         task: Optional[str] = None) -> dict:
    """Read a checkpoint, rebuilding and verifying its module library.

    Returns the stored dict with a live `library` added. Pass `library` to load against one you
    already hold -- it is verified against the recorded provenance rather than replacing it, so a
    mismatch still raises. Pass `task` (a registry key) to assert the checkpoint was trained on the
    task you are about to run it on; omitted, the recorded key is returned unchecked.
    """
    ckpt = torch.load(Path(path), map_location=map_location, weights_only=False)
    version = ckpt.get("format")
    if version != FORMAT_VERSION:
        raise ProvenanceMismatch(
            f"checkpoint format {version}, this build reads {FORMAT_VERSION}")

    prov = ckpt["library"]
    ckpt["library_provenance"] = prov
    ckpt["library"] = rebuild_library(prov) if library is None else library
    verify(ckpt["library"], prov)
    if task is not None and ckpt.get("task") != task:
        raise ProvenanceMismatch(
            f"checkpoint was trained on task {ckpt.get('task')!r}, loading against {task!r}. The "
            "observation layouts may still agree; the objectives do not.")
    # Decoded against the library only after it has been verified, so a body is rebuilt from the
    # vocabulary it was written against or not at all.
    ckpt["fixed_morphologies"] = decode_morphologies(ckpt.get("fixed_morphologies"),
                                                     ckpt["library"])
    # `.get`, not `[...]`, for the same reason `fixed_morphologies` was added without a bump: a
    # checkpoint written before resume existed reads correctly as "no position", which is what a
    # resume refuses on, and bumping would have rejected every existing file to say it.
    ckpt.setdefault("position", None)
    ckpt.setdefault("metric_state", None)
    return ckpt


def rebuild_library(provenance: dict) -> ModuleLibrary:
    """Reconstruct the recorded library from the registry. Verification is the caller's."""
    from codesigner.components.modular_libraries import REGISTRY

    key = provenance["name"]
    cls = REGISTRY.get(key)
    if cls is None:
        raise ProvenanceMismatch(
            f"checkpoint names module library {key!r}, which this build does not register "
            f"(have: {sorted(REGISTRY)}). Pass library= to load against your own.")
    return cls(**provenance.get("kwargs", {}))


def verify(library: ModuleLibrary, provenance: dict) -> None:
    """Raise if `library` differs from the one the checkpoint was written against.

    Checks content, not just the name: two libraries can share a registry key across a code change
    that reordered or renamed a module, and that change is exactly what silently corrupts a load.
    """
    have = library.descriptor()
    for field in ("name", "n_slots", "max_depth", "subtype_width"):
        if have[field] != provenance.get(field):
            raise ProvenanceMismatch(
                f"module library {field}: checkpoint has {provenance.get(field)!r}, "
                f"loaded library has {have[field]!r}")

    want_names = provenance.get("module_names", {})
    for type_name, names in want_names.items():
        mine = have["module_names"].get(type_name)
        if list(names) != list(mine or []):
            raise ProvenanceMismatch(
                f"module vocabulary for {type_name} differs: checkpoint has {list(names)}, loaded "
                f"library has {list(mine or [])}. Subtype ids are positions in this list, so every "
                f"module token would be misread.")

    # Slot placement is not implied by any field above: two libraries can agree on all of them and
    # still hang their limbs somewhere else entirely, which no shape check would notice.
    # `.get` rather than `[...]` so a checkpoint written before layouts still loads.
    want_layout = provenance.get("root_layout")
    if want_layout is not None and have["root_layout"] != want_layout:
        raise ProvenanceMismatch(
            f"root layout differs: checkpoint has {want_layout}, loaded library has "
            f"{have['root_layout']}. Every slot's placement, and so every limb's geometry, would "
            f"differ while the observation stayed the same shape.")


# ---- morphologies, structurally ------------------------------------------------------------

def encode_morphologies(bodies: Optional[Sequence[Morphology]]) -> Optional[list]:
    """Bodies as `(module name, orientation index)` per slot, per chain.

    Structural rather than pickled. A `Morphology` holds `ModuleDefinition`s, whose `geometry` is
    whatever the library made it, so pickling one would drag a library's private classes into the
    file and make the checkpoint fail to open wherever they cannot be imported -- duplicating,
    worse, the job the library provenance already does. Names and orientation indices rebuild
    exactly against the library the checkpoint already verified.
    """
    if not bodies:
        return None
    return [[[(m.name, m.orientation.index) for m in chain] for chain in body]
            for body in bodies]


def decode_morphologies(encoded: Optional[list],
                        library: ModuleLibrary) -> Optional[List[Morphology]]:
    """Rebuild what `encode_morphologies` wrote, against `library`.

    Unlike `Morphology.from_names`, this carries orientation: a body whose modules were mounted the
    other way up rebuilds as that body rather than as a plausible different one.
    """
    if not encoded:
        return None
    out: List[Morphology] = []
    for body in encoded:
        chains: List[List[Module]] = []
        for chain in body:
            modules = []
            for name, index in chain:
                definition = library.modules.get(name)
                if definition is None:
                    raise ProvenanceMismatch(
                        f"checkpoint records a fixed morphology using module {name!r}, which the "
                        f"loaded library does not define")
                orientation = Orientation(index)
                if orientation not in definition.orientations:
                    raise ProvenanceMismatch(
                        f"checkpoint records module {name!r} at orientation {index}, which the "
                        f"loaded library does not list among its valid orientations")
                modules.append(Module(definition, orientation))
            chains.append(modules)
        out.append(Morphology(chains))
    return out
