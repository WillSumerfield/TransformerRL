from codesigner.components.algorithms.evolutionary import (CPGControlPolicy, EvolutionaryAlgorithm,
                                                           PopulationMorphologyGenerator)

# Registry of shipped algorithms, keyed by the name a config names them with (mirrors
# modular_libraries.REGISTRY). CPGControlPolicy and PopulationMorphologyGenerator are excluded: per
# D18 they are artifacts an Algorithm hands out, not plug points a config selects independently.
REGISTRY = {
    "evolutionary": EvolutionaryAlgorithm,
}

__all__ = ["EvolutionaryAlgorithm", "CPGControlPolicy", "PopulationMorphologyGenerator", "REGISTRY"]
