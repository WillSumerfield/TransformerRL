from codesigner.components.algorithms.evolutionary import (CPGControlPolicy, EvolutionaryAlgorithm,
                                                           PopulationMorphologyGenerator)
from codesigner.components.algorithms.graph_heuristic_search import GraphHeuristicSearch

# Registry of shipped algorithms, keyed by the name a config names them with (mirrors
# modular_libraries.REGISTRY). CPGControlPolicy and PopulationMorphologyGenerator are excluded: per
# D18 they are artifacts an Algorithm hands out, not plug points a config selects independently.
# So is everything in `algorithms.control` -- MPPI is a sub-component an algorithm composes, and
# selecting it as "the algorithm" would leave nothing designing the body.
REGISTRY = {
    "evolutionary": EvolutionaryAlgorithm,
    "graph_heuristic_search": GraphHeuristicSearch,
}

__all__ = ["EvolutionaryAlgorithm", "CPGControlPolicy", "PopulationMorphologyGenerator",
           "GraphHeuristicSearch", "REGISTRY"]
