"""Model Predictive Path Integral control, ported from RoboGrammar.

Ported from RoboGrammar (`core/src/optim.cpp`, `core/include/robot_design/optim.h`), MIT licence,
Copyright (c) 2020 Allan Zhao, Jie Xu, Mina Konakovic-Lukovic, Josephine Hughes, Andrew Spielberg,
Daniela Rus, Wojciech Matusik. Their `MPPIOptimizer` and `DefaultInputSampler`, kept faithful; the
adaptations our stack forces are named as such where they occur.

MPPI is a sampling planner, not a learned controller. Each control step it draws `sample_count`
candidate input sequences over a horizon, rolls each one forward through the simulator, and BLENDS
them by softmax weight on return -- it does not take the best one. It then executes the first column
of the blend and shifts the plan along.

The one structural adaptation: RoboGrammar runs one simulator instance per sample on a thread pool,
so its sample count is a free parameter. Ours are envs of a single GPU simulation, so the sample
count IS `Task.envs_per_morph` and is fixed when the Task is set up. A whole morphology group plans
together, and every group plans in parallel, so a run planning for 16 bodies at 256 samples each is
one batched rollout over 4096 envs rather than 16 sequential ones. Their two-stage
512-then-64 sample schedule (`design_search.py`'s `optimizer.set_sample_count(64)` after a wide
first update) has nowhere to go under a fixed env count and is dropped.
"""
import torch

from codesigner.interfaces.algorithm import ControlPolicy

# FIR filter with passband below 2 Hz, stopband above 4 Hz at f_s = 15 Hz. Verbatim from
# `DefaultInputSampler::sampleInputSequence`, and the reason the port holds a control rate rather
# than a control interval: these coefficients are only the filter they are named after at 15 Hz.
_FILTER_COEFFS = (0.10422766377112629, 0.3239870556899027, 0.3658903830367387,
                  0.3239870556899027, 0.10422766377112629)


class ValueEstimator:
    """Estimates the value of the state a horizon ends in, to bootstrap a truncated return.

    RoboGrammar's `ValueEstimator` interface. The planner adds `gamma**horizon * estimate(obs)` to
    every sample's return, so a horizon that ends mid-stride is not scored as if the episode stopped
    there.
    """

    def estimate(self, observation: torch.Tensor) -> torch.Tensor:
        """`(num_envs, obs_total)` -> `(num_envs,)` estimated discounted value."""
        raise NotImplementedError


class NullValueEstimator(ValueEstimator):
    """Estimates zero. RoboGrammar's own default, and what its graph-heuristic search runs with --
    the value function it learns scores DESIGNS, not states, so it never enters the planner."""

    def estimate(self, observation: torch.Tensor) -> torch.Tensor:
        return torch.zeros(observation.shape[0], dtype=observation.dtype, device=observation.device)


class DefaultInputSampler:
    """Draws candidate input sequences around the current plan. RoboGrammar's `DefaultInputSampler`.

    Two kinds of candidate, alternating by sample index:

      even `k` -- REPEAT past motion. The last `repeat_len` columns of the history are tiled across
                  the horizon and cross-faded into the current plan, `repeat_len` cycling over
                  `[H/2 + 1, H]` with `k`. This is what makes a gait: a periodic input that scored
                  well is proposed back at every period the horizon can hold.
      odd `k`  -- WARM START. The current plan, unchanged.

    Each then gets low-pass-filtered Gaussian noise, wider on the warm-start half
    (`warm_start_std_dev` 0.25 vs `history_std_dev` 0.05) -- the repeats are already a structured
    proposal and need less jitter than perturbing the plan in place.

    Adaptation: RoboGrammar reseeds a generator per sample (`mt19937(sample_seed + sample_idx)`) so
    that `update` can REGENERATE each sequence when it comes to weight them, its worker threads
    having thrown their copies away. Batched, the sequences are one tensor and are simply kept, so
    the regeneration -- and the seed bookkeeping that exists only to make it reproducible -- is gone.
    """

    def __init__(self, history_std_dev: float = 0.05, warm_start_std_dev: float = 0.25):
        self.history_std_dev = history_std_dev
        self.warm_start_std_dev = warm_start_std_dev

    def sample(self, last_seq: torch.Tensor, history: torch.Tensor, sample_count: int,
               generator: torch.Generator = None) -> torch.Tensor:
        """`(M, A, H)` plan and history -> `(M, K, A, H)` candidates, K = `sample_count`.

        M is the morphology count, A the action width, H the horizon. Every morphology is sampled
        for at once; they share a horizon and an action width, and nothing else.
        """
        M, A, H = last_seq.shape
        K = sample_count
        dev = last_seq.device
        k = torch.arange(K, device=dev)
        j = torch.arange(H, device=dev)
        repeat = (k // 2) % (H // 2) + H // 2 + 1                     # (K,) in [H/2 + 1, H]

        # history.rightCols(repeat).replicate(1, H).col(j) -- the last `repeat` columns, tiled.
        col = H - repeat[:, None] + (j[None, :] % repeat[:, None])    # (K, H)
        hist = history[:, None, :, :].expand(M, K, A, H).gather(
            3, col[None, :, None, :].expand(M, K, A, H))
        t = ((j + 1).to(last_seq.dtype) / H)                          # cross-fade, no input jumps
        seq = t * hist + (1.0 - t) * last_seq[:, None]

        # The history branch is gated on `history_len >= horizon` upstream, which their history is
        # sized to satisfy from construction, so it is always taken on even samples.
        is_hist = (k % 2 == 0)[None, :, None, None]
        seq = torch.where(is_hist, seq, last_seq[:, None].expand(M, K, A, H))

        std = torch.where(k % 2 == 0,
                          torch.tensor(self.history_std_dev, dtype=seq.dtype, device=dev),
                          torch.tensor(self.warm_start_std_dev, dtype=seq.dtype, device=dev))
        coeffs = torch.tensor(_FILTER_COEFFS, dtype=seq.dtype, device=dev)
        n = coeffs.numel()
        noise = torch.empty((M, K, A, H + n - 1), dtype=seq.dtype, device=dev).normal_(
            0.0, 1.0, generator=generator) * std[None, :, None, None]
        return seq + (noise.unfold(-1, n, 1) * coeffs).sum(-1)


class OpenLoopPolicy(ControlPolicy):
    """A committed input sequence, replayed. The serializable half of an MPPI result.

    MPPI itself cannot be checkpointed usefully -- it is the simulator plus a search, and "the
    controller" only exists as the trajectory that search committed to. So a planned episode is
    handed back as this: `(n_morphs, action_dim, length)`, replayed column by column.

    Open loop, so it must be driven from the start of an episode. `act` ignores the observation
    entirely and reads the clock, which is `reset()`'s to zero and its own to advance; past the end
    of the sequence it holds the last column.
    """

    def __init__(self, sequence: torch.Tensor, interval: int = 1, name: str = "open_loop"):
        super().__init__(name)
        self.sequence = sequence                 # (M, A, T)
        self.interval = interval                 # task steps each column is held for
        self._t = 0

    def reset(self):
        self._t = 0

    def act(self, observation, deterministic: bool = True):
        M, A, T = self.sequence.shape
        col = min(self._t // self.interval, T - 1)
        self._t += 1
        envs_per_morph = observation.shape[0] // M
        return (self.sequence[:, None, :, col]
                .expand(M, envs_per_morph, A).reshape(-1, A).to(observation.device))

    def __str__(self):
        M, A, T = self.sequence.shape
        return f"OpenLoopPolicy(name={self.name}, morphs={M}, action_dim={A}, length={T})"


class MPPIPolicy(ControlPolicy):
    """The live planner: `MPPIOptimizer`, driving a Task as its own model.

    Use it as a `ControlPolicy` and the episode loop is unchanged:

        policy = MPPIPolicy(task, interval=4, horizon=16)
        policy.reset()
        for _ in range(episode_len * policy.interval):
            obs, rew, term, trunc, _ = task.step(policy.act(obs))

    `act` ignores its observation. A planner does not act on a summary of the state, it acts on the
    state, and it gets that by rewinding and replaying the simulator directly -- which also means
    this policy cannot be detached from the Task the way a network can. `open_loop_policy()` returns
    the detachable artifact once an episode has been planned.

    The Task's `auto_reset` is held off for as long as this policy is driving: a sample that falls
    over inside the horizon must stay fallen, and an auto-reset would hand it a fresh robot and let
    it keep scoring. RoboGrammar's simulator has no notion of termination at all, so a rollout that
    fails simply accrues a bad return; keeping the accrual is what matches it. `reset()` and
    `release()` put the flag back.
    """

    def __init__(self, task, interval: int = 4, horizon: int = 16, kappa: float = 1.0,
                 discount_factor: float = 0.99, value_estimator: ValueEstimator = None,
                 input_sampler: DefaultInputSampler = None, seed: int = None,
                 name: str = "mppi"):
        super().__init__(name)
        self.task = task
        self.interval = interval
        self.horizon = horizon
        self.kappa = kappa
        self.discount_factor = discount_factor
        self.value_estimator = value_estimator or NullValueEstimator()
        self.input_sampler = input_sampler or DefaultInputSampler()

        M, A = task.n_morphs, task.action_space.shape[0]
        self.sample_count = task.envs_per_morph
        dev = task.device
        self.input_sequence = torch.zeros((M, A, horizon), dtype=torch.float32, device=dev)
        self.history = torch.zeros((M, A, horizon), dtype=torch.float32, device=dev)
        self._gen = torch.Generator(device=dev)
        if seed is not None:
            self._gen.manual_seed(seed)
        # Restore gather: every env of a morphology group is put back into the state of that
        # group's first env, which is the one carrying the real robot.
        self._src = (torch.arange(task.total_num_envs, device=dev)
                     // self.sample_count * self.sample_count)
        self._prev_auto_reset = task.auto_reset
        self._hold = 0
        self._committed = torch.zeros((M, A), dtype=torch.float32, device=dev)
        self.executed = []

    # ---- the artifact ----------------------------------------------------------

    def open_loop_policy(self) -> OpenLoopPolicy:
        """The columns executed so far, as a replayable `OpenLoopPolicy`."""
        if not self.executed:
            raise RuntimeError("nothing has been planned yet; call act() through an episode first")
        return OpenLoopPolicy(torch.stack(self.executed, dim=-1), interval=self.interval)

    # ---- driving ---------------------------------------------------------------

    def reset(self):
        """Start a fresh episode: zero the plan, sync each group's envs, hold off auto-reset.

        The sync matters. A Task reset gives every env its own DOF noise, so a group's envs start
        DIFFERENT -- and a sample's return is only about its input sequence if every sample starts
        from the same state.
        """
        self.input_sequence.zero_()
        self.history.zero_()
        self.executed = []
        self._hold = 0
        self._prev_auto_reset = self.task.auto_reset
        self.task.auto_reset = False
        self.task.restore_state(self.task.save_state(), self._src)

    def release(self):
        """Give the Task's auto-reset back. Call when the planner is done driving it."""
        self.task.auto_reset = self._prev_auto_reset

    def act(self, observation, deterministic: bool = True):
        """The action to step the Task with. Replans every `interval` calls; holds in between.

        `deterministic` has no meaning here -- the plan IS the committed action, and the sampling
        that produced it happened inside the simulator, not at the output.
        """
        if self._hold == 0:
            state = self.task.save_state()
            self.update(state)
            self.task.restore_state(state, self._src)
            self._committed = self.input_sequence[:, :, 0].clone()
            self.executed.append(self._committed)
            self.advance(1)
            self._hold = self.interval
        self._hold -= 1
        M, A = self._committed.shape
        return (self._committed[:, None, :]
                .expand(M, self.sample_count, A).reshape(self.task.total_num_envs, A))

    # ---- the optimizer ---------------------------------------------------------

    def update(self, state: dict):
        """One MPPI iteration from `state`: sample, roll out, blend. `MPPIOptimizer::update`.

        Leaves the Task at the end of the last rollout -- the caller restores. That mirrors the
        original, where each worker restores its own instance and the real simulator is a separate
        object entirely.
        """
        seqs = self.input_sampler.sample(self.input_sequence, self.history, self.sample_count,
                                         self._gen)                       # (M, K, A, H)
        M, K, A, H = seqs.shape
        N = self.task.total_num_envs
        self.task.restore_state(state, self._src)

        returns = torch.zeros(N, dtype=torch.float32, device=self.task.device)
        discount = 1.0
        flat = seqs.permute(0, 1, 3, 2).reshape(N, H, A)                  # (N, H, A)
        for j in range(H):
            action = flat[:, j]
            # The inner interval loop is theirs: the objective is accumulated at every simulator
            # step the input is held for, not once per horizon column, and the discount steps only
            # on the column. Our step is a control step where theirs is a physics step, so the
            # accumulation lands on the same clock.
            for _ in range(self.interval):
                self.task.step(action)
                returns += self.task.rew_buf * discount
            discount *= self.discount_factor

        returns += (self.value_estimator.estimate(self.task.obs_buf)
                    * self.discount_factor ** H)

        # Blend, do NOT argmax. Softmax weights on return, normalized against the best sample of
        # each morphology group so the exponential cannot overflow.
        r = returns.view(M, K)
        w = torch.exp(self.kappa * (r - r.max(dim=1, keepdim=True).values))   # (M, K)
        self.input_sequence = ((seqs * w[:, :, None, None]).sum(dim=1)
                               / w.sum(dim=1)[:, None, None])

    def advance(self, step_count: int = 1):
        """Commit the first `step_count` columns and shift the plan along. `MPPIOptimizer::advance`.

        Their `advance` also steps the sample simulators, because those ARE the state they plan
        from next time. Ours plan from a state the caller supplies, so this is only the bookkeeping.
        """
        s = step_count
        self.history = torch.cat([self.history[:, :, s:], self.input_sequence[:, :, :s]], dim=2)
        self.input_sequence = torch.cat(
            [self.input_sequence[:, :, s:], torch.zeros_like(self.input_sequence[:, :, :s])], dim=2)

    def __str__(self):
        return (f"MPPIPolicy(name={self.name}, interval={self.interval}, horizon={self.horizon}, "
                f"samples={self.sample_count}, kappa={self.kappa})")
