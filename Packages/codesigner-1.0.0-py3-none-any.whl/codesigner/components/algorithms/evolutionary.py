"""A mutation-and-truncation evolutionary algorithm over bodies and open-loop gaits.

The package's own reference `Algorithm`, and the counterweight to TransformerRL's PPG agent: no
gradients, no networks, no rollout buffers. It exists to keep `Algorithm` an interface rather than a
description of one implementation -- every abstract method here is satisfied by something structurally
unlike what the transformer does.

**One `run()` is one generation**, which is also a rebuild boundary (D24): resample the population,
roll it out, score it, select, mutate. Fitness is the mean return of each body's **first** completed
episode across its `envs_per_morph` envs -- the same convention `evaluate` uses, because averaging
over "however many episodes fit" quietly weights the bodies that fall over early by their worst
behaviour.

**The genome is fixed-width over the padded `(slot, depth)` grid**, not over the modules a body
actually has. Mutation therefore never resizes anything, and a mutation that lengthens a limb finds
genes already waiting at the new depth instead of needing fresh ones -- which is what lets body and
gait co-evolve rather than the gait restarting from scratch after every morphological change. Genes
for absent modules are simply never read: the Task masks inactive DOFs itself.

Two things this deliberately demonstrates about the interfaces:

- **It has no inner step.** The whole population is rolled out in one batched pass, so there is no
  cadence between "generation" and "one step of a generation". It therefore never calls
  `report_iteration`, which is the best-effort half of the progress contract (D26) being exercised
  rather than assumed.
- **It is the algorithm most exposed to the seeding contract.** A `Seed` means reproducible draws,
  not bitwise-deterministic kernels, and selection here is a hard `argsort` over fitness -- so a
  single body whose physics differ in the last decimal can reorder the elites and send the whole
  search somewhere else. Measured: at one seed, two runs in **separate processes** agree exactly
  (genes, bodies and all fitnesses), while two runs in the **same process** agreed on 13 of 16
  bodies and diverged on one, which was enough to change every later generation. Compare EA runs
  one process per seed.

- **Its ControlPolicy does not generalize across bodies.** A CPG's genes are indexed by padded slot
  and were selected alongside one morphology; run them on a different body and they drive whatever
  modules happen to occupy those slots. The transformer's policy reads an observation and generalizes;
  this one does not. Both satisfy `ControlPolicy`, so scoring a checkpoint on bodies other than its
  own is meaningful for one and not the other -- a caller cannot tell from the interface, and that
  asymmetry is worth knowing before `evaluate`'s numbers are trusted.
"""
from __future__ import annotations

import math
import random
from typing import Dict, List, Optional, Tuple

import torch

from codesigner.metrics.capability import SPREAD_CONTROL, provides
from codesigner.interfaces import (Algorithm, ControlPolicy, ModuleType, Morphology,
                                   MorphologyGenerator)

_TWO_PI = 2.0 * math.pi

# The gene tensors, and the shape suffix each carries after the leading population dim.
#   counts  (n_slots,)             effectors in each attachment slot; 0 = slot empty
#   eff_sub (n_slots, max_depth)   effector subtype per depth; only [:count] is ever read
#   cap_sub (n_slots,)             cap subtype closing the chain
#   amp/phase/freq (action_width,) one sinusoid per action channel, padded-grid order
_MORPH_GENES = ("counts", "eff_sub", "cap_sub")
_CPG_GENES = ("amp", "phase", "freq")
_GENES = _MORPH_GENES + _CPG_GENES


class CPGControlPolicy(ControlPolicy):
    """An open-loop central pattern generator: `amp * sin(2*pi*freq*t + phase)` per action channel.

    Reads nothing from the observation but its batch size, so this algorithm never consults
    `obs_layout` -- the layout matters to policies that decode observations, and a CPG does not. The
    clock is an internal step counter, which makes the policy **stateful**: a score depends on the
    phase it was started at, so `reset()` before a rollout you intend to compare with another.

    `deterministic` is accepted and ignored: there is no distribution here to take the mode of.
    """

    def __init__(self, amp: torch.Tensor, phase: torch.Tensor, freq: torch.Tensor, dt: float,
                 name: str = "cpg"):
        super().__init__(name=name)
        self.amp, self.phase, self.freq, self.dt = amp, phase, freq, dt
        self.step_index = 0

    def reset(self) -> None:
        self.step_index = 0

    def act(self, observation, deterministic: bool = True):
        t = self.step_index * self.dt
        self.step_index += 1
        a = self.amp * torch.sin(_TWO_PI * self.freq * t + self.phase)
        if a.dim() == 1:                              # one individual's genes, shared by every env
            a = a.unsqueeze(0).expand(observation.shape[0], -1)
        return a.clamp(-1.0, 1.0)


class PopulationMorphologyGenerator(MorphologyGenerator):
    """The population, as a distribution over bodies.

    An EA holds a *set*, not a parametric distribution, so a stochastic draw is a uniform pick from
    the current generation (with replacement, since n may exceed the population) and a deterministic
    draw is the best individual repeated. That is the honest reading of `generate`'s contract for a
    population-based method: the spread a stochastic draw shows is real diversity between individuals
    rather than sampling noise around one design.
    """

    def __init__(self, bodies: List[Morphology], best: Morphology, generator: torch.Generator,
                 name: str = "evolved_population"):
        super().__init__(name=name)
        self._bodies = list(bodies)
        self._best = best
        self._generator = generator

    def generate(self, n: int, deterministic: bool = False) -> List[Morphology]:
        if deterministic:
            return [self._best] * n
        idx = torch.randint(len(self._bodies), (n,), generator=self._generator,
                            device=self._generator.device)
        return [self._bodies[int(i)] for i in idx]


class EvolutionaryAlgorithm(Algorithm):
    """Truncation selection with elitism, over a joint body-and-gait genome.

    Each generation keeps the top `elite_frac` unmutated -- so the best individual can never regress
    -- and refills the population by mutating copies of them.
    """

    _AMP_RANGE = (0.2, 1.0)
    _FREQ_RANGE = (0.5, 2.5)            # Hz; slower than one stride per second up to brisk

    def __init__(
        self,
        population_size: int = 1024,
        envs_per_body: int = 4,
        generations: int = 50,
        elite_frac: float = 0.25,
        morph_mutation_rate: float = 0.15,
        cpg_sigma: float = 0.15,
        max_steps: Optional[int] = None,
        seed: int = 0,
        name: str = "evolutionary",
        description: str = "mutation + truncation selection over body and open-loop gait",
    ):
        super().__init__(name=name, description=description)
        self.population_size = population_size
        self.envs_per_body = envs_per_body
        self.generations = generations
        self.elite_frac = elite_frac
        self.morph_mutation_rate = morph_mutation_rate
        self.cpg_sigma = cpg_sigma
        self.max_steps = max_steps
        self.seed = seed

        self._generation = 0
        self._genes: Dict[str, torch.Tensor] = {}
        self._best_genes: Dict[str, torch.Tensor] = {}
        self._best_fitness = -float("inf")
        self._evaluated: Optional[List[Morphology]] = None
        self._rng: Optional[torch.Generator] = None
        # A python RNG, separate from the torch one the search draws with: the ladder must not
        # perturb the sequence a run would otherwise have drawn.
        self._spread_rng: Optional[random.Random] = None
        self._dt = 0.0
        self._started = False
        self._fixed: Optional[List[Morphology]] = None

    # ---- the loop --------------------------------------------------------------------

    def run(self) -> Tuple[float, ControlPolicy, MorphologyGenerator]:
        # On whether the Task is standing, not on whether genes exist: `refine_control` loads a
        # population out of a checkpoint before the sim exists, and resampling one that was never
        # set up is a crash rather than a rebuild.
        if not self._started:
            self._start()
        else:
            self._evaluated = self._bodies(self._genes)
            self.task.resample(self._evaluated)

        fitness = self._rollout()

        top = int(torch.argmax(fitness))
        if float(fitness[top]) > self._best_fitness:
            self._best_fitness = float(fitness[top])
            self._best_genes = {k: v[top].clone() for k, v in self._genes.items()}

        self._genes = self._next_generation(fitness)
        self._generation += 1
        return float(fitness[top]), self.control_policy(), self.morphology_generator()

    def is_finished(self) -> bool:
        return self._generation >= self.generations

    def _start(self) -> None:
        """Draw the first population and size the Task around it.

        The env count is the algorithm's to choose (D7), and choosing `population_size *
        envs_per_body` exactly makes the round-down in `setup` a no-op -- every body gets the same
        number of envs and none are lost.
        """
        device = self.task.device
        if self._rng is None:
            self._rng = torch.Generator(device=device)
            self._rng.manual_seed(self.seed)
        # Genes a checkpoint supplied are kept and only moved onto the live device; a fresh run
        # draws them. `map_location="cpu"` would otherwise leave the population on the wrong device.
        self._genes = {k: v.to(device) for k, v in self._genes.items()}
        if not any(k in self._genes for k in _MORPH_GENES):
            self._init_morphology_genes(device)

        self._evaluated = self._bodies(self._genes)
        self.task.setup(self.modlib, self.population_size * self.envs_per_body,
                        self.population_size, self._evaluated, seed=self.seed)
        # Action width and dt exist only once there is a live sim, so the gait half of the genome is
        # drawn here rather than beside the morphology half.
        if not any(k in self._genes for k in _CPG_GENES):
            self._init_cpg_genes(self.task.action_space.shape[0], device)
        self._dt = self.task.dt
        self._started = True

    # ---- genome ----------------------------------------------------------------------

    def _init_morphology_genes(self, device) -> None:
        p, n_slots = self.population_size, self.modlib.n_slots
        g = self._rng
        self._genes["counts"] = torch.randint(
            0, self.modlib.max_effectors + 1, (p, n_slots), generator=g, device=device)
        self._genes["eff_sub"] = torch.randint(
            0, len(self.modlib.names(ModuleType.EFFECTOR)),
            (p, n_slots, self.modlib.max_depth), generator=g, device=device)
        self._genes["cap_sub"] = torch.randint(
            0, len(self.modlib.names(ModuleType.CAP)), (p, n_slots), generator=g, device=device)
        self._repair(self._genes["counts"])

    def _init_cpg_genes(self, width: int, device) -> None:
        p, g = self.population_size, self._rng
        lo_a, hi_a = self._AMP_RANGE
        lo_f, hi_f = self._FREQ_RANGE
        rand = lambda: torch.rand((p, width), generator=g, device=device)
        self._genes["amp"] = lo_a + (hi_a - lo_a) * rand()
        self._genes["phase"] = _TWO_PI * rand()
        self._genes["freq"] = lo_f + (hi_f - lo_f) * rand()

    def _repair(self, counts: torch.Tensor) -> None:
        """Guarantee at least one limb, in place. A body with no modules has no scene to build."""
        empty = counts.sum(1) == 0
        n = int(empty.sum())
        if n:
            slot = torch.randint(counts.shape[1], (n,), generator=self._rng, device=counts.device)
            counts[empty.nonzero(as_tuple=True)[0], slot] = 1

    def _bodies(self, genes: Dict[str, torch.Tensor]) -> List[Morphology]:
        """Genes -> the bodies the Task will build. The only place the genome crosses the boundary,
        and it crosses as `Morphology` -- nothing downstream sees a gene.

        Under fixed morphologies the morphology genes are bypassed entirely rather than back-encoded
        into `counts`/`eff_sub`/`cap_sub`. That encoding cannot carry `Orientation`, so a fixed body
        whose modules are mounted the other way up would round-trip into a plausible DIFFERENT body
        -- and every caller wanting one body per row is served by tiling the fixed set instead. The
        morphology genes stay allocated and simply go unread, which keeps selection, mutation and
        the checkpoint payload identical in both phases.
        """
        if self._fixed is not None:
            n = len(next(iter(genes.values())))
            return [self._fixed[i % len(self._fixed)] for i in range(n)]

        eff_names = self.modlib.names(ModuleType.EFFECTOR)
        cap_names = self.modlib.names(ModuleType.CAP)
        counts = genes["counts"].tolist()
        eff_sub = genes["eff_sub"].tolist()
        cap_sub = genes["cap_sub"].tolist()
        out = []
        for p in range(len(counts)):
            chains = {}
            for s in range(self.modlib.n_slots):
                k = counts[p][s]
                if k > 0:
                    chains[s] = ([eff_names[eff_sub[p][s][d]] for d in range(k)],
                                 cap_names[cap_sub[p][s]])
            out.append(Morphology.from_names(self.modlib, chains))
        return out

    # ---- evaluation ------------------------------------------------------------------

    @torch.no_grad()
    def _rollout(self) -> torch.Tensor:
        """Mean first-episode return per body, `(population_size,)`.

        Every individual runs at once: the population is what the Task was sized for, so one batched
        rollout scores the whole generation. Genes are expanded per env by the envs-per-body block
        structure the Task lays envs out in.
        """
        task = self.task
        epm = task.envs_per_morph
        amp, phase, freq = (self._genes[k].repeat_interleave(epm, dim=0) for k in _CPG_GENES)
        policy = CPGControlPolicy(amp, phase, freq, self._dt)

        n = task.total_num_envs
        steps = self.max_steps if self.max_steps is not None else task.max_episode_length
        returns = torch.zeros(n, device=task.device)
        done = torch.zeros(n, dtype=torch.bool, device=task.device)

        obs, _ = task.reset()
        for _ in range(steps):
            obs, reward, terminated, truncated, _ = task.step(policy.act(obs))
            reward = reward.squeeze(-1) if reward.ndim > 1 else reward
            returns += reward * (~done).float()      # frozen once an env's first episode ends
            done |= (terminated | truncated)
            if bool(done.all()):
                break
        return returns.view(self.population_size, epm).mean(dim=1)

    # ---- selection -------------------------------------------------------------------

    def _next_generation(self, fitness: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Elites carried through untouched, the rest mutated copies of them.

        Elitism is on the *genome*, so the best body keeps the gait it was scored with -- selecting
        the two halves independently would break pairs that only work together.
        """
        order = torch.argsort(fitness, descending=True)
        k = max(1, int(round(self.elite_frac * self.population_size)))
        elites = order[:k]
        parents = elites[torch.randint(k, (self.population_size - k,), generator=self._rng,
                                       device=fitness.device)]
        out = {key: torch.cat([self._genes[key][elites], self._genes[key][parents]]).clone()
               for key in _GENES}
        self._mutate(out, start=k)
        return out

    def _mutate(self, genes: Dict[str, torch.Tensor], start: int) -> None:
        """Mutate rows `start:` in place: resample discrete genes at `morph_mutation_rate`, and
        perturb the continuous gait genes by Gaussian noise scaled to each one's own range."""
        g = self._rng
        dev = genes["counts"].device
        rate = self.morph_mutation_rate

        def resample(key: str, high: int) -> None:
            block = genes[key][start:]
            hit = torch.rand(block.shape, generator=g, device=dev) < rate
            fresh = torch.randint(0, high, block.shape, generator=g, device=dev)
            genes[key][start:] = torch.where(hit, fresh, block)

        if self._fixed is None:
            resample("counts", self.modlib.max_effectors + 1)
            resample("eff_sub", len(self.modlib.names(ModuleType.EFFECTOR)))
            resample("cap_sub", len(self.modlib.names(ModuleType.CAP)))
            self._repair(genes["counts"])

        def jitter(key: str, scale: float) -> None:
            block = genes[key][start:]
            noise = torch.randn(block.shape, generator=g, device=dev) * self.cpg_sigma * scale
            genes[key][start:] = block + noise

        lo_a, hi_a = self._AMP_RANGE
        lo_f, hi_f = self._FREQ_RANGE
        jitter("amp", hi_a - lo_a)
        jitter("freq", hi_f - lo_f)
        jitter("phase", _TWO_PI)
        genes["amp"].clamp_(0.0, 1.0)
        genes["freq"].clamp_(lo_f, hi_f)
        genes["phase"].remainder_(_TWO_PI)

    # ---- fixed morphologies ------------------------------------------------------------

    def apply_fixed_morphologies(self, bodies: List[Morphology]) -> None:
        """Evolve gaits only: every individual becomes one of `bodies`, and mutation stops touching
        the morphology genes.

        **The population is not resized.** `population_size` individuals still run, so fixing one
        body gives that body `population_size` independent gaits under selection at once -- which is
        the tiling default, and is what makes this a search rather than a repeated measurement.
        `envs_per_body` is untouched for the same reason.

        A loaded checkpoint's gait genes are kept, so refining starts from the population that was
        already evolved rather than from a fresh draw; only the bodies underneath them change. The
        best-so-far is cleared, though: its fitness was earned by a different body and would never
        be beaten, which would pin `control_policy` to a gait for a body no longer in play.
        """
        self._fixed = list(bodies)
        self._generation = 0
        self._best_fitness = -float("inf")
        self._best_genes = {}
        if self._genes:
            # A live population is re-bodied in place. `_bodies` reads `_fixed` from here on, so the
            # morphology genes need no rewrite -- they simply stop being read.
            self._evaluated = self._bodies(self._genes)

    # ---- artifacts -------------------------------------------------------------------

    def control_policy(self) -> ControlPolicy:
        """The best individual's gait. Genes are moved onto the live Task's device, since a
        checkpoint loaded with `map_location="cpu"` would otherwise hand it CPU actions."""
        dev = self.task.device if self.task is not None else self._best_genes["amp"].device
        amp, phase, freq = (self._best_genes[k].to(dev) for k in _CPG_GENES)
        return CPGControlPolicy(amp, phase, freq, self._dt, name="cpg_best")

    # ---- capabilities ----------------------------------------------------------------

    @provides(SPREAD_CONTROL)
    def sample_at_spread(self, spread: float, n: int) -> List[Morphology]:
        """Each slot of the committed design replaced, with probability `spread`, by the same slot
        of a body drawn uniformly over the grammar.

        Not the EA's own mutation operator, deliberately. Mutation redraws genes within the EA's
        encoding, which cannot reach uniform-over-the-grammar at any rate -- it always caps a chain,
        and its chain-length distribution is its own -- so an operator-based ladder would have a top
        end that means something different from every other algorithm's. The contract fixes both
        endpoints; this hits them exactly and is monotone between them.
        """
        if self._spread_rng is None:
            self._spread_rng = random.Random(self.seed)
        rng = self._spread_rng
        committed = self.morphology_generator().generate(1, deterministic=True)[0]
        out: List[Morphology] = []
        for _ in range(n):
            if spread <= 0.0:
                out.append(committed)
                continue
            wild = self.modlib.random_morphology(rng)
            chains = [list(wild[i]) if rng.random() < spread else list(committed[i])
                      for i in range(len(committed))]
            out.append(Morphology(chains) if any(chains) else wild)
        return out

    @property
    def config(self) -> dict:
        """Everything `__init__` takes that changes what a run does. `max_steps=None` means the
        Task's own episode length, which the record cannot resolve without a live Task, so it is
        recorded as given."""
        return {"population_size": self.population_size, "envs_per_body": self.envs_per_body,
                "generations": self.generations, "elite_frac": self.elite_frac,
                "morph_mutation_rate": self.morph_mutation_rate, "cpg_sigma": self.cpg_sigma,
                "max_steps": self.max_steps, "seed": self.seed}

    def morphology_generator(self) -> MorphologyGenerator:
        best = self._bodies({k: self._best_genes[k].unsqueeze(0) for k in _MORPH_GENES})[0]
        return PopulationMorphologyGenerator(self._bodies(self._genes), best, self._rng)

    def current_morphologies(self) -> Optional[List[Morphology]]:
        """The bodies the reported fitness belongs to, not the children just bred from them -- so the
        run tick's reward and its morphologies describe the same generation."""
        return self._evaluated

    # ---- checkpoints -----------------------------------------------------------------

    def checkpoint_payload(self) -> dict:
        payload = {f"pop_{k}": v for k, v in self._genes.items()}
        payload.update({f"best_{k}": v for k, v in self._best_genes.items()})
        # dt is the CPG's clock, so a policy cannot be reconstituted without it and no live Task is
        # guaranteed at load time.
        payload["dt"] = self._dt
        payload["generation"] = self._generation
        payload["best_fitness"] = self._best_fitness
        return payload

    def load_checkpoint_payload(self, payload: dict) -> None:
        self._genes = {k: payload[f"pop_{k}"] for k in _GENES}
        # Absent when a fixed-morphology phase was checkpointed before its first generation closed:
        # `apply_fixed_morphologies` clears the best-so-far, and nothing has replaced it yet.
        self._best_genes = ({k: payload[f"best_{k}"] for k in _GENES}
                            if f"best_{_GENES[0]}" in payload else {})
        self._dt = payload["dt"]
        self._generation = payload["generation"]
        self._best_fitness = payload["best_fitness"]
        if self._rng is None:
            dev = self._genes["counts"].device
            self._rng = torch.Generator(device=dev)
            self._rng.manual_seed(self.seed)
