"""The construction MDP a design is built through, and the graph a partial design is featurized as.

Ported in structure from RoboGrammar (`examples/design_search/design_search.py`,
`examples/graph_learning/Preprocessor.py`, `examples/graph_learning/RobotGrammarEnv.py`), MIT
licence, Copyright (c) 2020 Allan Zhao, Jie Xu, Mina Konakovic-Lukovic, Josephine Hughes, Andrew
Spielberg, Daniela Rus, Wojciech Matusik.

RoboGrammar's states are graphs and its actions are rewrite-rule applications. We are not porting
their grammar (a decision, not an omission -- we design over our own module libraries), so the
question is what replaces it. The answer is in their `transite`:

    applicable_matches = list(get_applicable_matches(self.rules[action], state))
    next_state = rd.apply_rule(self.rules[action], state, applicable_matches[0])

Always the FIRST match. Their action chooses *what* to build, never *where* -- the where is fixed by
a canonical traversal order. So the MDP is: walk the attachment slots in order, and at the slot
currently open, either extend its chain, cap it, or leave it. That is a faithful mapping of what
their action space actually does, expressed over a module library instead of a rewrite grammar.

Their non-terminal nodes -- a node whose shape is not yet decided -- become a **placeholder** node
on every slot that is still open. Terminality is then the same test it is for them: no placeholders
left. It matters that a placeholder is a real node rather than an absence, for the same reason it
does in their graphs: "this limb is finished and short" and "this limb is unfinished" are different
states and the value function has to be able to tell them apart.
"""
from typing import List, Tuple

import numpy as np

from codesigner.interfaces.modlib import Module, ModuleLibrary, ModuleType, Morphology

# Node kinds, in the order their one-hot block is laid out.
_ROOT, _EFFECTOR, _CAP, _PLACEHOLDER = range(4)
_N_KIND = 4


class DesignState:
    """A partial design: a chain per slot, and which slots are finished.

    Immutable and hashable, because that is what the two tables downstream need -- `V_hat` is keyed
    by state and the states pool is deduplicated by it, exactly as in the original.
    """

    __slots__ = ("chains", "closed", "_hash")

    def __init__(self, chains: Tuple[Tuple[str, ...], ...], closed: Tuple[bool, ...]):
        self.chains = chains
        self.closed = closed
        self._hash = hash((chains, closed))

    @classmethod
    def initial(cls, n_slots: int) -> "DesignState":
        return cls(tuple(() for _ in range(n_slots)), tuple(False for _ in range(n_slots)))

    @property
    def slot(self) -> int:
        """The slot currently being built; `len(chains)` once every slot is closed."""
        for i, c in enumerate(self.closed):
            if not c:
                return i
        return len(self.closed)

    @property
    def is_terminal(self) -> bool:
        return all(self.closed)

    def __hash__(self):
        return self._hash

    def __eq__(self, other):
        return (isinstance(other, DesignState) and self.chains == other.chains
                and self.closed == other.closed)

    def __repr__(self):
        parts = [f"{i}:{'+'.join(c) if c else '-'}{'' if self.closed[i] else '?'}"
                 for i, c in enumerate(self.chains)]
        return f"DesignState({' '.join(parts)})"


class DesignMDP:
    """The action space and transition function over `DesignState`, plus its graph featurization.

    Actions, in index order: one per effector, one per cap, then SKIP.

      effector -- append it to the open slot's chain, leaving the slot open.
      cap      -- append it and CLOSE the slot. Any cap is a terminal, which is what makes the
                  action space finite without a separate "stop" per limb.
      skip     -- close the open slot as it stands, uncapped. On an empty chain that is how a slot
                  is left bare, and it is the only way to build a robot with fewer than `n_slots`
                  limbs.

    Adaptation: RoboGrammar's `is_valid` rejects a design whose links self-intersect, by building
    the robot and running `presimulate` on it. We have no equivalent cheap geometric check -- the
    library's emitter validates connectivity, not intersection -- so validity here is only that the
    body has at least one limb. Their rejection-and-resample loop is otherwise ported as-is.
    """

    def __init__(self, library: ModuleLibrary):
        self.library = library
        self.effectors = library.names(ModuleType.EFFECTOR)
        self.caps = library.names(ModuleType.CAP)
        self.n_slots = library.n_slots
        self.max_depth = library.max_depth
        self.max_effectors = library.max_effectors

        self.n_actions = len(self.effectors) + len(self.caps) + 1
        self.skip_action = self.n_actions - 1

        # The longest any rollout can run: every slot takes at most `max_effectors` extensions plus
        # one closing action. RoboGrammar's `--depth` is the same quantity for their grammar.
        self.max_depth_actions = self.n_slots * (self.max_effectors + 1)

        # Feature layout, declared once so `n_features` cannot drift from `featurize`.
        self._vocab = tuple(d.name for d in library.definitions)
        self._vocab_index = {n: i for i, n in enumerate(self._vocab)}
        self.n_features = (len(self._vocab) + _N_KIND + self.n_slots + self.max_depth + 3)
        self.max_nodes = 1 + self.n_slots * self.max_depth

    # ---- the MDP ---------------------------------------------------------------

    def initial_state(self) -> DesignState:
        return DesignState.initial(self.n_slots)

    def available_actions(self, state: DesignState) -> np.ndarray:
        """Action indices legal in `state`. Empty at a terminal state.

        Two masks, at the two ends of a chain:

          depth 0                -- effectors and skip, no caps. A cap on its own is not a limb: it
                                    carries no joint, and a library is entitled to emit nothing at
                                    all for one (`simple`'s `bare` does exactly that), which leaves
                                    a slot that is occupied and empty at the same time.
          depth `max_effectors`  -- caps and skip, no effectors. The library reserves the deepest
                                    position of a chain for a cap.

        Skip is available throughout, so a slot can always be closed and no rollout can dead-end.
        """
        if state.is_terminal:
            return np.zeros(0, dtype=np.int64)
        depth = len(state.chains[state.slot])
        n_eff = len(self.effectors)
        if depth == 0:
            return np.append(np.arange(n_eff, dtype=np.int64), self.skip_action)
        if depth >= self.max_effectors:
            return np.arange(n_eff, self.n_actions, dtype=np.int64)
        return np.arange(self.n_actions, dtype=np.int64)

    def transition(self, state: DesignState, action: int) -> DesignState:
        s = state.slot
        chains, closed = list(state.chains), list(state.closed)
        if action == self.skip_action:
            closed[s] = True
        elif action < len(self.effectors):
            chains[s] = chains[s] + (self.effectors[action],)
        else:
            chains[s] = chains[s] + (self.caps[action - len(self.effectors)],)
            closed[s] = True
        return DesignState(tuple(chains), tuple(closed))

    def is_valid(self, state: DesignState) -> bool:
        return state.is_terminal and any(state.chains)

    def to_morphology(self, state: DesignState) -> Morphology:
        """The built body. Only meaningful at a terminal state."""
        chains = {}
        for slot, chain in enumerate(state.chains):
            if not chain:
                continue
            cap = chain[-1] if chain[-1] in self.caps else None
            effectors = chain[:-1] if cap is not None else chain
            chains[slot] = (list(effectors), cap)
        return Morphology.from_names(self.library, chains)

    def from_morphology(self, morphology: Morphology) -> DesignState:
        """The terminal state that builds `morphology` -- the inverse of `to_morphology`.

        What lets `V` be asked about a body that came from somewhere else: a perturbed design, a
        uniform draw, another algorithm's committed design. Every slot is closed, since a finished
        body is a terminal state by definition.
        """
        chains = tuple(tuple(m.name for m in chain) for chain in morphology.chains)
        return DesignState(chains, tuple(True for _ in chains))

    # ---- featurization ---------------------------------------------------------

    def featurize(self, state: DesignState) -> Tuple[np.ndarray, np.ndarray]:
        """`(adj, features)` for one state: `(n, n)` symmetric adjacency and `(n, f)` node features.

        Node 0 is the root; each module is a node under its slot's chain; each OPEN slot carries one
        trailing placeholder. Edges are parent-child and, as in `Preprocessor.preprocess`, the
        matrix is symmetrized -- `adj = adj + adj.T` -- so message passing runs both ways.

        Features are STRUCTURAL plus library scalars, and carry no forward kinematics. RoboGrammar's
        `featurize_link` reads a link's radius, density, friction and world pose; ours cannot, and
        the reason is a boundary rather than an oversight -- `ModuleDefinition.geometry` is an opaque
        `object` the backend never interprets, so radius and density are not reachable from here at
        all. World placement is dropped for a better reason: for a library whose slots are fixed, a
        module's pose is a function of `(slot, depth)`, both of which are one-hot in the features
        already, so the FK loop would compute a quantity the network is already given.
        """
        feats: List[np.ndarray] = [self._node(None, _ROOT, -1, -1)]
        edges: List[Tuple[int, int]] = []
        for slot, chain in enumerate(state.chains):
            parent = 0
            for depth, name in enumerate(chain):
                kind = _CAP if name in self.caps else _EFFECTOR
                feats.append(self._node(name, kind, slot, depth))
                edges.append((parent, len(feats) - 1))
                parent = len(feats) - 1
            if not state.closed[slot]:
                feats.append(self._node(None, _PLACEHOLDER, slot, len(chain)))
                edges.append((parent, len(feats) - 1))
                parent = len(feats) - 1

        n = len(feats)
        adj = np.zeros((n, n), dtype=np.float32)
        for p, c in edges:
            adj[p, c] += 1.0
        return adj + adj.T, np.stack(feats)

    def _node(self, name, kind: int, slot: int, depth: int) -> np.ndarray:
        f = np.zeros(self.n_features, dtype=np.float32)
        off = 0
        if name is not None:
            f[self._vocab_index[name]] = 1.0
        off += len(self._vocab)
        f[off + kind] = 1.0
        off += _N_KIND
        if 0 <= slot < self.n_slots:
            f[off + slot] = 1.0
        off += self.n_slots
        if 0 <= depth < self.max_depth:
            f[off + depth] = 1.0
        off += self.max_depth
        if name is not None:
            d = self.library.modules[name]
            # The library scalars reachable through the interface rather than through the opaque
            # geometry: how long the module is, and how far its joint travels. A module's joint AXIS
            # would belong here too and cannot be had -- it lives inside `geometry`, which is typed
            # `object` precisely so nothing generic reads it. A multi-DOF module reports its first
            # joint only; every module in `simple` has one. Caps have no joint and stay at zero,
            # which the type one-hot already distinguishes from a joint that happens not to travel.
            f[off] = self.library.module_length(Module(d))
            if d.joint_limits:
                f[off + 1], f[off + 2] = d.joint_limits[0]
        return f

    def featurize_batch(self, states) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """`(adj, features, mask)` for a batch, padded to the batch's OWN widest graph.

        Per-minibatch padding is the original's (`heuristic_search_algo_mpc.py` recomputes
        `max_nodes` over each minibatch before calling `pad_graph`). `self.max_nodes` sizes the
        network's pooling schedule and nothing else.
        """
        graphs = [self.featurize(s) for s in states]
        width = max(f.shape[0] for _, f in graphs)
        b = len(graphs)
        adj = np.zeros((b, width, width), dtype=np.float32)
        feat = np.zeros((b, width, self.n_features), dtype=np.float32)
        mask = np.zeros((b, width), dtype=bool)
        for i, (a, f) in enumerate(graphs):
            k = f.shape[0]
            adj[i, :k, :k] = a
            feat[i, :k] = f
            mask[i, :k] = True
        return adj, feat, mask
