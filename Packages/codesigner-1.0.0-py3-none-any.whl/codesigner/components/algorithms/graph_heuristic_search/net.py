"""The DiffPool value network, ported from RoboGrammar.

Ported from RoboGrammar (`examples/graph_learning/Net.py`), MIT licence, Copyright (c) 2020 Allan
Zhao, Jie Xu, Mina Konakovic-Lukovic, Josephine Hughes, Andrew Spielberg, Daniela Rus, Wojciech
Matusik. `DenseSAGEConv` and `dense_diff_pool` are ported from PyTorch Geometric (MIT licence,
Copyright (c) 2023 PyG Team), which their `Net` imports.

`V(design) -> scalar`: a graph in, the expected reward of the design it describes out. It is
coarsened twice by learned soft clustering (DiffPool), then mean-pooled and read out through two
linear layers.

The two convolutions are ported rather than depended on. torch_geometric is a large dependency, its
build is tied to the torch version, and what is needed of it here is about forty lines of dense
tensor algebra with no sparse kernels involved -- the graphs are padded to at most 33 nodes.

Both `dense_diff_pool` losses are returned, and the search discards them: `heuristic_search_algo_mpc`
trains on `F.mse_loss(output[:, 0], train_reward)` alone. That is theirs, not a slip on the way over.
"""
import torch
import torch.nn.functional as F
from math import ceil

_EPS = 1e-15


class DenseSAGEConv(torch.nn.Module):
    """GraphSAGE convolution over a dense adjacency. PyTorch Geometric's `DenseSAGEConv`.

    Mean-aggregates each node's neighbours, then adds a separate projection of the node itself, so a
    node's own features survive the aggregation instead of being averaged into it.
    """

    def __init__(self, in_channels: int, out_channels: int, normalize: bool = False,
                 bias: bool = True):
        super().__init__()
        self.normalize = normalize
        self.lin_rel = torch.nn.Linear(in_channels, out_channels, bias=bias)
        self.lin_root = torch.nn.Linear(in_channels, out_channels, bias=False)
        self.reset_parameters()

    def reset_parameters(self):
        self.lin_rel.reset_parameters()
        self.lin_root.reset_parameters()

    def forward(self, x, adj, mask=None):
        # (B, N, F) x, (B, N, N) adj, (B, N) mask
        out = torch.matmul(adj, x)
        out = out / adj.sum(dim=-1, keepdim=True).clamp(min=1)
        out = self.lin_rel(out) + self.lin_root(x)
        if self.normalize:
            out = F.normalize(out, p=2.0, dim=-1)
        if mask is not None:
            out = out * mask.view(out.shape[0], out.shape[1], 1).to(x.dtype)
        return out


def dense_diff_pool(x, adj, s, mask=None, normalize: bool = True):
    """Coarsen a graph by a learned soft assignment. PyTorch Geometric's `dense_diff_pool`.

    `s` is `(B, N, C)` logits assigning each of N nodes to each of C clusters. Softmaxed over
    clusters, it becomes the projection that turns N nodes into C: `X' = S^T X`, `A' = S^T A S`.

    Returns the coarsened `(x, adj)` and DiffPool's two auxiliary losses -- link prediction
    (`||A - S S^T||_F`, the assignment should respect the edges) and assignment entropy (each node
    should commit to a cluster). Both are the paper's; the search that uses this network ignores
    them.
    """
    s = torch.softmax(s, dim=-1)
    if mask is not None:
        m = mask.view(x.shape[0], x.shape[1], 1).to(x.dtype)
        x, s = x * m, s * m

    out = torch.matmul(s.transpose(1, 2), x)
    out_adj = torch.matmul(torch.matmul(s.transpose(1, 2), adj), s)

    link_loss = adj - torch.matmul(s, s.transpose(1, 2))
    link_loss = torch.norm(link_loss, p=2)
    if normalize:
        link_loss = link_loss / adj.numel()
    ent_loss = (-s * torch.log(s + _EPS)).sum(dim=-1).mean()
    return out, out_adj, link_loss, ent_loss


class GNN(torch.nn.Module):
    """Three SAGE convolutions, their outputs concatenated. RoboGrammar's `GNN`.

    `lin=True` projects the concatenation back down to `out_channels`; `lin=False` leaves it at
    `2 * hidden + out`, which is what the next stage's `3 * 64` input widths are. `add_loop` writes
    ones onto the adjacency diagonal so a node aggregates itself as a neighbour too.

    `batch_normalization` is plumbed through because theirs is, and is off everywhere in `Net` --
    `Net.__init__` sets `batch_normalization = False` and passes it to every stage.
    """

    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int,
                 normalize: bool = False, batch_normalization: bool = False,
                 add_loop: bool = False, lin: bool = True):
        super().__init__()
        self.add_loop = add_loop
        self.batch_normalization = batch_normalization

        self.conv1 = DenseSAGEConv(in_channels, hidden_channels, normalize)
        self.conv2 = DenseSAGEConv(hidden_channels, hidden_channels, normalize)
        self.conv3 = DenseSAGEConv(hidden_channels, out_channels, normalize)

        if batch_normalization:
            self.bn1 = torch.nn.BatchNorm1d(hidden_channels)
            self.bn2 = torch.nn.BatchNorm1d(hidden_channels)
            self.bn3 = torch.nn.BatchNorm1d(out_channels)

        self.lin = (torch.nn.Linear(2 * hidden_channels + out_channels, out_channels)
                    if lin else None)

    def bn(self, i, x):
        batch_size, num_nodes, num_features = x.size()
        x = getattr(self, f"bn{i}")(x.view(-1, num_features))
        return x.view(batch_size, num_nodes, num_features)

    def forward(self, x, adj, mask=None):
        if self.add_loop:
            n = adj.size(1)
            adj = adj.clone()
            idx = torch.arange(n, dtype=torch.long, device=adj.device)
            adj[:, idx, idx] = 1

        if self.batch_normalization:
            x1 = self.bn(1, F.relu(self.conv1(x, adj, mask)))
            x2 = self.bn(2, F.relu(self.conv2(x1, adj, mask)))
            x3 = self.bn(3, F.relu(self.conv3(x2, adj, mask)))
        else:
            x1 = F.relu(self.conv1(x, adj, mask))
            x2 = F.relu(self.conv2(x1, adj, mask))
            x3 = F.relu(self.conv3(x2, adj, mask))

        out = torch.cat([x1, x2, x3], dim=-1)
        return F.relu(self.lin(out)) if self.lin is not None else out


class Net(torch.nn.Module):
    """The value function. RoboGrammar's `Net`, unchanged in shape.

    Two DiffPool levels at their 0.25 ratio, so `max_nodes` nodes become `ceil(0.25 * max_nodes)`
    clusters and then a quarter of that again, followed by a mean over what is left and a two-layer
    readout.

    `max_nodes` sizes only that pooling schedule -- the graphs themselves are padded per minibatch
    to the minibatch's own widest -- so it is set from what a design can actually contain,
    `1 + n_slots * max_depth`. Their default is 40 with a comment saying it is a legacy value kept to
    match a pretrained checkpoint's input ("TODO: use 80 to fit the input of trained MPC GNN, use
    args.depth * 3 later for real mpc"), which is exactly the derivation this replaces.

    Returns `(value, link_loss, entropy_loss)` -- three values, of which the search uses the first.
    """

    def __init__(self, max_nodes: int, num_channels: int, num_outputs: int = 1):
        super().__init__()
        bn = False

        num_nodes = ceil(0.25 * max_nodes)
        self.gnn1_pool = GNN(num_channels, 64, num_nodes, batch_normalization=bn, add_loop=True)
        self.gnn1_embed = GNN(num_channels, 64, 64, batch_normalization=bn, add_loop=True, lin=False)

        num_nodes = ceil(0.25 * num_nodes)
        self.gnn2_pool = GNN(3 * 64, 64, num_nodes, batch_normalization=bn)
        self.gnn2_embed = GNN(3 * 64, 64, 64, batch_normalization=bn, lin=False)

        self.gnn3_embed = GNN(3 * 64, 64, 64, batch_normalization=bn, lin=False)

        self.lin1 = torch.nn.Linear(3 * 64, 64)
        self.lin2 = torch.nn.Linear(64, num_outputs)

    def forward(self, x, adj, mask=None):
        s = self.gnn1_pool(x, adj, mask)
        x = self.gnn1_embed(x, adj, mask)
        x, adj, l1, e1 = dense_diff_pool(x, adj, s, mask)

        s = self.gnn2_pool(x, adj)
        x = self.gnn2_embed(x, adj)
        x, adj, l2, e2 = dense_diff_pool(x, adj, s)

        x = self.gnn3_embed(x, adj)
        x = x.mean(dim=1)
        x = F.relu(self.lin1(x))
        return self.lin2(x), l1 + l2, e1 + e2
