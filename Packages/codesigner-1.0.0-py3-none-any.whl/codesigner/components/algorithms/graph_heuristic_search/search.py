"""Graph Heuristic Search, ported from RoboGrammar.

Ported from RoboGrammar (`examples/graph_learning/heuristic_search_algo_mpc.py`,
`examples/graph_learning/states_pool.py`, `examples/design_search/design_search.py`), MIT licence,
Copyright (c) 2020 Allan Zhao, Jie Xu, Mina Konakovic-Lukovic, Josephine Hughes, Andrew Spielberg,
Daniela Rus, Wojciech Matusik. From "RoboGrammar: Graph Grammar for Terrain-Optimized Robot Design"
(SIGGRAPH Asia 2020).

The loop, one epoch of it:

  1. Decay two independent epsilons. `eps` is how often a construction step is taken at random
     rather than by the value function; `eps_sample` is how often the epoch settles for a single
     candidate design instead of the best of `num_samples`. Both exponential, both from 1 to 0.
  2. Build candidate designs by epsilon-greedy rollout through the construction MDP, scoring each
     completed one with `V` and keeping the best.
  3. Evaluate the winner for real -- MPPI plans a gait for it and the episode's mean reward is the
     design's reward.
  4. `V_hat[s] = max(V_hat[s], reward)` for EVERY state on the path that built it, terminal or not.
     This is the heuristic the search is named for: a partial design inherits the best result
     anything downstream of it ever achieved, so `V` learns to score an unfinished body by its
     potential rather than by what it currently is.
  5. Regress `V` onto `V_hat` by MSE, over minibatches from a pool of every state ever seen.

The one structural adaptation is batching, and it is the same one MPPI needed. RoboGrammar evaluates
ONE design per epoch, because a design evaluation is a CPU MPC run. Ours is a GPU simulation holding
`n_morphs` bodies at once, and evaluating one of them would leave the rest idle -- so an epoch here
selects `n_morphs` designs by `n_morphs` independent runs of steps 1-2, and steps 3-5 process all of
them together. Every ported constant keeps its meaning; what changes is that one `run()` covers
`n_morphs` of their epochs. Budget accordingly: `iterations` epochs is `iterations * n_morphs`
design evaluations, not `iterations`.
"""
import math
import random
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F

from codesigner.components.algorithms.control.mppi import MPPIPolicy
from codesigner.components.algorithms.graph_heuristic_search.mdp import DesignMDP, DesignState
from codesigner.components.algorithms.graph_heuristic_search.net import Net
from codesigner.interfaces.algorithm import Algorithm, ControlPolicy, MorphologyGenerator
from codesigner.interfaces.modlib import Morphology
from codesigner.metrics.capability import DESIGN_QUALITY_PREDICTOR, SPREAD_CONTROL, provides
from codesigner.progress import Progress


class StatesPool:
    """A ring buffer of every distinct state seen, sampled uniformly. RoboGrammar's `StatesPool`.

    Not a replay buffer in the RL sense -- entries hold no transition and no reward. The reward for
    a state is looked up in `V_hat` at training time, so a state's target improves as the search
    finds better designs beneath it without the pool being touched.
    """

    def __init__(self, capacity: int = 10_000_000):
        self.capacity = capacity
        self.pool: List[DesignState] = []
        self.position = 0

    def push(self, state: DesignState) -> None:
        if len(self.pool) < self.capacity:
            self.pool.append(None)
        self.pool[self.position] = state
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size: int) -> List[DesignState]:
        return random.sample(self.pool, batch_size)

    def __len__(self) -> int:
        return len(self.pool)


class GHSMorphologyGenerator(MorphologyGenerator):
    """The search's designer: greedy descent through the MDP under the learned `V`.

    A deterministic draw takes the argmax action at every step, which is the design the value
    function currently believes in. A stochastic draw uses the epoch's own epsilon, so the spread it
    shows is the search's live exploration rather than noise bolted on for the sake of the contract.
    """

    def __init__(self, mdp: DesignMDP, value: Net, device, eps: float = 0.0,
                 name: str = "ghs_greedy"):
        super().__init__(name=name)
        self._mdp = mdp
        self._value = value
        self._device = device
        self._eps = eps

    def generate(self, n: int, deterministic: bool = False) -> List[Morphology]:
        eps = 0.0 if deterministic else self._eps
        out = []
        while len(out) < n:
            state, _ = _rollout(self._mdp, self._value, self._device, eps, rng=random)
            if self._mdp.is_valid(state):
                out.append(self._mdp.to_morphology(state))
        return out


def _predict(mdp: DesignMDP, value: Net, device, states: List[DesignState]) -> np.ndarray:
    """`V` over a batch of states. `predict_batch` in the original."""
    adj, feat, mask = mdp.featurize_batch(states)
    with torch.no_grad():
        out, _, _ = value(torch.as_tensor(feat, device=device),
                          torch.as_tensor(adj, device=device),
                          torch.as_tensor(mask, device=device))
    return out[:, 0].cpu().numpy()


def _select_action(mdp: DesignMDP, value: Net, device, state: DesignState, eps: float, rng):
    """Epsilon-greedy over the successors of `state`. `select_action` in the original.

    Greedy means evaluating `V` at every state the available actions lead TO, not at the current
    state -- there is no action head, so a one-step lookahead is what makes `V` a policy.
    """
    actions = mdp.available_actions(state)
    if len(actions) == 0:
        return None
    if rng.random() > eps:
        values = _predict(mdp, value, device, [mdp.transition(state, a) for a in actions])
        return int(actions[int(np.argmax(values))])
    return int(actions[rng.randrange(len(actions))])


def _rollout(mdp: DesignMDP, value: Net, device, eps: float, rng
             ) -> Tuple[DesignState, List[DesignState]]:
    """Build one design epsilon-greedily; return the final state and every state on the way."""
    state = mdp.initial_state()
    seq = [state]
    for _ in range(mdp.max_depth_actions):
        action = _select_action(mdp, value, device, state, eps, rng)
        if action is None:
            break
        state = mdp.transition(state, action)
        seq.append(state)
        if state.is_terminal:
            break
    return state, seq


class GraphHeuristicSearch(Algorithm):
    """RoboGrammar's Graph Heuristic Search over a CoDesigner module library.

    Designs bodies; does not learn a controller. The controller is MPPI, which replans from scratch
    for whatever body it is handed, so the artifact this hands back is the planned gait of the best
    design rather than a trained network -- see `control_policy`.
    """

    def __init__(
        self,
        n_morphs: int = 16,
        samples_per_morph: int = 256,
        iterations: int = 2000,
        num_samples: int = 16,
        num_eval: int = 1,
        opt_iter: int = 25,
        batch_size: int = 32,
        lr: float = 1e-4,
        eps_start: float = 1.0,
        eps_end: float = 0.0,
        eps_decay: float = 0.5,
        eps_sample_start: float = 1.0,
        eps_sample_end: float = 0.0,
        eps_sample_decay: float = 0.5,
        states_pool_capacity: int = 10_000_000,
        result_bound: float = 400.0,
        invalid_reward: float = -2.0,
        episode_len: int = 200,
        interval: int = 4,
        horizon: int = 16,
        discount_factor: float = 0.99,
        kappa: float = 1.0,
        seed: int = 0,
        name: str = "graph_heuristic_search",
        description: str = "RoboGrammar's GHS: a DiffPool value function over partial designs, "
                           "with MPPI for control",
    ):
        super().__init__(name=name, description=description)
        self.n_morphs = n_morphs
        self.samples_per_morph = samples_per_morph
        self.iterations = iterations
        self.num_samples = num_samples
        self.num_eval = num_eval
        self.opt_iter = opt_iter
        self.batch_size = batch_size
        self.lr = lr
        self.eps_start, self.eps_end, self.eps_decay = eps_start, eps_end, eps_decay
        self.eps_sample_start = eps_sample_start
        self.eps_sample_end = eps_sample_end
        self.eps_sample_decay = eps_sample_decay
        # Designs scoring above this are rejected as physically implausible -- a body that exploits
        # the simulator rather than walking. Theirs is 10.0 against an objective bounded near 1 per
        # step; ours is Ant's reward, on a different scale entirely, so the NUMBER is recalibrated
        # while the guard is theirs. Derive it from a baseline run before trusting the default.
        self.result_bound = result_bound
        self.invalid_reward = invalid_reward
        self.episode_len = episode_len
        self.interval = interval
        self.horizon = horizon
        self.discount_factor = discount_factor
        self.kappa = kappa
        self.seed = seed

        self._epoch = 0
        self._mdp: Optional[DesignMDP] = None
        self._V: Optional[Net] = None
        self._optimizer: Optional[torch.optim.Optimizer] = None
        self._V_hat: Dict[DesignState, float] = {}
        self._pool = StatesPool(states_pool_capacity)
        self._seen = set()
        self._rng = random.Random(seed)
        self._best_reward = -float("inf")
        self._best_design: Optional[DesignState] = None
        self._best_sequence: Optional[torch.Tensor] = None
        self._evaluated: Optional[List[Morphology]] = None
        self._eps = eps_start
        self._fixed: Optional[List[Morphology]] = None
        self._started = False

    # ---- the loop --------------------------------------------------------------------

    def run(self) -> Tuple[float, ControlPolicy, MorphologyGenerator]:
        # On whether the Task is standing, not on whether the MDP exists: `refine_control` builds
        # both the MDP and `V` while loading a payload, long before there is a sim to resample.
        if not self._started:
            self._start()
        if self._fixed is not None:
            return self._run_fixed()

        eps, eps_sample = self._schedules()
        self._eps = eps
        self._V.eval()

        # A design's whole construction path, per morphology group.
        selected: List[DesignState] = []
        paths: List[List[DesignState]] = []
        n_candidates = 1 if self._rng.random() < eps_sample else self.num_samples
        for _ in range(self.n_morphs):
            best_state, best_path, best_value = None, None, -float("inf")
            for _ in range(n_candidates):
                # Their `while not valid` loop: an invalid design is thrown away and resampled, and
                # only the count of them is kept. Bounded here, since ours can only fail by being
                # empty and a run of pure skips is unlikely but not impossible.
                for _ in range(100):
                    state, path = _rollout(self._mdp, self._V, self._device, eps, self._rng)
                    if self._mdp.is_valid(state):
                        break
                value = float(_predict(self._mdp, self._V, self._device, [state])[0])
                if value > best_value:
                    best_state, best_path, best_value = state, path, value
            selected.append(best_state)
            paths.append(best_path)

        rewards = self._evaluate(selected)

        # V_hat over every state on every path, and the pool over the distinct ones.
        for path, reward in zip(paths, rewards):
            for state in path:
                self._V_hat[state] = max(self._V_hat.get(state, -float("inf")), reward)
                if state not in self._seen:
                    self._seen.add(state)
                    self._pool.push(state)

        loss = self._optimize()

        top = int(np.argmax(rewards))
        if rewards[top] > self._best_reward:
            self._best_reward = float(rewards[top])
            self._best_design = selected[top]
            self._best_sequence = self._last_sequence[top:top + 1].clone()

        self._epoch += 1
        self.report_iteration(Progress(tick=self._epoch, reward=float(rewards[top]),
                                       best_reward=self._best_reward,
                                       morphologies=self._evaluated))
        print(f"[ghs] epoch {self._epoch} eps {eps:.3f} eps_sample {eps_sample:.3f} "
              f"candidates {n_candidates} reward {float(rewards[top]):+.2f} "
              f"best {self._best_reward:+.2f} loss {loss:.4f} pool {len(self._pool)}")
        return float(rewards[top]), self.control_policy(), self.morphology_generator()

    def is_finished(self) -> bool:
        return self._epoch >= self.iterations

    # ---- fixed morphologies ------------------------------------------------------------

    def apply_fixed_morphologies(self, bodies: List[Morphology]) -> None:
        """Stop designing; keep planning. `run` then skips the construction MDP entirely.

        Everything the search learns is about DESIGNS -- `V` scores partial bodies, `V_hat` records
        what was ever achieved beneath a state, the pool holds states. With the body given, none of
        it has an input: there is no construction path to credit and no candidate to rank. So the
        fixed phase touches none of them, and one `run()` is `num_eval` MPPI episodes over the fixed
        bodies, keeping the best sequence found. Repeated runs are repeated planning attempts, which
        is the only thing MPPI can be made better at -- it learns nothing between them.

        **The Task is not resized.** `n_morphs` groups of `samples_per_morph` envs still run, so the
        fixed set is tiled across the groups and MPPI's sample count -- which IS `envs_per_morph` --
        stays exactly what it was tuned at. Fixing one body therefore gives `n_morphs` independent
        planning attempts at the tuned sample count, not one attempt at `n_morphs` times it.

        The best-so-far is cleared: a reward and a gait earned by a different design would never be
        beaten, and `control_policy` would keep handing back a sequence planned for a body that is
        no longer being built.
        """
        self._fixed = list(bodies)
        self._epoch = 0
        self._best_reward = -float("inf")
        self._best_design = None
        self._best_sequence = None

    def _run_fixed(self) -> Tuple[float, ControlPolicy, MorphologyGenerator]:
        """One run of the fixed-morphology phase: plan for the fixed bodies and keep the best."""
        bodies = [self._fixed[i % len(self._fixed)] for i in range(self.n_morphs)]
        rewards = self._evaluate_bodies(bodies)

        top = int(np.argmax(rewards))
        if rewards[top] > self._best_reward:
            self._best_reward = float(rewards[top])
            self._best_sequence = self._last_sequence[top:top + 1].clone()

        self._epoch += 1
        self.report_iteration(Progress(tick=self._epoch, reward=float(rewards[top]),
                                       best_reward=self._best_reward,
                                       morphologies=self._evaluated))
        print(f"[ghs] fixed-morphology run {self._epoch} reward {float(rewards[top]):+.2f} "
              f"best {self._best_reward:+.2f}")
        return float(rewards[top]), self.control_policy(), self.morphology_generator()

    def _schedules(self) -> Tuple[float, float]:
        """The two exponential decays, verbatim from the original's `exp-decay` branch."""
        t = self._epoch / self.iterations
        eps = self.eps_end + (self.eps_start - self.eps_end) * math.exp(-t / self.eps_decay)
        eps_sample = (self.eps_sample_end + (self.eps_sample_start - self.eps_sample_end)
                      * math.exp(-t / self.eps_sample_decay))
        return eps, eps_sample

    def _start(self) -> None:
        """Stand up the MDP, the network and the Task.

        The env count is the algorithm's (D7): `n_morphs * samples_per_morph`, because the sample
        count MPPI plans with is `envs_per_morph` and nothing else can set it.
        """
        random.seed(self.seed)
        np.random.seed(self.seed)
        torch.manual_seed(self.seed)

        # A loaded payload has already built these; rebuilding would discard the weights it
        # restored. `.to` still runs, since a checkpoint mapped to CPU leaves `V` there.
        if self._mdp is None:
            self._mdp = DesignMDP(self.modlib)
        self._device = self.task.device
        if self._V is None:
            self._V = Net(max_nodes=self._mdp.max_nodes, num_channels=self._mdp.n_features,
                          num_outputs=1)
            self._optimizer = torch.optim.Adam(self._V.parameters(), lr=self.lr)
        self._V = self._V.to(self._device)

        if self._fixed is not None:
            seed_bodies = [self._fixed[i % len(self._fixed)] for i in range(self.n_morphs)]
        else:
            seed_bodies = [self._mdp.to_morphology(s) for s in self._seed_designs()]
        self.task.setup(self.modlib, self.n_morphs * self.samples_per_morph, self.n_morphs,
                        seed_bodies, seed=self.seed)
        self._evaluated = seed_bodies
        self._planner = MPPIPolicy(self.task, interval=self.interval, horizon=self.horizon,
                                   kappa=self.kappa, discount_factor=self.discount_factor,
                                   seed=self.seed)
        self._started = True

    def _seed_designs(self) -> List[DesignState]:
        """`n_morphs` valid designs to size the Task with, drawn uniformly. `V` is untrained at this
        point, so a greedy rollout would give `n_morphs` copies of one arbitrary design."""
        out = []
        while len(out) < self.n_morphs:
            state, _ = _rollout(self._mdp, self._V, self._device, 1.0, self._rng)
            if self._mdp.is_valid(state):
                out.append(state)
        return out

    # ---- evaluation ------------------------------------------------------------------

    def _evaluate(self, designs: List[DesignState]) -> np.ndarray:
        """Plan a gait for every design at once and score it. `RobotGrammarEnv.get_reward`.

        The score is the episode's MEAN reward, as theirs is (`simulate` returns
        `np.mean(rewards)`), so episode length does not scale it. A design scoring above
        `result_bound` is rejected to `invalid_reward`, which is their guard against a body that has
        found a hole in the simulator rather than a gait -- ported with the constant recalibrated,
        since the bound is a property of the objective's scale and Ant's is not theirs.

        `num_eval` repeats and takes the max, which is theirs too: MPPI is seeded per run, so a
        design that plans badly once is given another chance rather than being written off.
        """
        return self._evaluate_bodies([self._mdp.to_morphology(d) for d in designs])

    def _evaluate_bodies(self, bodies: List[Morphology]) -> np.ndarray:
        """The half of `_evaluate` that needs no design: plan for `bodies` and score them.

        Split out for the fixed-morphology phase, which holds Morphologies and no construction path
        -- there is no state to featurize, so `V` and `V_hat` have nothing to be told.
        """
        self._evaluated = list(bodies)
        self.task.resample(self._evaluated)

        best = np.full(len(bodies), -np.inf)
        best_seq = None
        for _ in range(self.num_eval):
            rewards, sequence = self._episode()
            if best_seq is None:
                best_seq = sequence.clone()
            better = rewards > best
            best_seq[better] = sequence[better]
            best = np.maximum(best, rewards)

        self._last_sequence = best_seq
        rejected = best > self.result_bound
        if rejected.any():
            print(f"[ghs] {int(rejected.sum())} design(s) above result_bound "
                  f"{self.result_bound}, rejected to {self.invalid_reward}")
        return np.where(rejected, self.invalid_reward, best)

    def _episode(self) -> Tuple[np.ndarray, torch.Tensor]:
        """One MPPI-planned episode over every morphology group. Returns per-design mean reward and
        the committed input sequences."""
        self.task.reset()
        self._planner.reset()
        total = torch.zeros(self.task.total_num_envs, device=self._device)
        obs = self.task.obs_buf
        steps = self.episode_len * self.interval
        for _ in range(steps):
            obs, rew, _, _, _ = self.task.step(self._planner.act(obs))
            total += rew
        self._planner.release()
        # Every env of a group holds the same robot in the same state, so the group's mean is the
        # design's score and is not an average over independent trials.
        mean = (total.view(self.n_morphs, self.samples_per_morph).mean(dim=1) / steps)
        return mean.cpu().numpy(), self._planner.open_loop_policy().sequence

    # ---- training --------------------------------------------------------------------

    def _optimize(self) -> float:
        """`opt_iter` minibatches of MSE regression onto `V_hat`.

        DiffPool's link and entropy losses are computed and discarded -- theirs is
        `F.mse_loss(output[:, 0], train_reward)` and nothing else.
        """
        self._V.train()
        total = 0.0
        for _ in range(self.opt_iter):
            states = self._pool.sample(min(len(self._pool), self.batch_size))
            adj, feat, mask = self._mdp.featurize_batch(states)
            target = torch.tensor([self._V_hat[s] for s in states], dtype=torch.float32,
                                  device=self._device)
            self._optimizer.zero_grad()
            out, _, _ = self._V(torch.as_tensor(feat, device=self._device),
                                torch.as_tensor(adj, device=self._device),
                                torch.as_tensor(mask, device=self._device))
            loss = F.mse_loss(out[:, 0], target)
            loss.backward()
            total += loss.item()
            self._optimizer.step()
        return total / max(self.opt_iter, 1)

    # ---- artifacts -------------------------------------------------------------------

    def control_policy(self) -> ControlPolicy:
        """The gait planned for the best design so far, as a replayable open-loop sequence.

        GHS learns no controller -- MPPI replans for whatever body it is given, and cannot be
        detached from the simulator it plans in. What survives a checkpoint is the trajectory the
        planner committed to on the best design, which is exactly what RoboGrammar reports too:
        `simulate` returns `input_sequence` alongside the reward, and their viewer replays it.
        """
        from codesigner.components.algorithms.control.mppi import OpenLoopPolicy
        if self._best_sequence is None:
            raise RuntimeError("no design has been evaluated yet")
        return OpenLoopPolicy(self._best_sequence, interval=self.interval, name="ghs_best_gait")

    # ---- capabilities ----------------------------------------------------------------

    @provides(SPREAD_CONTROL)
    def sample_at_spread(self, spread: float, n: int) -> List[Morphology]:
        """Epsilon-greedy rollouts at `eps = spread`, which is the scale the contract asks for
        already: at 0 every action is the argmax under `V`, so the draw IS the committed design; at
        1 every action is uniform over the legal ones, which is exactly `ModuleLibrary`'s uniform
        draw over the grammar. Monotone in between because epsilon mixes the two.

        The search's own epsilon is not read -- that is the live exploration schedule, and a ladder
        indexed by it would move as the schedule decayed.
        """
        out: List[Morphology] = []
        while len(out) < n:
            state, _ = _rollout(self._mdp, self._V, self._device, float(spread), rng=self._rng)
            if self._mdp.is_valid(state):
                out.append(self._mdp.to_morphology(state))
        return out

    @provides(DESIGN_QUALITY_PREDICTOR)
    def predict_design_quality(self, designs: List[Morphology]) -> List[float]:
        """`V` at each design's terminal state -- what the search believes a body is worth before
        running it.

        In the units of measured **Episode return**: `V_hat`'s targets are the rewards
        `_evaluate_bodies` measures on this task, unshaped and unnormalized, so prediction and
        reality are already in the same units and the gap between them is a gap.
        """
        states = [self._mdp.from_morphology(m) for m in designs]
        return [float(v) for v in _predict(self._mdp, self._V, self._device, states)]

    @property
    def config(self) -> dict:
        """Everything `__init__` takes. The three epsilon schedules and the MPPI settings are in
        here because a GHS run is not reproducible or interpretable without them -- `result_bound`
        especially, which is calibrated against a task's reward scale and silently rejects designs
        when it is not."""
        return {"n_morphs": self.n_morphs, "samples_per_morph": self.samples_per_morph,
                "iterations": self.iterations, "num_samples": self.num_samples,
                "num_eval": self.num_eval, "opt_iter": self.opt_iter,
                "batch_size": self.batch_size, "lr": self.lr,
                "eps_start": self.eps_start, "eps_end": self.eps_end, "eps_decay": self.eps_decay,
                "eps_sample_start": self.eps_sample_start, "eps_sample_end": self.eps_sample_end,
                "eps_sample_decay": self.eps_sample_decay,
                "result_bound": self.result_bound, "invalid_reward": self.invalid_reward,
                "episode_len": self.episode_len, "interval": self.interval,
                "horizon": self.horizon, "discount_factor": self.discount_factor,
                "kappa": self.kappa, "seed": self.seed}

    def morphology_generator(self) -> MorphologyGenerator:
        return GHSMorphologyGenerator(self._mdp, self._V, self._device, eps=self._eps)

    def current_morphologies(self) -> Optional[List[Morphology]]:
        return self._evaluated

    # ---- checkpoints -----------------------------------------------------------------

    def checkpoint_payload(self) -> dict:
        """`V`'s weights and the `V_hat` table -- not the states pool.

        The pool is derivable: it is the keys of `V_hat`, which is what the search actually learned.
        Storing both would let a reloaded run hold a pool naming states it has no target for.
        """
        return {
            "V": self._V.state_dict(),
            "V_hat": {(s.chains, s.closed): v for s, v in self._V_hat.items()},
            "epoch": self._epoch,
            "best_reward": self._best_reward,
            "best_sequence": self._best_sequence,
            "best_design": None if self._best_design is None
                           else (self._best_design.chains, self._best_design.closed),
            "optimizer": self._optimizer.state_dict() if self._optimizer is not None else None,
        }

    def load_checkpoint_payload(self, payload: dict) -> None:
        if self._mdp is None:
            self._mdp = DesignMDP(self.modlib)
            self._device = self.task.device if self.task is not None else torch.device("cpu")
            self._V = Net(max_nodes=self._mdp.max_nodes, num_channels=self._mdp.n_features,
                          num_outputs=1).to(self._device)
            self._optimizer = torch.optim.Adam(self._V.parameters(), lr=self.lr)
        self._V.load_state_dict(payload["V"])
        if payload.get("optimizer") is not None:
            self._optimizer.load_state_dict(payload["optimizer"])
        self._V_hat = {DesignState(c, cl): v for (c, cl), v in payload["V_hat"].items()}
        self._pool = StatesPool(self._pool.capacity)
        self._seen = set()
        for state in self._V_hat:
            self._seen.add(state)
            self._pool.push(state)
        self._epoch = payload["epoch"]
        self._best_reward = payload["best_reward"]
        self._best_sequence = payload["best_sequence"]
        best = payload.get("best_design")
        self._best_design = None if best is None else DesignState(*best)
