from codesigner.components.modular_libraries.basic import BasicModuleLibrary
from codesigner.components.modular_libraries.simple import SimpleModuleLibrary

# Registry of shipped libraries, keyed by the name a config names them with. A checkpoint records
# the key plus construction args so its library can be reconstructed (see ModuleLibrary.descriptor).
REGISTRY = {
    "simple": SimpleModuleLibrary,
    "basic": BasicModuleLibrary,
}

__all__ = ["SimpleModuleLibrary", "BasicModuleLibrary", "REGISTRY"]
