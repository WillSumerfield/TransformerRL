"""The original ant's vocabulary: two effector types, one blank cap.

`simple` offers 3 effectors and 4 caps; this restricts that to the modules the pre-migration ant
actually had -- a `swing` hip, a `knee` ankle, and the geometry-less `bare` cap. Same torso ring,
same module geometry, same chain limit; only the vocabulary is smaller. It exists so a run can be
put on the phase-1/3 design space (skeleton only, no subtype choice worth making) without editing
the default library.

**Vocabulary only, not the old geometry.** Module length is uniform and library-owned here, as in
`simple` -- the pre-migration hip (0.2828) and ankle (0.6325) lengths and its per-limb length
randomisation have no successor. A library reviving those would be a third library, not this one.

Subtyping this rather than `ModuleLibrary` directly means the two share one copy of the torso, slot
placement, effector emission and cap-frame geometry, so they cannot drift apart. Names are shared
deliberately: `swing`/`knee`/`bare` mean the same module in both libraries, and keeping `simple`'s
declaration order gives them the same per-type subtype indices in both (swing 0, knee 1, bare 0).
Checkpoints still do not cross, because the library **name** is part of a checkpoint's provenance and
`subtype_width` differs (2 here, 4 there) -- so the refusal is by design, not an oversight.
"""
from typing import List

from codesigner.components.modular_libraries.simple import SimpleModuleLibrary
from codesigner.interfaces.modlib import ModuleDefinition


class BasicModuleLibrary(SimpleModuleLibrary):

    _NAME = "basic"
    _MODULE_NAMES = ('swing', 'knee', 'bare')

    def _modules(self) -> List[ModuleDefinition]:
        """The two joints and the blank cap, in `simple`'s declaration order.

        Order is part of the library's identity (it *is* the subtype vocabulary), so these keep the
        relative order they have in `simple` rather than being rearranged.
        """
        by_name = {d.name: d for d in super()._modules()}
        return [by_name[name] for name in self._MODULE_NAMES]
