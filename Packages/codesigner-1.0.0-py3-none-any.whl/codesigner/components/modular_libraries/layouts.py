"""Shipped `RootLayout` presets: where a library's attachment slots sit on the root body.

Built by a constructor rather than typed out, so a ring of a different size or slot count is one
call and cannot drift from the ones below.

Named by **the plane the slots occupy**, in the **Model frame** (CONTEXT.md; z-up):

- `RING_XY` -- the horizontal ring, and the historical default. Slots evenly spaced around the
  vertical, every one of them parallel to the ground. What an ant walks on.
- `RING_XZ` -- the same ring stood on edge, in the plane of travel. What a planar task needs: with
  `RING_XY` and a root pinned to a vertical plane, two slots point straight out of that plane and
  the limbs on them can never reach the ground.
"""
import math

from codesigner.interfaces.modlib import RootLayout, SlotPlacement

# The historical torso: a sphere, with limbs attaching one radius out. Kept as the defaults of
# `ring` so `RING_XY` reproduces the pre-layout geometry exactly.
_TORSO_SPHERE = 0.25
_TORSO_RADIUS = 0.3


def ring(n_slots: int = 8, plane: str = "xy", radius: float = _TORSO_RADIUS,
         body_radius: float = _TORSO_SPHERE, name: str = None) -> RootLayout:
    """`n_slots` slots evenly spaced around a circle in `plane`, slot 0 facing model +x.

    `plane` is the plane the slots occupy, so its **normal** is the axis they turn about: 'xy' turns
    about z, 'xz' about y, 'yz' about x. Each slot's rotation is that turn, which is what carries
    the canonical +x onto its outward direction and every module's joint axis along with it.
    """
    normal = {"xy": (0.0, 0.0, 1.0), "xz": (0.0, 1.0, 0.0), "yz": (1.0, 0.0, 0.0)}.get(plane)
    if normal is None:
        raise ValueError(f"unknown slot plane {plane!r}; want 'xy', 'xz' or 'yz'")

    slots = []
    for s in range(n_slots):
        theta = s * 2.0 * math.pi / n_slots
        sin = math.sin(0.5 * theta)
        rotation = (normal[0] * sin, normal[1] * sin, normal[2] * sin, math.cos(0.5 * theta))
        placement = SlotPlacement(offset=(0.0, 0.0, 0.0), rotation=rotation)
        slots.append(SlotPlacement(
            offset=tuple(radius * c for c in placement.direction), rotation=rotation))

    return RootLayout(name=name or f"ring_{plane}_{n_slots}",
                      body=("sphere", (body_radius,)), slots=tuple(slots))


RING_XY = ring(8, "xy")
"""8 slots in the horizontal plane -- the ant torso, and every library's default."""

RING_XZ = ring(8, "xz")
"""8 slots in the vertical plane of travel, for a planar task."""
