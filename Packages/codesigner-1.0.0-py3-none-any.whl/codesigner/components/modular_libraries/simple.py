"""Default module library: a static 8-slot torso ring, 3 effector types, 4 cap types.

Owns everything ring/limb/cap-specific -- torso shape, ring-slot placement, body assembly.
`backend/build_vsim.py` stays a domain-free XML/geometry toolkit this module calls into.

Every module's joint axis is defined RELATIVE to its parent frame (one axis per type, not a
table per ring slot); `construct_robot` resolves it to an absolute world-frame value by
rotating it with the ring slot's yaw. Ring-slot geometry is computed from the slot index
rather than tabulated.

Every module here has exactly ONE orientation, so orientation never varies in this library --
it is still carried per module, because the interface requires it of libraries that do vary.

Subclassed by `basic.py` to restrict the vocabulary, so everything vocabulary-dependent is derived
from `_NAME` and `_MODULE_NAMES` rather than written out: a subclass overrides those two plus
`_modules()` and inherits every piece of geometry unchanged.
"""
import math
from dataclasses import dataclass
from typing import List, Tuple

from codesigner.backend.build_vsim import (
    fmt_float, vec_str, quat_axis, quat_mul, quat_str, quat_rotate, geom_volume, collision_xml
)
from codesigner.backend.emit import BodyEmitter, BodyRecord
from codesigner.components.modular_libraries.layouts import RING_XY
from codesigner.interfaces.modlib import (ModuleLibrary, ModuleType, ModuleDefinition, Module,
                                          Morphology, Orientation, RootLayout)


# ---- per-module-type physical specifics ----------------------------------------------------
@dataclass
class EffectorGeometry:
    axis: Tuple[float, float, float]   # rotation axis, relative to the module's parent frame
    proximal_cyl: bool                  # True: full-length collision cyl (swing); False: shortened
                                         # distal cyl (knee/twist)


@dataclass
class CapGeom:
    kind: str
    half_dims: Tuple[float, ...]
    yaw: float                          # about the cap's own vertical, cap-frame-relative
    offset: Tuple[float, float, float]  # cap-frame-relative offset from the cap link origin


class SimpleModuleLibrary(ModuleLibrary):

    _NAME = "simple"
    # Every module in this library is symmetric about its connection point, so each has exactly one
    # orientation and anything may attach to anything.
    _MODULE_NAMES = ('swing', 'knee', 'twist', 'bare', 'foot', 'pad', 'ball')
    _ONLY = Orientation(0)
    _DEFAULT_ORIENTATIONS = [_ONLY]

    # ---- Geometry -------------------------------------------------------------
    _EFF_LENGTH = 0.65
    # The proximal fraction of a leg the shortened (knee/twist) collision cylinder covers. Named
    # after the torso stub it was originally sized to match; the stub itself is now the RootLayout's
    # slot offset, but this is a limb proportion and stays here.
    _LEG_CYL_FRAC = 0.3 / _EFF_LENGTH

    _MAX_LIMB_LENGTH = 4

    _EFFORT = "3.4e+38"
    _DENSITY = "5.0"
    _RADIUS = "0.08"
    _JOINT_DYNAMICS = 'damping="1.0" stiffness="100" friction="0.0" armature="1.0"'
    _JOINT_VELOCITY = "30.0"

    _PAD_HALF_LEN = 0.10
    _LONG_EFF_VOLUME = math.pi * float(_RADIUS) ** 2 * 2 * (_LEG_CYL_FRAC * _EFF_LENGTH)
    # Every cap masses the same: half a long (knee/twist) effector module. See build_ant_vsim's old
    # cap-geometry docstring for why (caps span a >10x mass range by shape alone otherwise).
    _CAP_MASS = 0.5 * float(_DENSITY) * _LONG_EFF_VOLUME

    _ROOT_AXIS_DIR = {'x': (1.0, 0.0, 0.0), 'y': (0.0, 1.0, 0.0), 'z': (0.0, 0.0, 1.0)}

    _DEFAULT_LAYOUT = RING_XY

    # Root-mount chain stages carry no geometry (see construct_robot) -- these give each stage the
    # same mass/inertia a 0.05-radius solid sphere at _DENSITY would have had, so removing the
    # geometry changes nothing dynamically, only what renders.
    _MOUNT_RADIUS_EQUIV = 0.05
    _MOUNT_MASS = float(_DENSITY) * geom_volume("sphere", (_MOUNT_RADIUS_EQUIV,))
    _MOUNT_INERTIA = 0.4 * _MOUNT_MASS * _MOUNT_RADIUS_EQUIV ** 2

    def __init__(self, root_layout: RootLayout = None):
        # The layout owns slot count and placement, so `n_slots` is read off it rather than declared
        # a second time. A library built on a different one is a different library as far as a
        # checkpoint is concerned -- see ModuleLibrary.descriptor.
        layout = root_layout or self._DEFAULT_LAYOUT
        super().__init__(name=self._NAME, n_slots=layout.n_slots,
                         max_depth=self._MAX_LIMB_LENGTH, root_layout=layout)

    @property
    def _connections_all(self) -> dict:
        """Anything attaches to anything, at the single orientation every module has.

        Derived from `_MODULE_NAMES` so a subclass that drops modules cannot leave a connection
        table naming one it no longer defines -- which `ModuleLibrary.validate` would reject.
        """
        return {self._ONLY: {name: [self._ONLY] for name in self._MODULE_NAMES}}

    # ------------------------- Module Definitions -------------------------------

    def _modules(self) -> List[ModuleDefinition]:
        return [
            self._define_effector("swing", [(-0.7, 0.7)], EffectorGeometry(axis=self._ROOT_AXIS_DIR["z"], proximal_cyl=True)),
            self._define_effector("knee", [(0.5, 1.5)], EffectorGeometry(axis=self._ROOT_AXIS_DIR["y"], proximal_cyl=False)),
            self._define_effector("twist", [(-1.5, 1.5)], EffectorGeometry(axis=self._ROOT_AXIS_DIR["x"], proximal_cyl=False)),
            self._define_cap("bare", geometry=None),
            self._define_cap("foot", geometry=[
                CapGeom("cylinder", (0.25, 0.03), 0.25 * math.pi, (0.0, 0.0, 0.0)),
                CapGeom("cylinder", (0.25, 0.03), -0.25 * math.pi, (0.0, 0.0, 0.0)),
            ]),
            self._define_cap("pad", geometry=[
                CapGeom("box", (self._PAD_HALF_LEN, 0.10, 0.02), 0.0, (0.6 * self._PAD_HALF_LEN, 0.0, 0.0)),
            ]),
            self._define_cap("ball", geometry=[
                CapGeom("sphere", (0.09,), 0.0, (0.0, 0.0, 0.0)),
            ]),
        ]

    def _define_cap(self, name: str, geometry) -> ModuleDefinition:
        return ModuleDefinition(
            name=name,
            type=ModuleType.CAP,
            valid_orientations=self._DEFAULT_ORIENTATIONS,
            action_dimensions=0,
            joint_limits=None,
            geometry=geometry,
            valid_configurations=None,
        )

    def _define_effector(self, name: str, joint_limits: List[Tuple[float, float]], geometry) -> ModuleDefinition:
        return ModuleDefinition(
            name=name,
            type=ModuleType.EFFECTOR,
            valid_orientations=self._DEFAULT_ORIENTATIONS,
            action_dimensions=1,
            joint_limits=joint_limits,
            geometry=geometry,
            valid_configurations=self._connections_all,
        )

    # ------------------------- Robot construction -------------------------------

    def construct_robot(self, morphology: Morphology, root_axes: list = None) -> BodyRecord:
        """Supply geometry for the entities the emitter has already declared.

        Every name, key and declaration order is the emitter's; everything below is numbers.
        """
        e = BodyEmitter(self, morphology, root_axes=root_axes)

        body_kind, body_dims = self.root_layout.body
        torso_collisions = [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", body_kind, body_dims)]
        for s in morphology.occupied_slots:
            # A stub bridging the root body out to the slot's attachment point: half as long as the
            # offset, centred on it. Derived from the offset rather than from _TORSO_STUB so a
            # layout that seats its slots further out grows the stub to match.
            offset = self._slot_offset(s)
            half = 0.5 * math.dist((0.0, 0.0, 0.0), offset)
            torso_collisions.append(collision_xml(
                vec_str(0.5, offset), self._slot_rot_str(s),
                "cylinder", (half, float(self._RADIUS))))
        e.set_root(self._DENSITY, torso_collisions)

        for i, ax in enumerate(e.root_axes):
            # `range is None` means unlimited, and reaches joint_xml as no <limit> element at all.
            limits = None if ax.range is None else (fmt_float(ax.range[0]), fmt_float(ax.range[1]))
            e.set_root_mount(i, self._MOUNT_MASS, self._MOUNT_INERTIA,
                             axis=vec_str(1.0, self._ROOT_AXIS_DIR[ax.direction]),
                             limits=limits, effort=self._EFFORT,
                             velocity=self._JOINT_VELOCITY, dynamics=self._JOINT_DYNAMICS)

        for s in morphology.occupied_slots:
            chain = e.chain(s)
            n_knees = sum(1 for r in chain if r.module.name == "knee")
            for rec in chain:
                if rec.type is ModuleType.CAP:
                    # A bare cap terminates the chain in the grammar only: no link, no joint, and
                    # the limb's contact sensor stays on its terminal effector.
                    if rec.module.definition.geometry is not None:
                        self._emit_cap(e, rec, n_knees)
                else:
                    self._emit_effector(e, rec)
            # One contact sensor per limb, on its terminal emitted module -- the cap when the cap is
            # a real body, else the deepest effector (a bare cap emits no link). `set_sensor` takes
            # a module, so a library wanting readings further up the chain calls it per module; this
            # one keeps a single ground-contact reading per limb.
            terminal = e.terminal(s)
            e.set_sensor(terminal, "0.0 0.0 0.0" if terminal.type is ModuleType.CAP
                         else vec_str(self._EFF_LENGTH, self._slot_dir(s)))

        return e.build()

    def _emit_effector(self, e: BodyEmitter, rec) -> None:
        geom = rec.module.definition.geometry
        s = rec.slot
        half = self._EFF_LENGTH / 2 if geom.proximal_cyl else self._LEG_CYL_FRAC * self._EFF_LENGTH
        coll = collision_xml(vec_str(half, self._slot_dir(s)), self._slot_rot_str(s), "cylinder",
                             (half, float(self._RADIUS)))
        # Depth 0 attaches at the slot's own offset; deeper modules extend one module length on
        # from their parent, along the slot direction.
        origin = (vec_str(1.0, self._slot_offset(s)) if rec.depth == 0
                  else vec_str(self._EFF_LENGTH, self._slot_dir(s)))
        lo, hi = rec.module.definition.joint_limits[0]
        e.set_module(rec, self._DENSITY, [coll], origin,
                     axis=vec_str(1.0, quat_rotate(self._slot_yaw(s), geom.axis)),
                     limits=(fmt_float(lo), fmt_float(hi)), effort=self._EFFORT,
                     velocity=self._JOINT_VELOCITY, dynamics=self._JOINT_DYNAMICS)

    def _emit_cap(self, e: BodyEmitter, rec, n_knees: int) -> None:
        geoms = rec.module.definition.geometry
        density = self._CAP_MASS / sum(geom_volume(g.kind, g.half_dims) for g in geoms)
        frame = self._cap_frame(rec.slot, n_knees)
        collisions = [
            collision_xml(vec_str(1.0, quat_rotate(frame, g.offset)),
                          quat_str(quat_mul(frame, quat_axis((0.0, 0.0, 1.0), g.yaw))),
                          g.kind, g.half_dims)
            for g in geoms
        ]
        # A cap rides a FIXED joint: no axis, no limits, no DOF.
        e.set_module(rec, density, collisions,
                     vec_str(self._EFF_LENGTH, self._slot_dir(rec.slot)))

    def module_length(self, module: Module) -> float:
        """Every module in this library is one fixed length; caps add none."""
        return 0.0 if module.type is ModuleType.CAP else self._EFF_LENGTH

    def _cap_pitch(self) -> float:
        """Nominal bend of one knee: the midpoint of its own joint range.

        Derived from the knee definition rather than tabulated, so changing the knee's limits cannot
        leave the cap compensation silently stale.
        """
        lo, hi = self.modules["knee"].joint_limits[0]
        return 0.5 * (lo + hi)

    def _cap_frame(self, slot: int, n_knees: int) -> tuple:
        """Cap frame: yaw to the ring slot, then pitch UP by the nominal knee bend so a bare-standing
        cap's contact face lands horizontal.

        Caps ride a FIXED joint, so this compensation is baked statically into the cap's geometry
        rather than tracked at runtime -- a cap only sits truly flat at that one nominal pose. Each
        knee in the chain bends the frame further, hence the per-knee multiple, clamped upright at
        90deg. Swing and twist do not pitch the limb, so they do not contribute.
        """
        pitch = min(self._cap_pitch() * n_knees, 0.5 * math.pi)
        return quat_mul(self._slot_yaw(slot), quat_axis((0.0, 1.0, 0.0), -pitch))

    # Slots are 0-based throughout, matching Morphology position. The 1-based numbers in XML names
    # are the emitter's convention and appear nowhere in this library. Placement itself is the
    # RootLayout's; these three only read it, so nothing here assumes a ring.

    def _slot_dir(self, slot: int) -> tuple:
        """Unit outward direction for a slot."""
        return self.root_layout.slots[slot].direction

    def _slot_yaw(self, slot: int) -> tuple:
        """Quaternion carrying the canonical (model +x) slot frame onto `slot`."""
        return self.root_layout.slots[slot].rotation

    def _slot_rot_str(self, slot: int) -> str:
        return quat_str(self._slot_yaw(slot))

    def _slot_offset(self, slot: int) -> tuple:
        """Where the slot's depth-0 module attaches, measured from the root body's origin.

        Supersedes the old `_TORSO_RADIUS` reach: the offset is the placement's own, so a layout
        whose slots are not all one radius out stays correct with no change here.
        """
        return self.root_layout.slots[slot].offset
