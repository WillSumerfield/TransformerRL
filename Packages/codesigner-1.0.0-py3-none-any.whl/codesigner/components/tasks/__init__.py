from codesigner.components.tasks.ant import Ant
from codesigner.components.tasks.grasp import Grasp
from codesigner.components.tasks.adroit.adroit import AdroitTask
from codesigner.components.tasks.adroit.relocate import Relocate
from codesigner.components.tasks.adroit.door import Door
from codesigner.components.tasks.adroit.hammer import Hammer
from codesigner.components.tasks.adroit.pen import Pen
from codesigner.components.tasks.bodygen.bodygen import PlanarMotion
from codesigner.components.tasks.bodygen.gap import Gap
from codesigner.components.tasks.bodygen.hopper import Hopper
from codesigner.components.tasks.bodygen.swimmer import Swimmer
from codesigner.components.tasks.bodygen.walker import Walker

# Registry of shipped tasks, keyed by the name a config names them with (mirrors
# modular_libraries.REGISTRY). AdroitTask and PlanarMotion are excluded: both leave create_scene
# abstract, so they are shared bases, not something a config can construct on its own.
REGISTRY = {
    "ant": Ant,
    "grasp": Grasp,
    "relocate": Relocate,
    "door": Door,
    "hammer": Hammer,
    "pen": Pen,
    "hopper": Hopper,
    "walker": Walker,
    "gap": Gap,
    "swimmer": Swimmer,
}


def registry_key(task) -> str:
    """The REGISTRY key naming `task` (a Task instance or class).

    The reverse of REGISTRY, for the places that hold a Task and need the stable name for it -- a
    checkpoint recording which task it was trained on, chiefly. Exact class match, not isinstance:
    a subclass is a different task, and recording its base's key is exactly the mislabelling this
    exists to prevent.
    """
    cls = task if isinstance(task, type) else type(task)
    for key, registered in REGISTRY.items():
        if registered is cls:
            return key
    raise KeyError(
        f"{cls.__name__} is not a registered task (have: {sorted(REGISTRY)}). Register it before "
        "writing a checkpoint, or the checkpoint cannot say what it was trained on.")


__all__ = ["Ant", "Grasp", "AdroitTask", "Relocate", "Door", "Hammer", "Pen", "PlanarMotion",
           "Hopper", "Walker", "Gap", "Swimmer", "REGISTRY", "registry_key"]
