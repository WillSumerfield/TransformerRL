"""Shared base for the four Adroit-derived manipulation tasks: Door, Hammer, Pen, Relocate.

Ported from gymnasium-robotics' `AdroitHand{Door,Hammer,Pen,Relocate}` envs, with two deliberate
departures (see CONTEXT.md's Root mounting and Prop entries):

- **The hand is whatever morphology/library the Algorithm supplies** -- codesignable, per D6/D9 --
  not the fixed 24-DOF Shadow Hand. A Task stays modlib-agnostic; it does not choose or assume a
  library, same as `Grasp`.
- **The wrist is `root_axes`**, not a body-owned joint. The source envs give their forearm body a
  *different* actuated joint set per task -- Door 4 DOF (z, rx, ry, rz), Hammer 2 (rx, ry), Pen 0
  (the forearm is fully welded; only the hand's own WRJ0/WRJ1 move it), Relocate the full 6 -- so
  this base does **not** hand down one shared `root_axes`. Each concrete task fixes its own, same as
  `Grasp` hardcodes `['y', 'x']` in its own `__init__` rather than taking it from a caller.
- **Everything with a length is `_SCALE` times the source value.** The source rig is a Shadow Hand;
  the bodies these tasks actually get are built from this package's own libraries, whose limbs are
  0.65m long and 0.16m across. Sizes, placements, randomization ranges and reward radii all scale
  together -- a prop that grew 6x but stayed where it was would simply be out of reach -- while
  angles do not, since a radian means the same thing at any scale. Densities scale by `_SCALE ** -3`
  so a prop keeps the mass ratio to its robot that the source intended: 216x the volume at 1/216th
  the density is the same mass, against libraries whose own density is deliberately low.
"""
import torch
import vlearn as v

from codesigner.interfaces import GlobalField
from codesigner.interfaces.task import Task

_SCALE = 6.0                    # linear, vs the source Shadow-Hand rig
_DENSITY_SCALE = _SCALE ** -3   # holds the source's robot:prop mass ratio (see the module docstring)
_PROP_GAP = _SCALE * 0.02       # clearance under the hand for a weightless prop (see Hammer/Pen)


class AdroitTask(Task):
    """What the four do share: a hand mounted near a fixed point in space (never dropped, never
    walking) and at least one Prop for it to act on.

    `set_root_pose` is the one piece of that worth factoring out -- it is `Grasp`'s implementation
    verbatim, because both are "hang the hand at a constant height, clear of its own longest chain"
    tasks. `create_scene` and `create_props` stay this class's responsibility to leave abstract:
    what scene and what Props a task needs is exactly the part that differs (a door and frame, a
    nail and board, nothing at all for Pen) -- inheriting a default here is how `Grasp` warns a
    manipulation task ends up with a floor it never asked for (D7c), and the same reasoning applies
    to Props.

    The **palm position** is the other. Every hand-anchored objective is some function of where the
    palm is relative to a Prop, and the standard observation does not carry it: the root block holds
    height and orientation, not full root xyz, which is enough for a walker whose x is meaningless
    and not enough for a hand bolted over a table. Appended here so all four share one offset rather
    than each publishing its own `palm_off` at a different place, and so a policy trained on one
    Adroit task reads the palm from the same column on the next.
    """

    def obs_fields(self) -> dict:
        return {**super().obs_fields(), "palm": GlobalField(3)}     # palm xyz

    def compute_observations(self):
        super().compute_observations()
        self.obs("palm")[:] = self._get_root_pose[:, 4:7]

    def __init__(
        self,
        device: torch.device,
        root_axes: list,
        hover_height: float,
        max_episode_length: int = 1000,
        gravity: v.Vec3 = v.Vec3(0, -9.81, 0),
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 3.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        **kwargs,
    ):
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=root_axes,
            **kwargs,
        )
        self.hover_height = hover_height

    def set_root_pose(self, group: dict, start: int, end: int):
        """Hang the hand so its lowest extent clears the Props by `hover_height` -- **Mount
        clearance** (CONTEXT.md).

        Lifting by the body's whole `reach` rather than by `Grasp`'s `deepest_chain[2:]` is the one
        place this diverges from it, and deliberately. `Grasp`'s rule holds the *palm* at a constant
        height by treating the first two modules as wrist rather than finger, which leaves the
        fingertips 0.65m lower on a four-module limb than on a one-module one -- fine for a task
        whose target is a bare pose, fatal here, where a short-limbed body ends up unable to reach
        the floor its ball rests on while a long-limbed one starts driven through it. Lifting by the
        full reach puts every morphology's fingertips at exactly `hover_height`, which is what makes
        `hover_height` a number worth setting and what lets the hand-anchored tasks place their
        weightless Props at a constant height instead of a per-group one.
        """
        lift = self.hover_height + group["reach"]
        self._set_root_pose[start:end, 5] += lift
        self._height_offset[start:end] = lift
