"""Door: undo a latch and swing a door open, hand mounted on a partially actuated wrist.

Ported from gymnasium-robotics' `AdroitHandDoorEnv` (dense reward variant). Unlike `Relocate`'s
single free rigid-body Prop, the door is a hinged mechanism -- frame, door and latch chained by two
unmotored revolute joints (see `backend.props.PropBuilder`'s "no auto-motor" note) -- so it becomes
its own small articulation (`env_def.create_articulation`), not a `create_rigid_body`. The frame link
is imported `fixed=True` (pinned to a placement transform, exactly like a world-mounted robot root)
and repositioned once per episode via the same masked kinematic-state SET pattern used everywhere
else in this codebase; `door_hinge`/`latch` are read every step through the matching GET command and
never driven -- they swing (or don't) purely from hand contact and their own damping/friction.

**Departures from the source env**, beyond the ones `AdroitTask` already documents:

- The source's dense reward has `reward = 0.1 * ||palm - handle||` for the "get to handle" term --
  positive, the same sign bug already found and fixed in `Relocate` (see its module docstring).
  Ported here with the negated sign the source's own doc table ("increasing negative reward the
  further away") describes: `-0.1 * ||palm - handle||`.
- "Palm" is the hand's root link position, and "handle" is the `latch` link's own origin -- neither
  a named MuJoCo site, for the same reason `Relocate` gives: a codesigned hand and a codesigner-built
  Prop have no fixed site geometry to hang one off.
- The source's velocity penalty (`-1e-5 * sum(full qvel**2)`) covers the entire simulation, hand and
  door alike. Only the robot's own DOF velocities (fingers plus the wrist/root axes) are penalized
  here -- the door's two joints are unmotored and not part of what a policy directly commands, so
  penalizing their velocity does not serve the term's purpose (discouraging jerky policy output).
- Door has one translation axis in the source (`ARTz`) and three rotations (`ARRx/y/z`), unlike
  Relocate's three; `AdroitTask` already documents this as `['z', 'rx', 'ry', 'rz']`. With only one
  translation axis there is no ambiguity about which world axis it adapts to, so both the translation
  and rotation ranges are ported numerically, unchanged from the source XML.
"""
import torch
import vlearn as v

from codesigner.backend.build_vsim import collision_xml
from codesigner.backend.props import PropBuilder, write_prop_vsim
from codesigner.backend.vlearn_helpers import create_plane
from codesigner.components.tasks.adroit.adroit import AdroitTask, _DENSITY_SCALE, _SCALE
from codesigner.interfaces import GlobalField
from codesigner.interfaces.modlib import RootAxis

# The one translation axis (model z, the vertical) scales; the three rotations do not. See
# Relocate's note.
_ROOT_AXES = [
    RootAxis.slide("z", (_SCALE * -0.3, _SCALE * 0.5)),
    RootAxis.hinge("x", (-0.75, 0.75)),
    RootAxis.hinge("y", (-0.75, 0.75)),
    RootAxis.hinge("z", (-1.0, 2.0)),
]


class Door(AdroitTask):

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int = 200,
        gravity: v.Vec3 = v.Vec3(0, -9.81, 0),
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 6.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        hover_height: float = 0.5,
        frame_density: float = _DENSITY_SCALE * 1000.0,
        door_density: float = _DENSITY_SCALE * 500.0,
        latch_density: float = _DENSITY_SCALE * 500.0,
        door_half_width: float = _SCALE * 0.2,
        door_half_height: float = _SCALE * 0.25,
        door_thickness: float = _SCALE * 0.05,
        latch_length: float = _SCALE * 0.15,
        latch_radius: float = _SCALE * 0.03,
        door_hinge_damping: float = 1.0,
        door_hinge_friction: float = 2.0,
        latch_friction: float = 5.0,
        door_x_range: tuple = (_SCALE * -0.3, _SCALE * -0.2),
        door_y_range: tuple = (_SCALE * 0.252, _SCALE * 0.35),
        door_z_range: tuple = (_SCALE * 0.25, _SCALE * 0.35),
        dist_penalty_weight: float = 0.1,
        open_weight: float = 0.1,
        target_angle: float = 1.57,
        vel_penalty_weight: float = 1e-5,
        open_thresh1: float = 0.2,
        open_bonus1: float = 2.0,
        open_thresh2: float = 1.0,
        open_bonus2: float = 8.0,
        open_thresh3: float = 1.35,
        open_bonus3: float = 10.0,
        **kwargs,
    ):
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=_ROOT_AXES,
            hover_height=hover_height,
            **kwargs,
        )
        self.frame_density = frame_density
        self.door_density = door_density
        self.latch_density = latch_density
        self.door_half_width = door_half_width
        self.door_half_height = door_half_height
        self.door_thickness = door_thickness
        self.latch_length = latch_length
        self.latch_radius = latch_radius
        self.door_hinge_damping = door_hinge_damping
        self.door_hinge_friction = door_hinge_friction
        self.latch_friction = latch_friction
        self.door_x_range = door_x_range
        self.door_y_range = door_y_range
        self.door_z_range = door_z_range
        self.dist_penalty_weight = dist_penalty_weight
        self.open_weight = open_weight
        self.target_angle = target_angle
        self.vel_penalty_weight = vel_penalty_weight
        self.open_thresh1 = open_thresh1
        self.open_bonus1 = open_bonus1
        self.open_thresh2 = open_thresh2
        self.open_bonus2 = open_bonus2
        self.open_thresh3 = open_thresh3
        self.open_bonus3 = open_bonus3
        self._door_handles = []

    def create_scene(self):
        create_plane(self.gym)

    def create_props(self, env_def, group_index: int, morph):
        """One hinged articulation: frame (fixed base) -> door -[door_hinge]-> door -[latch]-> latch.
        `_door_handles` is rebuilt from scratch on `group_index == 0`, same reasoning as `Relocate`'s
        `_ball_handles`. The dof/link name -> index lookup only needs to happen once (every group
        imports the identical generated file, so the ordering vsim reports back is deterministic
        across groups) -- done on group 0 and reused."""
        if group_index == 0:
            self._door_handles = []

        b = PropBuilder("door")
        b.add_link("frame", self.frame_density,
                  [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "box",
                                (_SCALE * 0.03, _SCALE * 0.15, _SCALE * 0.03))])
        b.add_link("door", self.door_density,
                  [collision_xml(f"{self.door_half_width} 0.0 0.0", "0.0 0.0 0.0 1.0", "box",
                                (self.door_half_width, self.door_half_height, self.door_thickness))])
        b.add_link("latch", self.latch_density,
                  [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "cylinder",
                                (self.latch_length, self.latch_radius))])
        b.add_joint("door_hinge", "revolute", "frame", "door", "0.0 0.0 0.0",
                   axis="0.0 1.0 0.0", limits=("0.0", "1.57"),
                   dynamics=f'damping="{self.door_hinge_damping}" frictionloss="{self.door_hinge_friction}"')
        b.add_joint("latch", "revolute", "door", "latch",
                   f"{2 * self.door_half_width - _SCALE * 0.05} 0.0 "
                   f"{-0.5 * self.door_half_height}",
                   axis="0.0 0.0 1.0", limits=("0.0", "1.8"),
                   dynamics=f'frictionloss="{self.latch_friction}"')
        path = write_prop_vsim(b.build(), "door", group_index)
        env_def.import_definitions(str(path), fixed=True)

        door_def_handle = env_def.get_articulation_def_handle_by_name("door")
        init_pos = v.Vec3(sum(self.door_x_range) / 2, sum(self.door_y_range) / 2,
                          sum(self.door_z_range) / 2)
        init_tf = v.Transform(v.Quat(0, 0, 0, 1), init_pos)
        door_handle = env_def.create_articulation(door_def_handle, init_tf, "door")

        if group_index == 0:
            art_def = env_def.get_articulation_def(door_def_handle)
            dof_names = [art_def.get_joint_dof_def_name(k)
                        for k in range(art_def.get_num_joint_dof_defs())]
            self._hinge_col = dof_names.index("door_hinge")
            self._latch_col = dof_names.index("latch")
            link_names = [art_def.get_link_def_name(k) for k in range(art_def.get_num_link_defs())]
            self._latch_link_k = link_names.index("latch")

        self._door_handles.append(door_handle)

    def allocate_buffers(self):
        super().allocate_buffers()
        N, EPM = self.total_num_envs, self.envs_per_morph

        self._get_door_dof = torch.zeros((N, 2), dtype=torch.float32, device=self.device)
        self._get_door_dof_vel = torch.zeros((N, 2), dtype=torch.float32, device=self.device)
        self._set_door_dof = torch.zeros((N, 2), dtype=torch.float32, device=self.device)
        self._set_door_dof_vel = torch.zeros((N, 2), dtype=torch.float32, device=self.device)
        # All 3 links (frame/door/latch), MODEL/ENVIRONMENT frame; only the latch row is read
        # downstream (the handle proxy), but the command fetches every link in one call.
        self._get_door_link_pose = torch.zeros((N, 3 * 7), dtype=torch.float32, device=self.device)
        self._get_door_link_vel = torch.zeros((N, 3 * 6), dtype=torch.float32, device=self.device)
        # Root-only (frame) SET target -- door_hinge/latch reset via the dof buffers above, which
        # stay zero for the whole run (door starts closed every episode, same as the source env).
        self._set_frame_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._set_frame_vel = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_frame_pose[:, 3] = 1.0   # identity quat (qw); door frame never rotates

        get_cmds, set_cmds = [], []
        for gi, g in enumerate(self.groups):
            start, end = gi * EPM, (gi + 1) * EPM
            get_cmds.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(self._get_door_dof[start:end]),
                v.wrap_gpu_buffer(self._get_door_dof_vel[start:end]),
                v.wrap_gpu_buffer(self._get_door_link_pose[start:end]),
                v.wrap_gpu_buffer(self._get_door_link_vel[start:end]),
                self._door_handles[gi], link_index_range=(0, 3),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            set_cmds.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(self._set_door_dof[start:end]),
                v.wrap_gpu_buffer(self._set_door_dof_vel[start:end]),
                v.wrap_gpu_buffer(self._set_frame_pose[start:end]),
                v.wrap_gpu_buffer(self._set_frame_vel[start:end]),
                self._door_handles[gi], link_index_range=(0, 1),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
                masks_buffer=v.wrap_gpu_buffer(self._reset_buf[start:end]),
            ))
        self._door_get_cmd_array = self.gym.create_gpu_array(get_cmds)
        self._door_set_cmd_array = self.gym.create_gpu_array(set_cmds)

        self._draw_door(torch.ones(N, dtype=torch.bool, device=self.device))

    def reset_idx(self):
        super().reset_idx()
        self._draw_door(self._reset_buf)
        self.gym.set_articulation_kinematic_states(self._door_set_cmd_array)

    def _draw_door(self, mask: torch.Tensor):
        """Redraw the door frame's placement (env-local frame) for resetting envs. `door_hinge` and
        `latch` are not redrawn -- their SET buffers stay zero for the process lifetime, so the
        masked SET always snaps a resetting env's door back closed."""
        m = mask.unsqueeze(-1)
        n = self._set_frame_pose.shape[0]

        def _uniform(lo: float, hi: float) -> torch.Tensor:
            return torch.rand((n, 1), device=self.device) * (hi - lo) + lo

        self._set_frame_pose[:, 4:5] = torch.where(m, _uniform(*self.door_x_range),
                                                   self._set_frame_pose[:, 4:5])
        self._set_frame_pose[:, 5:6] = torch.where(m, _uniform(*self.door_y_range),
                                                   self._set_frame_pose[:, 5:6])
        self._set_frame_pose[:, 6:7] = torch.where(m, _uniform(*self.door_z_range),
                                                   self._set_frame_pose[:, 6:7])

    def obs_fields(self) -> dict:
        # The palm itself is AdroitTask's. `open_flag` is +-1 rather than {0,1} and is a fact about
        # the door's state, not the body's structure, so it normalizes like the angles it derives
        # from -- see `backend.obs_spec` on what `structural` is for.
        return {**super().obs_fields(),
                "handle":         GlobalField(3),
                "palm_to_handle": GlobalField(3),
                "hinge_angle":    GlobalField(1),
                "latch_angle":    GlobalField(1),
                "open_flag":      GlobalField(1)}

    def compute_observations(self):
        self.gym.get_articulation_kinematic_states(self._door_get_cmd_array)
        super().compute_observations()

        palm = self._get_root_pose[:, 4:7]
        handle = self._handle_pos()
        hinge_angle = self._get_door_dof[:, self._hinge_col]
        latch_angle = self._get_door_dof[:, self._latch_col]

        self.obs("handle")[:] = handle
        self.obs("palm_to_handle")[:] = palm - handle
        self.obs("hinge_angle")[:, 0] = hinge_angle
        self.obs("latch_angle")[:, 0] = latch_angle
        self.obs("open_flag")[:, 0] = torch.where(hinge_angle > 1.0, 1.0, -1.0)

    def _handle_pos(self) -> torch.Tensor:
        return self._get_door_link_pose.view(-1, 3, 7)[:, self._latch_link_k, 4:7]

    def compute_reward_termination_truncation(self):
        # Robot-only DOF velocities (fingers + wrist/root axes), masked to active slots -- see the
        # module docstring's velocity-penalty departure. Gathered here (not jit-safe as instance
        # attributes) and reduced before handing off, same as Ant precomputes root_pose.
        dof_vel = self._flat_get_dof_vel[self._dof_gather_idx] * self._global_dof_mask
        dof_vel_sq_sum = (dof_vel * dof_vel).sum(dim=-1)

        self.reward_term_trunc_helper_jit(
            self._rew_buf, self._next_term_buf, self._next_trunc_buf,
            self._get_root_pose[:, 4:7], self._handle_pos(),
            self._get_door_dof[:, self._hinge_col], dof_vel_sq_sum,
            self.dist_penalty_weight, self.open_weight, self.target_angle, self.vel_penalty_weight,
            self.open_thresh1, self.open_bonus1,
            self.open_thresh2, self.open_bonus2,
            self.open_thresh3, self.open_bonus3,
            self._progress_buf, self.max_episode_length,
        )

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        palm_pos: torch.Tensor,
        handle_pos: torch.Tensor,
        hinge_angle: torch.Tensor,
        dof_vel_sq_sum: torch.Tensor,
        dist_penalty_weight: float,
        open_weight: float,
        target_angle: float,
        vel_penalty_weight: float,
        open_thresh1: float,
        open_bonus1: float,
        open_thresh2: float,
        open_bonus2: float,
        open_thresh3: float,
        open_bonus3: float,
        progress: torch.Tensor,
        max_episode_length: int,
    ):
        """`AdroitHandDoorEnv.step`'s dense reward, sign-corrected on the first term (see the module
        docstring): distance-to-handle penalty, squared error to the target hinge angle, a (robot-
        only) velocity penalty, and three step bonuses as the door swings further open. Never
        terminates -- truncates at the time limit, same as the source env.
        """
        palm_to_handle = torch.norm(palm_pos - handle_pos, dim=-1)
        angle_err = hinge_angle - target_angle

        reward = -dist_penalty_weight * palm_to_handle
        reward = reward - open_weight * angle_err * angle_err
        reward = reward - vel_penalty_weight * dof_vel_sq_sum
        reward = reward + torch.where(hinge_angle > open_thresh1, open_bonus1, 0.0)
        reward = reward + torch.where(hinge_angle > open_thresh2, open_bonus2, 0.0)
        reward = reward + torch.where(hinge_angle > open_thresh3, open_bonus3, 0.0)

        rew_buf[:] = reward
        term_buf[:] = False
        trunc_buf[:] = progress >= max_episode_length
