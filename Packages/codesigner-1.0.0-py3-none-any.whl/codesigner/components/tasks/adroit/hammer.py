"""Hammer: pick up a hammer and drive a nail into a board, hand mounted on a two-axis wrist.

Ported from gymnasium-robotics' `AdroitHandHammerEnv` (dense reward variant). Two Props
(`backend.props.PropBuilder`), of two different kinds:

- **The hammer** is a free **rigid body**, exactly like `Relocate`'s ball. It is authored as two
  links -- where the hand grips it (`handle`) and where it strikes (`head`) -- joined by a `fixed`
  joint, and `import_definitions` merges the pair into one body (`merge_fixed_joints=True`) that
  keeps both collision shapes and their combined mass. That merge is wanted: the head is real
  striking geometry, not a marker. `fixed=False` on import gives it the same free 6-DOF motion Ant's
  own free-floating root has. The strike point is then `handle + R(q) * (-head_offset, 0, 0)` --
  see `_head_pos` -- because VSim exposes exactly one transform per rigid body and has no concept of
  a named point on one.
- **The nail and board** is structurally `Door`'s frame/door/latch pattern again, with the moving
  joint swapped from revolute to prismatic: `board` (fixed base, repositioned once per episode) ->
  `nail` (`prismatic`, unmotored, so it only moves when struck). It keeps a real DOF, so it stays an
  articulation. The fully-driven-in target depth is **not** a link: it is massless in the source (a
  site), so it is computed off the board's own pose in `_goal_pos` rather than welded on as a marker
  link, which VSim would silently merge away.

**Departures from the source env**, beyond the ones `AdroitTask` and `Door` already document:

- The source's dense reward has `reward = 0.1 * ||palm - hammer||` for the "get to hammer" term --
  the same sign bug already found in `Relocate` and `Door`. Ported here negated, per the source's own
  doc table ("increasing negative reward the further away"): `-0.1 * ||palm - hammer||`.
- "Palm" is the hand's root link; "hammer" is the `handle` link's own origin (not `Object`'s body
  frame via a separate site) and "head" is the `head` link's origin (not the `tool` site) -- same
  reasoning as every other departure of this kind: no fixed site geometry to hang a name off.
- The source's velocity penalty is an L2 **norm** (`-1e-2 * ||qvel||`), unlike `Door`'s sum-of-squares
  -- ported with the same shape, restricted to the robot's own DOFs for the same reason `Door` gives.
- Only the board's height is randomized in the source (`reset_model` touches just one coordinate);
  the hammer's start pose is not randomized at all. Both are ported that way: `_draw_board` redraws
  one axis per reset, the hammer's `_set_hammer_pose` is a constant written once.
- No force-sensor term (`nail_impact`, the source's 46th observation) -- Props have no sensor wiring
  yet, unlike `BodyEmitter`-built links which mint real force-sensor commands (the
  emitter-owns-names split does not extend to Props yet).
- **No gravity, and the props hang off the hand.** The source spawns its hammer on a table at a
  height chosen for one fixed rig; there is no such height here, because the body is whatever the
  Algorithm supplied. So the hammer and board are placed relative to the hand's own lowest extent
  -- a constant, since `AdroitTask`'s Mount clearance puts every morphology's fingertips at exactly
  `hover_height` -- and gravity is off, so a hammer the fingers have not yet closed on stays where
  it was put instead of falling away before the episode begins. `lift_bonus` therefore always
  fires; it is left in place rather than deleted, since it is a constant offset that changes no
  gradient, and deleting it would make this port harder to diff against the source.
"""
import torch
import vlearn as v
from vlearn.torch_utils.torch_jit_utils import quat_rotate

from codesigner.backend.build_vsim import collision_xml
from codesigner.backend.props import PropBuilder, write_prop_vsim
from codesigner.backend.vlearn_helpers import create_plane
from codesigner.components.tasks.adroit.adroit import (AdroitTask, _DENSITY_SCALE, _PROP_GAP,
                                                       _SCALE)
from codesigner.interfaces import GlobalField
from codesigner.interfaces.modlib import RootAxis

_ROOT_AXES = [RootAxis.hinge("x", (-0.4, 0.25)), RootAxis.hinge("y", (-0.3, 0.3))]


class Hammer(AdroitTask):

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int = 200,
        gravity: v.Vec3 = v.Vec3(0, 0, 0),   # see the module docstring
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 6.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        hover_height: float = 0.5,
        handle_length: float = _SCALE * 0.1,
        handle_radius: float = _SCALE * 0.025,
        handle_density: float = _DENSITY_SCALE * 700.0,
        head_offset: float = _SCALE * 0.22,
        head_length: float = _SCALE * 0.08,
        head_radius: float = _SCALE * 0.02,
        head_density: float = _DENSITY_SCALE * 3000.0,
        hammer_pos: tuple = None,        # derived below -- hangs under the hand
        board_half_extent: tuple = (_SCALE * 0.08, _SCALE * 0.08, _SCALE * 0.01),
        board_density: float = _DENSITY_SCALE * 500.0,
        board_x: float = _SCALE * 0.05,
        board_z: float = 0.0,
        board_y_range: tuple = None,     # derived below -- hangs under the hand
        nail_goal_offset: float = _SCALE * 0.01,   # depth into the board
        nail_radius: float = _SCALE * 0.01,
        nail_length: float = _SCALE * 0.1,
        nail_density: float = _DENSITY_SCALE * 500.0,
        nail_range: tuple = (_SCALE * -0.01, _SCALE * 0.09),
        nail_frictionloss: float = 2.5,
        dist_penalty_weight: float = 0.1,
        head_nail_weight: float = 1.0,
        insert_weight: float = 10.0,
        vel_penalty_weight: float = 1e-2,
        lift_thresh: float = None,       # derived below -- relative to the hammer's own spawn
        lift_bonus: float = 2.0,
        close_thresh: float = _SCALE * 0.02,
        close_bonus: float = 25.0,
        very_close_thresh: float = _SCALE * 0.01,
        very_close_bonus: float = 75.0,
        **kwargs,
    ):
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=_ROOT_AXES,
            hover_height=hover_height,
            **kwargs,
        )
        self.handle_length = handle_length
        self.handle_radius = handle_radius
        self.handle_density = handle_density
        self.head_offset = head_offset
        self.head_length = head_length
        self.head_radius = head_radius
        self.head_density = head_density
        # Hand-anchored placements, all measured off `hover_height` -- the height every morphology's
        # lowest extent sits at (see `AdroitTask.set_root_pose`). The hammer hangs one gap below it
        # so nothing intersects the body at rest; the board sits from that height upwards, keeping
        # its own half-height clear of the ground plane at the bottom of its range.
        self.hammer_pos = hammer_pos if hammer_pos is not None else (
            0.0, hover_height - handle_radius - _PROP_GAP, _SCALE * -0.15)
        self.board_half_extent = board_half_extent
        self.board_density = board_density
        self.board_x = board_x
        self.board_z = board_z
        self.board_y_range = board_y_range if board_y_range is not None else (
            hover_height, hover_height + _SCALE * 0.15)
        self.nail_goal_offset = nail_goal_offset
        self.nail_radius = nail_radius
        self.nail_length = nail_length
        self.nail_density = nail_density
        self.nail_range = nail_range
        self.nail_frictionloss = nail_frictionloss
        self.dist_penalty_weight = dist_penalty_weight
        self.head_nail_weight = head_nail_weight
        self.insert_weight = insert_weight
        self.vel_penalty_weight = vel_penalty_weight
        # The source's 0.04 against a 0.05 spawn: "has not dropped below where it started". Kept as
        # that relationship rather than as an absolute, since the spawn is no longer a fixed number.
        self.lift_thresh = lift_thresh if lift_thresh is not None else (
            self.hammer_pos[1] - _SCALE * 0.01)
        self.lift_bonus = lift_bonus
        self.close_thresh = close_thresh
        self.close_bonus = close_bonus
        self.very_close_thresh = very_close_thresh
        self.very_close_bonus = very_close_bonus
        self._hammer_handles = []
        self._board_handles = []

    def create_scene(self):
        create_plane(self.gym)

    def create_props(self, env_def, group_index: int, morph):
        """Two props: the free hammer, a rigid body (`handle` + `head`, merged at import across their
        `fixed` joint), and the fixed nail/board articulation (`board` -[prismatic]-> `nail`). Both
        handle lists are rebuilt on `group_index == 0`; the name -> index lookups are computed once
        there too, same reasoning as `Door`'s (every group imports identical generated files)."""
        if group_index == 0:
            self._hammer_handles = []
            self._board_handles = []

        hb = PropBuilder("hammer")
        hb.add_link("handle", self.handle_density,
                   [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "cylinder",
                                 (self.handle_length, self.handle_radius))])
        hb.add_link("head", self.head_density,
                   [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "cylinder",
                                 (self.head_length, self.head_radius))])
        hb.add_joint("head_weld", "fixed", "handle", "head", f"{-self.head_offset} 0.0 0.0")
        hpath = write_prop_vsim(hb.build(), "hammer", group_index)
        # Merged at import into ONE rigid body carrying both collision shapes -- see the module
        # docstring. The head's mass is wanted; only its separate identity is not available.
        env_def.import_definitions(str(hpath), fixed=False)
        hammer_def_handle = env_def.get_rigid_body_def_handle_by_name("hammer")
        hammer_init_tf = v.Transform(v.Quat(0, 0, 0, 1), v.Vec3(*self.hammer_pos))
        hammer_handle = env_def.create_rigid_body(hammer_def_handle, hammer_init_tf, "hammer")

        nb = PropBuilder("nail_board")
        nb.add_link("board", self.board_density,
                   [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "box", self.board_half_extent)])
        nb.add_link("nail", self.nail_density,
                   [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "cylinder",
                                 (self.nail_length, self.nail_radius))])
        nb.add_joint("nail_dir", "prismatic", "board", "nail", "0.0 0.0 0.0", axis="0.0 0.0 1.0",
                    limits=(str(self.nail_range[0]), str(self.nail_range[1])),
                    dynamics=f'frictionloss="{self.nail_frictionloss}"')
        npath = write_prop_vsim(nb.build(), "nail_board", group_index)
        env_def.import_definitions(str(npath), fixed=True)
        board_def_handle = env_def.get_articulation_def_handle_by_name("nail_board")
        board_init_tf = v.Transform(v.Quat(0, 0, 0, 1), v.Vec3(
            self.board_x, sum(self.board_y_range) / 2, self.board_z))
        board_handle = env_def.create_articulation(board_def_handle, board_init_tf, "nail_board")

        if group_index == 0:
            board_art_def = env_def.get_articulation_def(board_def_handle)
            dof_names = [board_art_def.get_joint_dof_def_name(k)
                        for k in range(board_art_def.get_num_joint_dof_defs())]
            self._nail_col = dof_names.index("nail_dir")
            link_names = [board_art_def.get_link_def_name(k)
                         for k in range(board_art_def.get_num_link_defs())]
            self._nail_link_k = link_names.index("nail")
            self._board_link_k = link_names.index("board")
            self._n_board_links = len(link_names)

        self._hammer_handles.append(hammer_handle)
        self._board_handles.append(board_handle)

    def allocate_buffers(self):
        super().allocate_buffers()
        N, EPM = self.total_num_envs, self.envs_per_morph

        # Hammer: one free rigid body (handle + head merged at import) -- its motion is entirely the
        # pose/vel GET/SET, the same mechanism Relocate's ball and Ant's free-floating root use.
        self._get_hammer_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._get_hammer_vel = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_hammer_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._set_hammer_vel = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_hammer_pose[:, 3] = 1.0
        self._set_hammer_pose[:, 4] = self.hammer_pos[0]
        self._set_hammer_pose[:, 5] = self.hammer_pos[1]
        self._set_hammer_pose[:, 6] = self.hammer_pos[2]

        # Nail/board: fixed base (board), 1 real DOF (nail_dir). Two links, board and nail.
        nbl = self._n_board_links
        self._get_nail_dof = torch.zeros((N, 1), dtype=torch.float32, device=self.device)
        self._get_nail_dof_vel = torch.zeros((N, 1), dtype=torch.float32, device=self.device)
        self._get_board_link_pose = torch.zeros((N, nbl * 7), dtype=torch.float32, device=self.device)
        self._get_board_link_vel = torch.zeros((N, nbl * 6), dtype=torch.float32, device=self.device)
        self._set_nail_dof = torch.zeros((N, 1), dtype=torch.float32, device=self.device)
        self._set_nail_dof_vel = torch.zeros((N, 1), dtype=torch.float32, device=self.device)
        self._set_board_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._set_board_vel = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_board_pose[:, 3] = 1.0
        self._set_board_pose[:, 4] = self.board_x
        self._set_board_pose[:, 6] = self.board_z

        # Four arrays, not two: `create_gpu_array` requires every command in a list to be the same
        # type, and the hammer is now a rigid body while the board is still an articulation.
        h_get, h_set, b_get, b_set = [], [], [], []
        for gi, g in enumerate(self.groups):
            start, end = gi * EPM, (gi + 1) * EPM
            h_get.append(g["env_group"].create_rigid_body_kinematic_state_command(
                v.wrap_gpu_buffer(self._get_hammer_pose[start:end]),
                v.wrap_gpu_buffer(self._get_hammer_vel[start:end]),
                rigid_body_handle=self._hammer_handles[gi],
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            h_set.append(g["env_group"].create_rigid_body_kinematic_state_command(
                v.wrap_gpu_buffer(self._set_hammer_pose[start:end]),
                v.wrap_gpu_buffer(self._set_hammer_vel[start:end]),
                rigid_body_handle=self._hammer_handles[gi],
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
                masks_buffer=v.wrap_gpu_buffer(self._reset_buf[start:end]),
            ))
            b_get.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(self._get_nail_dof[start:end]),
                v.wrap_gpu_buffer(self._get_nail_dof_vel[start:end]),
                v.wrap_gpu_buffer(self._get_board_link_pose[start:end]),
                v.wrap_gpu_buffer(self._get_board_link_vel[start:end]),
                self._board_handles[gi], link_index_range=(0, nbl),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            b_set.append(g["env_group"].create_articulation_kinematic_state_command(
                v.wrap_gpu_buffer(self._set_nail_dof[start:end]),
                v.wrap_gpu_buffer(self._set_nail_dof_vel[start:end]),
                v.wrap_gpu_buffer(self._set_board_pose[start:end]),
                v.wrap_gpu_buffer(self._set_board_vel[start:end]),
                self._board_handles[gi], link_index_range=(0, 1),
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
                masks_buffer=v.wrap_gpu_buffer(self._reset_buf[start:end]),
            ))
        self._hammer_get_cmd_array = self.gym.create_gpu_array(h_get)
        self._hammer_set_cmd_array = self.gym.create_gpu_array(h_set)
        self._board_get_cmd_array = self.gym.create_gpu_array(b_get)
        self._board_set_cmd_array = self.gym.create_gpu_array(b_set)

        # The nail's fully-driven-in target depth, in the board's local frame -- a site in the
        # source, so it carries no mass and gets no link of its own here (see the module docstring).
        self._goal_local = torch.zeros((N, 3), dtype=torch.float32, device=self.device)
        self._goal_local[:, 2] = self.nail_goal_offset
        # The head's weld offset in the handle's frame -- see `_head_pos`.
        self._head_local = torch.zeros((N, 3), dtype=torch.float32, device=self.device)
        self._head_local[:, 0] = -self.head_offset

        # Target indicator (CONTEXT.md): a wireframe cube at the nail's fully-driven-in depth,
        # headed mode only. The board is a fixed base (never rotates -- see _draw_board), so its
        # SET pose is already the env-local point this needs; no need to wait on a GET readback.
        self._goal_cubes = self.create_indicator_cubes(size=4.0 * self.nail_radius)

        self._draw_board(torch.ones(N, dtype=torch.bool, device=self.device))

    def reset_idx(self):
        super().reset_idx()
        self._draw_board(self._reset_buf)
        self.gym.set_rigid_body_kinematic_states(self._hammer_set_cmd_array)
        self.gym.set_articulation_kinematic_states(self._board_set_cmd_array)

    def _draw_board(self, mask: torch.Tensor):
        """Redraw the board's height (env-local frame) for resetting envs -- the source only
        randomizes this one axis (see the module docstring); x/z stay at the constants written in
        `allocate_buffers`. The hammer's SET pose is a constant, never redrawn."""
        m = mask.unsqueeze(-1)
        n = self._set_board_pose.shape[0]
        lo, hi = self.board_y_range
        y = torch.rand((n, 1), device=self.device) * (hi - lo) + lo
        self._set_board_pose[:, 5:6] = torch.where(m, y, self._set_board_pose[:, 5:6])

        if self._goal_cubes:
            identity = v.Quat(0, 0, 0, 1)
            for i in mask.nonzero(as_tuple=True)[0].tolist():
                pos = v.Vec3(self.board_x, float(self._set_board_pose[i, 5]),
                             self.board_z + self.nail_goal_offset)
                self._goal_cubes[i].set_transform(v.Transform(identity, pos))

    def obs_fields(self) -> dict:
        # hammer, head, nail, goal + 3 diffs, xyz each; the palm itself is AdroitTask's
        return {**super().obs_fields(),
                "hammer":         GlobalField(3),
                "head":           GlobalField(3),
                "nail":           GlobalField(3),
                "goal":           GlobalField(3),
                "palm_to_hammer": GlobalField(3),
                "head_to_nail":   GlobalField(3),
                "nail_to_goal":   GlobalField(3)}

    def compute_observations(self):
        self.gym.get_rigid_body_kinematic_states(self._hammer_get_cmd_array)
        self.gym.get_articulation_kinematic_states(self._board_get_cmd_array)
        super().compute_observations()

        palm = self._get_root_pose[:, 4:7]
        hammer_pos = self._hammer_pos()
        head_pos = self._head_pos()
        nail_pos = self._nail_pos()
        goal_pos = self._goal_pos()

        self.obs("hammer")[:] = hammer_pos
        self.obs("head")[:] = head_pos
        self.obs("nail")[:] = nail_pos
        self.obs("goal")[:] = goal_pos
        self.obs("palm_to_hammer")[:] = palm - hammer_pos
        self.obs("head_to_nail")[:] = head_pos - nail_pos
        self.obs("nail_to_goal")[:] = nail_pos - goal_pos

    def _hammer_pos(self) -> torch.Tensor:
        return self._get_hammer_pose[:, 4:7]

    def _head_pos(self) -> torch.Tensor:
        """The strike point: the head's weld offset carried into world space by the merged body's
        own pose. `head_weld` puts the head at `(-head_offset, 0, 0)` in the handle's frame, so this
        is exactly the position the separate `head` link used to report."""
        return self._hammer_pos() + quat_rotate(self._get_hammer_pose[:, 0:4], self._head_local)

    def _nail_pos(self) -> torch.Tensor:
        return self._get_board_link_pose.view(-1, self._n_board_links, 7)[:, self._nail_link_k, 4:7]

    def _goal_pos(self) -> torch.Tensor:
        """Where the nail is fully driven in: a fixed offset in the board's frame. The board is a
        fixed base but is repositioned per episode (`_draw_board`), so this is read off its live
        pose rather than precomputed."""
        board = self._get_board_link_pose.view(-1, self._n_board_links, 7)[:, self._board_link_k]
        return board[:, 4:7] + quat_rotate(board[:, 0:4], self._goal_local)

    def compute_reward_termination_truncation(self):
        # Robot-only DOF velocities, as in Door -- see the module docstring's velocity-penalty note.
        dof_vel = self._flat_get_dof_vel[self._dof_gather_idx] * self._global_dof_mask
        dof_vel_norm = torch.norm(dof_vel, dim=-1)

        self.reward_term_trunc_helper_jit(
            self._rew_buf, self._next_term_buf, self._next_trunc_buf,
            self._get_root_pose[:, 4:7], self._hammer_pos(), self._head_pos(),
            self._nail_pos(), self._goal_pos(), dof_vel_norm,
            self.dist_penalty_weight, self.head_nail_weight, self.insert_weight,
            self.vel_penalty_weight, self.lift_thresh, self.lift_bonus,
            self.close_thresh, self.close_bonus, self.very_close_thresh, self.very_close_bonus,
            self._progress_buf, self.max_episode_length,
        )

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        palm_pos: torch.Tensor,
        hammer_pos: torch.Tensor,
        head_pos: torch.Tensor,
        nail_pos: torch.Tensor,
        goal_pos: torch.Tensor,
        dof_vel_norm: torch.Tensor,
        dist_penalty_weight: float,
        head_nail_weight: float,
        insert_weight: float,
        vel_penalty_weight: float,
        lift_thresh: float,
        lift_bonus: float,
        close_thresh: float,
        close_bonus: float,
        very_close_thresh: float,
        very_close_bonus: float,
        progress: torch.Tensor,
        max_episode_length: int,
    ):
        """`AdroitHandHammerEnv.step`'s dense reward, sign-corrected on the first term (see the module
        docstring): distance-to-hammer penalty, distance from hammer head to nail, distance from nail
        to its fully-driven depth (scaled x10), a (robot-only) velocity penalty, a lift bonus, and two
        insertion bonuses. Never terminates -- truncates at the time limit, same as the source env.
        """
        palm_to_hammer = torch.norm(palm_pos - hammer_pos, dim=-1)
        head_to_nail = torch.norm(head_pos - nail_pos, dim=-1)
        goal_distance = torch.norm(nail_pos - goal_pos, dim=-1)
        lifted = (hammer_pos[:, 1] > lift_thresh) & (head_pos[:, 1] > lift_thresh)   # Y is up

        reward = -dist_penalty_weight * palm_to_hammer
        reward = reward - head_nail_weight * head_to_nail
        reward = reward - insert_weight * goal_distance
        reward = reward - vel_penalty_weight * dof_vel_norm
        reward = reward + torch.where(lifted, lift_bonus, 0.0)
        reward = reward + torch.where(goal_distance < close_thresh, close_bonus, 0.0)
        reward = reward + torch.where(goal_distance < very_close_thresh, very_close_bonus, 0.0)

        rew_buf[:] = reward
        term_buf[:] = False
        trunc_buf[:] = progress >= max_episode_length
