"""Pen: reorient a pen in-hand to match a randomized target orientation, wrist fully welded.

Ported from gymnasium-robotics' `AdroitHandPenEnv` (dense reward variant). `root_axes = []` -- the
forearm has no joints at all in the source XML (unlike Door/Hammer/Relocate, which each actuate some
subset), so `AdroitTask` mounts it world-fixed with nothing to move; only the hand's own WRJ0/WRJ1
and finger joints reposition the pen, exactly as `AdroitHandPenEnv`'s doc says ("the base of the
hand is fixed"). One Prop: the pen itself, a free single-link **rigid body**, whose world-space
orientation vector is its own quaternion applied to its local long axis (`+X`) -- what the source's
`object_top`/`object_bottom` site pair computes the long way round.

**No marker link.** An earlier port welded a `pen_tip` link on with a `fixed` joint and took
`tip_pos - body_pos`, mirroring the source's two sites. VSim cannot represent that: `import_
definitions` merges fixed-jointed links by default (`merge_fixed_joints=True`) and demotes the
resulting single-link def to a rigid body, and forcing the links apart only trades that for a 0-DOF
articulation, which `create_articulation_kinematic_state_command` rejects outright (`invalid
dofIndexRange` -- the default range is `[0, num_dofs)`, and a `fixed` joint is not a DOF). The
marker sat at a constant local offset regardless, so `quat_rotate(q, +X)` is not an approximation of
the old quantity, it is exactly it -- and it avoids the merged body's frame landing on the pair's
combined COM rather than on the pen.

**The target has no body in this port.** The source spins up a whole extra `target` body purely to
read two site positions off it (`target_top`/`target_bottom`) and take their difference -- the target
never touches anything, is never affected by physics, and its *position* is never even randomized
(only its orientation is, via `body_quat`). That is exactly the shape of `Grasp`'s `_target_pose`: a
plain per-env tensor redrawn at reset, no physics body needed. `_target_orien` is that tensor here,
holding a randomized unit vector directly instead of a quaternion + a pair of sites to extract one
from.

**Departures from the source env**, beyond the ones `AdroitTask` already documents:

- Unlike Relocate/Door/Hammer's "get to X" term, this task's position term (`-goal_distance`) has the
  *correct* sign already in the source -- no fix needed here.
- The source's own doc table claims the position term is "scaled by a factor of 0.1", but the shipped
  `step()` applies no such scaling (`reward = -goal_distance + orien_similarity`, unweighted). Ported
  to match the code that actually runs, the same principle behind the sign fixes elsewhere: `dist_
  weight` defaults to `1.0`, not `0.1`, and is exposed as a kwarg for parity with the other tasks'
  weight knobs regardless.
- The source's doc table also claims the episode `terminated`s on success, but the line that would do
  that is commented out in the shipped `step()` (`# goal_failed or goal_achieved,`) -- it always
  returns `False`. Ported the same way as every other task here: never terminates, truncates at the
  time limit.
- `desired_loc` (the position the pen must stay near) is the constant `eps_ball` site position in the
  source, which is numerically identical to the pen's own constant spawn position -- reset_model never
  moves either the pen or `eps_ball`, only the target's orientation. Ported as one constant tensor,
  written once in `allocate_buffers` and never redrawn, rather than as a second Prop.
- The source samples the target's orientation via `euler2quat` applied to a MuJoCo `body_quat`, then
  recovers a direction from two more sites. Reimplemented directly as a randomized unit vector --
  two rotations (about the up axis, then a horizontal axis) of the pen's own rest-axis direction, by
  angles of the same magnitude (`+-1.0` rad) as the source's random roll/pitch -- since there is no
  target body here to carry a quaternion through.
- **No gravity, and the pen hangs off the hand.** This task needs it more than any other: the wrist
  is fully welded (`root_axes = []`), so the hand cannot descend to meet a pen that has fallen away
  from it, and the source's spawn height was picked for one fixed rig rather than for whatever body
  the Algorithm supplied. The pen is placed one gap below the hand's own lowest extent -- a constant
  height, since `AdroitTask`'s Mount clearance puts every morphology's fingertips at exactly
  `hover_height` -- and with gravity off it stays there for the fingers to close on. `drop_penalty`
  consequently never fires; left in place for the same reason `Hammer` keeps its `lift_bonus`.
"""
import torch
import vlearn as v
from vlearn.torch_utils.torch_jit_utils import quat_rotate

from codesigner.backend.build_vsim import collision_xml
from codesigner.backend.props import PropBuilder, write_prop_vsim
from codesigner.backend.vlearn_helpers import create_plane
from codesigner.components.tasks.adroit.adroit import (AdroitTask, _DENSITY_SCALE, _PROP_GAP,
                                                       _SCALE)
from codesigner.interfaces import GlobalField

_ROOT_AXES: list = []           # welded: world-fixed, and not one axis of freedom


class Pen(AdroitTask):

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int = 200,
        gravity: v.Vec3 = v.Vec3(0, 0, 0),   # see the module docstring
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 6.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        hover_height: float = 0.5,
        pen_length: float = _SCALE * 0.13,
        pen_radius: float = _SCALE * 0.015,   # an earlier port had 0.008 here, a copy error
        pen_density: float = _DENSITY_SCALE * 200.0,
        pen_spawn_pos: tuple = None,          # derived below -- hangs under the hand
        target_angle_range: float = 1.0,
        dist_weight: float = 1.0,
        close_thresh: float = _SCALE * 0.075,
        orien_thresh1: float = 0.9,
        close_bonus1: float = 10.0,
        orien_thresh2: float = 0.95,
        close_bonus2: float = 50.0,
        drop_height: float = None,            # derived below -- relative to the pen's own spawn
        drop_penalty: float = 5.0,
        **kwargs,
    ):
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=_ROOT_AXES,
            hover_height=hover_height,
            **kwargs,
        )
        self.pen_length = pen_length
        self.pen_radius = pen_radius
        self.pen_density = pen_density
        # One gap below the hand's lowest extent, which `hover_height` is by definition (see
        # `AdroitTask.set_root_pose`), so the pen never starts inside the body whatever its shape.
        self.pen_spawn_pos = pen_spawn_pos if pen_spawn_pos is not None else (
            0.0, hover_height - pen_radius - _PROP_GAP, _SCALE * -0.2)
        self.target_angle_range = target_angle_range
        self.dist_weight = dist_weight
        self.close_thresh = close_thresh
        self.orien_thresh1 = orien_thresh1
        self.close_bonus1 = close_bonus1
        self.orien_thresh2 = orien_thresh2
        self.close_bonus2 = close_bonus2
        # The source's 0.075 against a 0.25 spawn: "has fallen 0.175 below where it started". Kept
        # as that relationship rather than as an absolute, since the spawn is no longer fixed.
        self.drop_height = drop_height if drop_height is not None else (
            self.pen_spawn_pos[1] - _SCALE * 0.175)
        self.drop_penalty = drop_penalty
        self._pen_handles = []

    def create_scene(self):
        create_plane(self.gym)

    def create_props(self, env_def, group_index: int, morph):
        """One free single-link rigid body: the pen, a cylinder along its own local X.
        `_pen_handles` is rebuilt on `group_index == 0`, same reasoning as every other task's handle
        list."""
        if group_index == 0:
            self._pen_handles = []

        b = PropBuilder("pen")
        b.add_link("pen_body", self.pen_density,
                  [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "cylinder",
                                (self.pen_length, self.pen_radius))])
        path = write_prop_vsim(b.build(), "pen", group_index)
        env_def.import_definitions(str(path), fixed=False)

        pen_def_handle = env_def.get_rigid_body_def_handle_by_name("pen")
        init_tf = v.Transform(v.Quat(0, 0, 0, 1), v.Vec3(*self.pen_spawn_pos))
        self._pen_handles.append(env_def.create_rigid_body(pen_def_handle, init_tf, "pen"))

    def allocate_buffers(self):
        super().allocate_buffers()
        N, EPM = self.total_num_envs, self.envs_per_morph

        self._get_pen_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._get_pen_vel = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_pen_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._set_pen_vel = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_pen_pose[:, 3] = 1.0
        self._set_pen_pose[:, 4] = self.pen_spawn_pos[0]
        self._set_pen_pose[:, 5] = self.pen_spawn_pos[1]
        self._set_pen_pose[:, 6] = self.pen_spawn_pos[2]

        # Constant -- see the module docstring: the source's `eps_ball` tolerance sphere never
        # moves, and sits exactly on the pen's own constant spawn position.
        self._desired_loc = torch.tensor(self.pen_spawn_pos, dtype=torch.float32,
                                         device=self.device).unsqueeze(0).expand(N, 3).contiguous()
        self._target_orien = torch.zeros((N, 3), dtype=torch.float32, device=self.device)
        # The pen's own long axis in its local frame: the collision cylinder is laid out along X,
        # and the world-space orientation vector is this rotated by the body's quaternion.
        self._pen_axis_local = torch.zeros((N, 3), dtype=torch.float32, device=self.device)
        self._pen_axis_local[:, 0] = 1.0

        # Target indicator (CONTEXT.md): a line along the target axis, anchored at the pen's
        # (constant) home position -- headed mode only. A line rather than a cube since the target
        # is a pure orientation, no position of its own.
        self._target_lines = self.create_indicator_lines(
            points=[v.Vec3(0, 0, 0), v.Vec3(self.pen_length, 0, 0)])

        get_cmds, set_cmds = [], []
        for gi, g in enumerate(self.groups):
            start, end = gi * EPM, (gi + 1) * EPM
            get_cmds.append(g["env_group"].create_rigid_body_kinematic_state_command(
                v.wrap_gpu_buffer(self._get_pen_pose[start:end]),
                v.wrap_gpu_buffer(self._get_pen_vel[start:end]),
                rigid_body_handle=self._pen_handles[gi],
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            set_cmds.append(g["env_group"].create_rigid_body_kinematic_state_command(
                v.wrap_gpu_buffer(self._set_pen_pose[start:end]),
                v.wrap_gpu_buffer(self._set_pen_vel[start:end]),
                rigid_body_handle=self._pen_handles[gi],
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
                masks_buffer=v.wrap_gpu_buffer(self._reset_buf[start:end]),
            ))
        self._pen_get_cmd_array = self.gym.create_gpu_array(get_cmds)
        self._pen_set_cmd_array = self.gym.create_gpu_array(set_cmds)

        self._draw_target(torch.ones(N, dtype=torch.bool, device=self.device))

    def reset_idx(self):
        super().reset_idx()
        self._draw_target(self._reset_buf)
        self.gym.set_rigid_body_kinematic_states(self._pen_set_cmd_array)

    def _draw_target(self, mask: torch.Tensor):
        """Redraw the target orientation for resetting envs: the pen's own rest axis (world X),
        rotated by two random angles of the same +-1 rad magnitude as the source's random roll/
        pitch -- see the module docstring. The pen's own SET pose is a constant, never redrawn."""
        m = mask.unsqueeze(-1)
        n = self._target_orien.shape[0]
        r = self.target_angle_range
        a = (torch.rand(n, device=self.device) * 2.0 - 1.0) * r
        b = (torch.rand(n, device=self.device) * 2.0 - 1.0) * r

        ca, sa = torch.cos(a), torch.sin(a)
        x1, y1, z1 = ca, torch.zeros_like(a), -sa       # rotate (1,0,0) about the up axis (Y)
        cb, sb = torch.cos(b), torch.sin(b)
        x2 = x1 * cb                                     # rotate about the horizontal axis (Z)
        y2 = x1 * sb
        z2 = z1
        new = torch.stack([x2, y2, z2], dim=-1)

        self._target_orien[:] = torch.where(m, new, self._target_orien)

        if self._target_lines:
            pos = v.Vec3(*self.pen_spawn_pos)
            for i in mask.nonzero(as_tuple=True)[0].tolist():
                direction = v.Vec3(*self._target_orien[i].tolist())
                rot = v.shortest_rotation(v.Vec3(1, 0, 0), direction)
                self._target_lines[i].set_transform(v.Transform(rot, pos))

    def obs_fields(self) -> dict:
        return {**super().obs_fields(),
                "pen_pos":         GlobalField(3),
                "pen_orien":       GlobalField(3),
                "target_orien":    GlobalField(3),
                "pen_to_desired":  GlobalField(3),
                "orien_to_target": GlobalField(3)}

    def compute_observations(self):
        self.gym.get_rigid_body_kinematic_states(self._pen_get_cmd_array)
        super().compute_observations()

        pen_pos = self._pen_pos()
        pen_orien = self._pen_orien()

        self.obs("pen_pos")[:] = pen_pos
        self.obs("pen_orien")[:] = pen_orien
        self.obs("target_orien")[:] = self._target_orien
        self.obs("pen_to_desired")[:] = pen_pos - self._desired_loc
        self.obs("orien_to_target")[:] = pen_orien - self._target_orien

    def _pen_pos(self) -> torch.Tensor:
        return self._get_pen_pose[:, 4:7]

    def _pen_orien(self) -> torch.Tensor:
        """Unit vector along the pen's long axis, in world space: its local +X rotated by its own
        quaternion (pose layout is xyzw then xyz, which is `quat_rotate`'s convention). Unit by
        construction for a unit quaternion; normalized anyway, since the engine's quaternion is not
        contractually renormalized every step."""
        return torch.nn.functional.normalize(
            quat_rotate(self._get_pen_pose[:, 0:4], self._pen_axis_local), dim=-1)

    def compute_reward_termination_truncation(self):
        self.reward_term_trunc_helper_jit(
            self._rew_buf, self._next_term_buf, self._next_trunc_buf,
            self._pen_pos(), self._pen_orien(), self._target_orien, self._desired_loc,
            self.dist_weight, self.close_thresh, self.orien_thresh1, self.close_bonus1,
            self.orien_thresh2, self.close_bonus2, self.drop_height, self.drop_penalty,
            self._progress_buf, self.max_episode_length,
        )

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        pen_pos: torch.Tensor,
        pen_orien: torch.Tensor,
        target_orien: torch.Tensor,
        desired_loc: torch.Tensor,
        dist_weight: float,
        close_thresh: float,
        orien_thresh1: float,
        close_bonus1: float,
        orien_thresh2: float,
        close_bonus2: float,
        drop_height: float,
        drop_penalty: float,
        progress: torch.Tensor,
        max_episode_length: int,
    ):
        """`AdroitHandPenEnv.step`'s dense reward, as actually shipped (see the module docstring for
        the two places its doc and its code disagree): distance from the pen to its constant home
        position, plus orientation similarity to the target, two proximity+alignment bonuses, and a
        drop penalty. Never terminates -- truncates at the time limit.
        """
        goal_distance = torch.norm(pen_pos - desired_loc, dim=-1)
        orien_similarity = (pen_orien * target_orien).sum(dim=-1)
        close = goal_distance < close_thresh

        reward = -dist_weight * goal_distance + orien_similarity
        reward = reward + torch.where(close & (orien_similarity > orien_thresh1), close_bonus1, 0.0)
        reward = reward + torch.where(close & (orien_similarity > orien_thresh2), close_bonus2, 0.0)
        reward = reward + torch.where(pen_pos[:, 1] < drop_height, -drop_penalty, 0.0)   # Y is up

        rew_buf[:] = reward
        term_buf[:] = False
        trunc_buf[:] = progress >= max_episode_length
