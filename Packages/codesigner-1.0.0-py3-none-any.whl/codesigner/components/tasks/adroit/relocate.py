"""Relocate: move a ball to a randomized target position, hand mounted on a fully actuated wrist.

Ported from gymnasium-robotics' `AdroitHandRelocateEnv` (dense reward variant). The simplest of the
four Adroit tasks -- no hinges, one free Prop -- so it is the template the other three extend
(CONTEXT.md's Prop entry; `create_props` on `interfaces.task.Task`).

**Departures from the source env**, beyond the ones `AdroitTask` already documents:

- The source's dense reward has `reward = 0.1 * ||palm - ball||` for the "get to ball" term --
  *positive*, so it trains the hand away from the ball. Its own docstring says "increasing negative
  reward the further away", and the installed package's own import-time warning notes this reward
  changed between 1.2.0 and 1.4.3 without a version bump. Ported here with the sign the docstring
  and the original D4RL formulation both intend: `-0.1 * ||palm - ball||`.
- "Palm" is the hand's root link position (`_get_root_pose`), not a named `S_grasp` site -- a
  codesigned hand has no fixed palm geometry to put a site on, and the root link is the one point
  every morphology has in common.
- Root-mount ranges are adapted to this engine's Y-up convention rather than copied axis-for-axis
  from the source's rotated forearm-local frame (see `AdroitTask`); the *rotation* ranges are ported
  numerically (Adroit's ARRx/ARRy/ARRz are all +-0.75 rad here too), since a rotation range means the
  same thing regardless of which world axis it is expressed against.
"""
import torch
import vlearn as v

from codesigner.backend.build_vsim import collision_xml
from codesigner.backend.props import PropBuilder, write_prop_vsim
from codesigner.backend.vlearn_helpers import create_plane
from codesigner.components.tasks.adroit.adroit import AdroitTask, _DENSITY_SCALE, _SCALE
from codesigner.interfaces import GlobalField
from codesigner.interfaces.modlib import RootAxis

# A fully actuated wrist. Translation limits scale with everything else -- the ball spreads over a
# 6x wider patch of floor, so a wrist held to the source's +-0.3m would never get above most of it.
# Rotations do not scale.
_ROOT_AXES = [
    RootAxis.slide("x", (_SCALE * -0.3, _SCALE * 0.3)),
    RootAxis.slide("y", (_SCALE * -0.2, _SCALE * 0.3)),
    RootAxis.slide("z", (_SCALE * -0.3, _SCALE * 0.3)),
    RootAxis.hinge("x", (-0.75, 0.75)),
    RootAxis.hinge("y", (-0.75, 0.75)),
    RootAxis.hinge("z", (-0.75, 0.75)),
]


class Relocate(AdroitTask):

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int = 200,
        gravity: v.Vec3 = v.Vec3(0, -9.81, 0),
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 6.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        hover_height: float = 0.5,
        ball_radius: float = _SCALE * 0.035,
        ball_density: float = _DENSITY_SCALE * 1000.0,
        ball_x_range: tuple = (_SCALE * -0.15, _SCALE * 0.15),
        ball_z_range: tuple = (_SCALE * -0.15, _SCALE * 0.3),
        target_x_range: tuple = (_SCALE * -0.2, _SCALE * 0.2),
        target_z_range: tuple = (_SCALE * -0.2, _SCALE * 0.2),
        target_y_range: tuple = (_SCALE * 0.15, _SCALE * 0.35),
        lift_threshold: float = _SCALE * 0.04,
        dist_penalty_weight: float = 0.1,
        lift_bonus: float = 1.0,
        target_dist_weight: float = 0.5,
        close_thresh: float = _SCALE * 0.1,
        close_bonus: float = 10.0,
        very_close_thresh: float = _SCALE * 0.05,
        very_close_bonus: float = 20.0,
        **kwargs,
    ):
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=_ROOT_AXES,
            hover_height=hover_height,
            **kwargs,
        )
        self.ball_radius = ball_radius
        self.ball_density = ball_density
        self.ball_x_range = ball_x_range
        self.ball_z_range = ball_z_range
        self.target_x_range = target_x_range
        self.target_z_range = target_z_range
        self.target_y_range = target_y_range
        self.lift_threshold = lift_threshold
        self.dist_penalty_weight = dist_penalty_weight
        self.lift_bonus = lift_bonus
        self.target_dist_weight = target_dist_weight
        self.close_thresh = close_thresh
        self.close_bonus = close_bonus
        self.very_close_thresh = very_close_thresh
        self.very_close_bonus = very_close_bonus
        self._ball_handles = []

    def create_scene(self):
        create_plane(self.gym)

    def create_props(self, env_def, group_index: int, morph):
        """One free rigid body: the ball. `_ball_handles` is rebuilt from scratch every time
        `create_envs` starts a fresh pass (`group_index == 0` is that pass's first call) -- a rebuild
        tears the whole scene down, so stale handles from the previous one must not linger."""
        if group_index == 0:
            self._ball_handles = []

        b = PropBuilder("ball")
        b.add_link("ball", self.ball_density,
                  [collision_xml("0.0 0.0 0.0", "0.0 0.0 0.0 1.0", "sphere", (self.ball_radius,))])
        path = write_prop_vsim(b.build(), "ball", group_index)
        env_def.import_definitions(str(path), fixed=False)
        ball_def_handle = env_def.get_rigid_body_def_handle_by_name("ball")

        init_tf = v.Transform(v.Quat(0, 0, 0, 1), v.Vec3(0, self.ball_radius, 0))
        self._ball_handles.append(env_def.create_rigid_body(ball_def_handle, init_tf, "ball"))

    def allocate_buffers(self):
        super().allocate_buffers()
        N, EPM = self.total_num_envs, self.envs_per_morph

        self._get_ball_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._get_ball_vel  = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_ball_pose = torch.zeros((N, 7), dtype=torch.float32, device=self.device)
        self._set_ball_vel  = torch.zeros((N, 6), dtype=torch.float32, device=self.device)
        self._set_ball_pose[:, 3] = 1.0                  # identity quat (qw); never redrawn
        self._set_ball_pose[:, 5] = self.ball_radius      # resting height (Y, up); never redrawn
        self._target_pos = torch.zeros((N, 3), dtype=torch.float32, device=self.device)
        # Target indicator (CONTEXT.md): a wireframe cube the size of the ball, headed mode only.
        self._target_cubes = self.create_indicator_cubes(size=2.0 * self.ball_radius)

        get_cmds, set_cmds = [], []
        for gi, g in enumerate(self.groups):
            start, end = gi * EPM, (gi + 1) * EPM
            get_cmds.append(g["env_group"].create_rigid_body_kinematic_state_command(
                v.wrap_gpu_buffer(self._get_ball_pose[start:end]),
                v.wrap_gpu_buffer(self._get_ball_vel[start:end]),
                rigid_body_handle=self._ball_handles[gi],
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
            ))
            set_cmds.append(g["env_group"].create_rigid_body_kinematic_state_command(
                v.wrap_gpu_buffer(self._set_ball_pose[start:end]),
                v.wrap_gpu_buffer(self._set_ball_vel[start:end]),
                rigid_body_handle=self._ball_handles[gi],
                transform_type=v.TransformType.MODEL, frame_type=v.FrameType.ENVIRONMENT,
                masks_buffer=v.wrap_gpu_buffer(self._reset_buf[start:end]),
            ))
        self._ball_get_cmd_array = self.gym.create_gpu_array(get_cmds)
        self._ball_set_cmd_array = self.gym.create_gpu_array(set_cmds)

        # Buffer hygiene only -- the physics push happens through reset_idx, once the gym is
        # finalized. Safe to draw here regardless, same as Grasp's _draw_targets at allocate time.
        self._draw_ball_and_target(torch.ones(N, dtype=torch.bool, device=self.device))

    def reset_idx(self):
        super().reset_idx()
        self._draw_ball_and_target(self._reset_buf)
        self.gym.set_rigid_body_kinematic_states(self._ball_set_cmd_array)

    def _draw_ball_and_target(self, mask: torch.Tensor):
        """Redraw the ball's (x, z) and the target's (x, y, z) for resetting envs, in the env-local
        frame -- env-grid placement is the engine's business, not this task's. The ball's resting
        height and orientation are constant (set once in allocate_buffers) and never redrawn."""
        n = self._set_ball_pose.shape[0]
        m = mask.unsqueeze(-1)

        def _uniform(lo: float, hi: float) -> torch.Tensor:
            return torch.rand((n, 1), device=self.device) * (hi - lo) + lo

        self._set_ball_pose[:, 4:5] = torch.where(m, _uniform(*self.ball_x_range),
                                                  self._set_ball_pose[:, 4:5])
        self._set_ball_pose[:, 6:7] = torch.where(m, _uniform(*self.ball_z_range),
                                                  self._set_ball_pose[:, 6:7])

        self._target_pos[:, 0:1] = torch.where(m, _uniform(*self.target_x_range),
                                               self._target_pos[:, 0:1])
        self._target_pos[:, 1:2] = torch.where(m, _uniform(*self.target_y_range),
                                               self._target_pos[:, 1:2])
        self._target_pos[:, 2:3] = torch.where(m, _uniform(*self.target_z_range),
                                               self._target_pos[:, 2:3])

        if self._target_cubes:
            identity = v.Quat(0, 0, 0, 1)
            for i in mask.nonzero(as_tuple=True)[0].tolist():
                pos = v.Vec3(*self._target_pos[i].tolist())
                self._target_cubes[i].set_transform(v.Transform(identity, pos))

    def obs_fields(self) -> dict:
        return {**super().obs_fields(),
                "palm_to_ball":   GlobalField(3),
                "palm_to_target": GlobalField(3),
                "ball_to_target": GlobalField(3)}

    def compute_observations(self):
        self.gym.get_rigid_body_kinematic_states(self._ball_get_cmd_array)
        super().compute_observations()
        palm, ball, target = self._get_root_pose[:, 4:7], self._get_ball_pose[:, 4:7], self._target_pos
        self.obs("palm_to_ball")[:] = palm - ball
        self.obs("palm_to_target")[:] = palm - target
        self.obs("ball_to_target")[:] = ball - target

    def compute_reward_termination_truncation(self):
        self.reward_term_trunc_helper_jit(
            self._rew_buf, self._next_term_buf, self._next_trunc_buf,
            self._get_root_pose[:, 4:7], self._get_ball_pose[:, 4:7], self._target_pos,
            self.ball_radius, self.lift_threshold, self.dist_penalty_weight, self.lift_bonus,
            self.target_dist_weight, self.close_thresh, self.close_bonus,
            self.very_close_thresh, self.very_close_bonus,
            self._progress_buf, self.max_episode_length,
        )

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        palm_pos: torch.Tensor,
        ball_pos: torch.Tensor,
        target_pos: torch.Tensor,
        ball_radius: float,
        lift_threshold: float,
        dist_penalty_weight: float,
        lift_bonus: float,
        target_dist_weight: float,
        close_thresh: float,
        close_bonus: float,
        very_close_thresh: float,
        very_close_bonus: float,
        progress: torch.Tensor,
        max_episode_length: int,
    ):
        """`AdroitHandRelocateEnv.step`'s dense reward, sign-corrected on the first term (see the
        module docstring): distance-to-ball penalty, always; a lift bonus plus distance-to-target
        penalties once the ball clears the table; proximity bonuses on top. Never terminates --
        truncates at the time limit, same as the source env.
        """
        palm_to_ball   = torch.norm(palm_pos - ball_pos, dim=-1)
        ball_to_target = torch.norm(ball_pos - target_pos, dim=-1)
        palm_to_target = torch.norm(palm_pos - target_pos, dim=-1)
        lifted = ball_pos[:, 1] > (ball_radius + lift_threshold)   # Y is up

        reward = -dist_penalty_weight * palm_to_ball
        reward = reward + torch.where(
            lifted,
            lift_bonus - target_dist_weight * palm_to_target - target_dist_weight * ball_to_target,
            0.0,
        )
        reward = reward + torch.where(ball_to_target < close_thresh, close_bonus, 0.0)
        reward = reward + torch.where(ball_to_target < very_close_thresh, very_close_bonus, 0.0)

        rew_buf[:] = reward
        term_buf[:] = False
        trunc_buf[:] = progress >= max_episode_length
