"""Locomotion on a plane: walk forward, stay upright.

Free-floating root -- the body is dropped on the ground and has to hold itself up, so `root_axes`
is None. The scene is a ground plane and nothing else, which is why Ant alone cannot show that
`create_scene` needed to be abstract.
"""
import torch
import vlearn as v

from codesigner.backend.vlearn_helpers import create_plane
from codesigner.interfaces.task import Task


class Ant(Task):

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int = 1000,
        gravity: v.Vec3 = v.Vec3(0, -9.81, 0),
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 3.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        ctrl_cost_weight: float = 0.5,
        healthy_reward: float = 2.0,
        healthy_y_range: tuple = (0.3, 1.1),
        **kwargs,
    ):
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=None,             # free-floating: nothing holds the ant up but the ant
            **kwargs,
        )
        self.ctrl_cost_weight = ctrl_cost_weight
        self.healthy_reward_val = healthy_reward
        self.healthy_y_range = healthy_y_range

    def create_scene(self):
        create_plane(self.gym)

    def set_root_pose(self, group: dict, start: int, end: int):
        """Drop the body at its standing height.

        Spawn higher when the longest chain runs past two modules, so long legs do not clip through
        the ground at reset -- the lift is exactly the length of everything beyond the second
        module, taken from the emitter's record rather than from a library constant. Index 5 is root
        Y (up-axis) in [qx,qy,qz,qw, px,py,pz]. `store_initial_conditions_helper` returns a fixed
        height, so the offset is added to the reset pose, which governs: envs reset before stepping.
        """
        lift = sum(group["deepest_chain"][2:])
        self._set_root_pose[start:end, 5] += lift
        self._height_offset[start:end] = lift

    def compute_reward_termination_truncation(self):
        # Reward needs only root pose plus the already-global act/old-root/progress buffers, so it
        # runs whole-tensor (the helper is elementwise per env).
        # The healthy Y band is ASYMMETRIC in body height: the CEILING scales with the spawn lift (a
        # long-legged ant stands taller), but the FLOOR is ABSOLUTE -- a fallen ant's torso is near
        # the ground regardless of leg length (only the limbs are longer, not the torso). So we pass
        # a Y-normalized pose to the helper (giving the correct relative ceiling + untouched forward
        # reward from X), then revive any body the shifted floor wrongly killed while its torso is
        # still above the absolute floor. (Shifting BOTH bounds killed standing tall ants at
        # normY < 0.3.)
        root_pose = self._get_root_pose.clone()
        root_pose[:, 5] -= self._height_offset

        self.reward_term_trunc_helper_jit(
            self._rew_buf,
            self._next_term_buf,
            self._next_trunc_buf,
            self._act_buf,
            root_pose,
            self.old_root_pos_buf,
            self._progress_buf,
            self.healthy_y_range,
            self.healthy_reward_val,
            self.dt,
            self.ctrl_cost_weight,
            self.max_episode_length,
        )

        lo = self.healthy_y_range[0]
        # helper killed it on the (shifted) floor, but the real torso is above the absolute floor:
        wrongly_low = (self._next_term_buf & (root_pose[:, 5] < lo)
                       & (self._get_root_pose[:, 5] >= lo))
        self._next_term_buf[:] = self._next_term_buf & ~wrongly_low
        self._rew_buf[:] = (self._rew_buf                       # restore the healthy bonus
                            + self.healthy_reward_val * wrongly_low.to(self._rew_buf.dtype))

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        act: torch.Tensor,
        root_pose: torch.Tensor,
        old_root_pos: torch.Tensor,
        progress: torch.Tensor,
        healthy_y_range: tuple[float, float],
        healthy_reward: float,
        dt: float,
        ctrl_cost_weight: float,
        max_episode_length: int,
    ):
        """Forward velocity, minus control cost, plus a bonus for staying in the healthy Y band.

        The body of this was vlearn's `envs/ant_environment_common.py`, which ships in vlearn's
        sample directory and not in the wheel. Vendored here rather than into the backend because
        it is an objective, and objectives belong to tasks (docs/decisions.md, D13).
        """
        healthy = torch.logical_and(healthy_y_range[0] <= root_pose[:, 5],
                                    root_pose[:, 5] <= healthy_y_range[1])
        healthy_reward_t = torch.where(healthy, healthy_reward, 0.0)
        x_vel = (root_pose[:, 4] - old_root_pos[:, 4]) / dt
        action_cost = torch.sum(act * act, dim=1)

        rew_buf[:] = healthy_reward_t + x_vel - ctrl_cost_weight * action_cost
        term_buf[:] = torch.logical_not(healthy)
        trunc_buf[:] = progress >= max_episode_length
