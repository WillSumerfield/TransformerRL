"""`PlanarMotion`: the shared base of the BodyGen locomotion tasks.

Ported from [BodyGen](https://openreview.net/pdf?id=cTR17xl89h) (ICLR 2025). Four of its five envs
-- `hopper`, `walker`, `gap`, `swimmer` -- are the same task with different thresholds: a robot
confined to a plane, rewarded for travelling along it. Only `ant` is genuinely different (a free
root in three dimensions), and it is already `components/tasks/ant.py`.

**The plane is three passive root axes** (CONTEXT.md's Passive root axis). MuJoCo's planar envs float
their robot on `rootx`/`rootz` sliders and a root hinge, none of them motorized, and that is what is
reproduced here: two prismatic axes spanning the plane and one revolute axis about its normal, all
unactuated and unlimited. The robot cannot leave the plane, and -- crucially -- the policy cannot
push its own root, which would otherwise be free reward, since the reward *is* root velocity.

**Motion lives in the mount, not in the root pose.** `root_axes` being non-`None` welds the base link
to its placement, so `_get_root_pose` is constant and `root_dof_state()` is where height, pitch and
travel are read. Each of those reads as a displacement from the spawn placement, because every mount
joint starts at zero -- which is why the healthy band below is expressed relative to spawn.

**Directions are Model frame** (CONTEXT.md), which is z-up. So `plane="xz"` is the vertical plane a
walker travels in, and `plane="xy"` is the horizontal one a swimmer swims in. Travel is along model
**+x** in both; nothing in BodyGen travels along anything else, and the plane argument already
carries the real variation.

**Departures from the source envs:**

- **The healthy height band is relative to the spawn height, not absolute.** Upstream's `min_height
  0.7` / `max_height 2.0` are absolute world heights for one fixed robot whose torso spawns at 1.25.
  A codesigned body has no such height -- its torso spawns at its own reach, so a three-module body
  would spawn *above* an absolute 2.0 ceiling and terminate on its first step. The band is therefore
  carried across as the tolerance it represents, `(0.7 - 1.25, 2.0 - 1.25)` around wherever this
  body happens to spawn. Same intent, and it survives a change of robot. This follows `Ant`, which
  already scales its ceiling with the spawn lift for the same reason.
- **Reward is not scaled and carries no bonus by default.** Every published BodyGen config leaves
  `reward_specs` empty, so `alive_bonus` is 0, `exec_reward_scale` is 1, and the walker family has
  no control cost at all. The parameters are kept, at those defaults, rather than dropped -- they
  are what the source exposes.
- **The body spawns at its own reach**, clear of the ground, rather than at a fixed height. A limb
  on a vertical ring can point straight down, so anything less clips through the floor at reset.
"""
import math

import torch
import vlearn as v

from codesigner.interfaces.modlib import RootAxis
from codesigner.interfaces.task import Task

# The axis normal to each plane -- the one the root's revolute axis turns about.
_PLANE_NORMAL = {"xy": "z", "xz": "y", "yz": "x"}

# Upstream's absolute healthy band, re-expressed around the height its torso spawns at. See the
# module docstring: the tolerance transfers, the absolute heights do not.
_BODYGEN_SPAWN_HEIGHT = 1.25
_HEALTHY_HEIGHT_RANGE = (0.7 - _BODYGEN_SPAWN_HEIGHT, 2.0 - _BODYGEN_SPAWN_HEIGHT)


class PlanarMotion(Task):
    """Abstract. Concrete tasks fix the thresholds and supply the scene.

    Unregistered, like `AdroitTask`: `create_scene` stays abstract, so a locomotion plane is never
    inherited by something that did not ask for one (D7c).
    """

    def __init__(
        self,
        device: torch.device,
        plane: str = "xz",
        max_episode_length: int = 1000,
        gravity: v.Vec3 = v.Vec3(0, -9.81, 0),
        timestep: float = 0.002,
        frame_skip: int = 4,
        spacing: float = 6.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        # Upstream perturbs every qpos/qvel by uniform +-0.005 at reset. The package's own defaults
        # are +-0.2 / +-0.1, which are fine for a free-floating Ant but not here: a passive root
        # axis is a DOF like any other, so that noise would start the body pitched by up to 0.2 rad
        # -- over half of Hopper's whole 20-degree termination budget -- before it acts once.
        dof_reset_pos_bias: float = -0.005,
        dof_reset_pos_scale: float = 0.01,
        dof_reset_vel_bias: float = -0.005,
        dof_reset_vel_scale: float = 0.01,
        max_ang: float = 3600.0,            # degrees, as upstream's done_condition is
        healthy_height_range: tuple = _HEALTHY_HEIGHT_RANGE,
        alive_bonus: float = 0.0,
        ctrl_cost_coeff: float = 0.0,
        exec_reward_scale: float = 1.0,
        ground_clearance: float = 0.1,
        **kwargs,
    ):
        if plane not in _PLANE_NORMAL:
            raise ValueError(f"unknown plane {plane!r}; want one of {sorted(_PLANE_NORMAL)}")
        if "x" not in plane:
            raise ValueError(f"plane {plane!r} does not contain the travel axis x")
        self.plane = plane

        # Two slides spanning the plane, one hinge about its normal. Unlimited, because a walker
        # travels arbitrarily far, and passive, because none of them is the policy's to drive.
        slides = [RootAxis.slide(d, None, actuated=False) for d in plane]
        hinge = RootAxis.hinge(_PLANE_NORMAL[plane], None, actuated=False)
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            dof_reset_pos_bias=dof_reset_pos_bias,
            dof_reset_pos_scale=dof_reset_pos_scale,
            dof_reset_vel_bias=dof_reset_vel_bias,
            dof_reset_vel_scale=dof_reset_vel_scale,
            root_axes=slides + [hinge],
            **kwargs,
        )
        # Columns into root_dof_state()'s (num_envs, n_root_axes), in root_axes order.
        self._travel_col = plane.index("x")
        self._up_col = plane.index("z") if "z" in plane else -1   # -1: the plane is horizontal
        self._pitch_col = 2

        self.max_ang = max_ang
        self.healthy_height_range = healthy_height_range
        self.alive_bonus = alive_bonus
        self.ctrl_cost_coeff = ctrl_cost_coeff
        self.exec_reward_scale = exec_reward_scale
        self.ground_clearance = ground_clearance

    @property
    def terminates(self) -> bool:
        """Whether falling ends the episode. False for a task with no vertical axis to fall along --
        upstream's swimmer returns `termination = False` unconditionally, for exactly this reason."""
        return self._up_col >= 0

    def allocate_buffers(self):
        super().allocate_buffers()
        # Travel velocity is the finite difference upstream uses, `(posafter - posbefore) / dt`,
        # rather than the simulator's instantaneous DOF velocity: it is the average over the whole
        # frame_skip, which is what the source's reward means and is the less noisy of the two.
        self._old_root_dof_pos = torch.zeros(
            (self.total_num_envs, max(1, self._n_root_axes)),
            dtype=torch.float32, device=self.device)

    def pre_physics_step(self, actions: torch.Tensor):
        # Snapshot before stepping, mirroring the backend's own old_root_pos_buf. The fetched DOF
        # buffers still hold the previous step's values at this point.
        self._old_root_dof_pos[:] = self.root_dof_state()[0]
        super().pre_physics_step(actions)

    def set_root_pose(self, group: dict, start: int, end: int):
        """Place the body one full reach above the ground, plus a clearance margin.

        The whole reach, not `Ant`'s "everything past the second module": a slot on a vertical ring
        can point straight down, so the longest chain is a real vertical extent rather than a
        mostly-horizontal one. Index 5 is world Y (up) in `[qx,qy,qz,qw, px,py,pz]`.

        **Assigned, not added to.** `store_initial_conditions_helper` seeds this buffer with a
        hardcoded 0.75, which every other task then offsets from; here the height is the body's own
        and adding an unrelated constant to it would eat into the healthy band before the first
        step. Upstream has the same problem and does not solve it -- its robot spawns at a fixed
        1.25 whatever its legs are, and the retry loop that would have fixed that (`reset_state`'s
        `env_init_height` branch) is dead code, defaulting off with no published config enabling it.
        """
        height = group["reach"] + self.ground_clearance
        self._set_root_pose[start:end, 5] = height
        self._height_offset[start:end] = height

    def compute_reward_termination_truncation(self):
        dof_pos, _ = self.root_dof_state()
        self.reward_term_trunc_helper_jit(
            self._rew_buf,
            self._next_term_buf,
            self._next_trunc_buf,
            self._act_buf,
            dof_pos,
            self._old_root_dof_pos,
            self._progress_buf,
            self._travel_col,
            self._up_col,
            self._pitch_col,
            self.healthy_height_range,
            math.radians(self.max_ang),
            self.alive_bonus,
            self.ctrl_cost_coeff,
            self.exec_reward_scale,
            self.dt,
            self.max_episode_length,
            self.terminates,
        )

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        act: torch.Tensor,
        dof_pos: torch.Tensor,
        old_dof_pos: torch.Tensor,
        progress: torch.Tensor,
        travel_col: int,
        up_col: int,
        pitch_col: int,
        healthy_height_range: tuple[float, float],
        max_ang_rad: float,
        alive_bonus: float,
        ctrl_cost_coeff: float,
        exec_reward_scale: float,
        dt: float,
        max_episode_length: int,
        terminates: bool,
    ):
        """Travel speed along the plane, and death on falling over.

        Every quantity is a root-mount DOF displacement from the spawn placement, so the healthy
        band is a tolerance about spawn rather than an absolute world height (see the module
        docstring).
        """
        travel_vel = (dof_pos[:, travel_col] - old_dof_pos[:, travel_col]) / dt
        action_cost = torch.mean(act * act, dim=1)
        rew_buf[:] = (travel_vel + alive_bonus - ctrl_cost_coeff * action_cost) * exec_reward_scale

        if terminates:
            height = dof_pos[:, up_col]
            upright = torch.logical_and(
                torch.logical_and(height > healthy_height_range[0],
                                  height < healthy_height_range[1]),
                torch.abs(dof_pos[:, pitch_col]) < max_ang_rad)
            term_buf[:] = torch.logical_not(
                torch.logical_and(torch.isfinite(dof_pos).all(dim=1), upright))
        else:
            term_buf[:] = torch.zeros_like(term_buf)

        trunc_buf[:] = progress >= max_episode_length
