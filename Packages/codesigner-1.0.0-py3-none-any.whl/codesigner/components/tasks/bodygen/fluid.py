"""MuJoCo's inertia-box fluid model, as a batched torch kernel.

VSim has no fluid model, and the fluid is what makes a swimmer swim: BodyGen's `swimmer.xml` sets
`density="4000" viscosity="0.1"` and the body has no other way to make progress. So the forces are
computed host-side and pushed in as per-link external forces.

**Why an inertia box.** MuJoCo does not use a body's actual geometry. It substitutes the box of
uniform density with the same mass and the same diagonal inertia, and takes its drag areas from
that. That is what makes this implementable here at all: `ModuleDefinition.geometry` is opaque to
the backend by design (the emitter/library split), but mass and inertia are reported by the
simulator for every link.

**The law**, verified numerically against MuJoCo 3.11.0 (`tests/test_fluid.py` re-checks it):

    box[i] = sqrt(max(eps, I[j] + I[k] - I[i]) / m * 6)      (i, j, k) cyclic -- FULL side lengths
    diam   = (box[0] + box[1] + box[2]) / 3

    F_i = -0.5 * density * box[j] * box[k] * |v_i| * v_i  -  3*pi*diam*viscosity * v_i
    T_i = -(density / 64) * box[i] * (box[j]^4 + box[k]^4) * |w_i| * w_i
          -  pi * diam^3 * viscosity * w_i

`v` and `w` are the link's linear and angular velocity **in its own frame**, and `F`/`T` come back
in that frame too, laid out `[force, torque]` -- see `inertia_box_fluid` on why that is not the
order the same simulator reports velocities in. Note there is no added-mass term: the plan expected one, and the numerical oracle
says this path has only quadratic drag and linear viscous drag. Both terms are anisotropic in the
drag part and isotropic in the viscous part, which is the whole reason a flat body can scull.

This lives task-side, not in the backend, because the medium a robot moves through is a property of
the scene. The backend supplies external forces and knows nothing about what is filling them in.
"""
import math

import torch


@torch.jit.script
def inertia_box_fluid(lin_vel: torch.Tensor, ang_vel: torch.Tensor, box: torch.Tensor,
                      density: float, viscosity: float) -> torch.Tensor:
    """Fluid wrench on every link, `(..., 6)` laid out `[force xyz, torque xyz]`.

    `lin_vel`, `ang_vel` are `(..., 3)` in each link's own frame; `box` is `(..., 3)` side lengths
    from `CodesignEnvironmentGpu.link_inertia_boxes`. Links with a zero box (padding, or a massless
    link) come back as zero wrench, since every term carries a box factor.

    **The two vsim spatial buffers are ordered oppositely, and neither says so.** A link's reported
    *velocity* is `[ang xyz, lin xyz]`; a link's external *force* is `[force xyz, torque xyz]`.
    Measured, both of them (`tests/test_fluid.py` drives one component at a time and watches which
    mount DOF answers). Writing a torque where a force belongs mostly produces a body that does not
    move at all -- the components land on axes the mount has welded -- which reads as "the fluid is
    not applied" rather than as a layout error.
    """
    bx, by, bz = box[..., 0], box[..., 1], box[..., 2]
    diam = (bx + by + bz) / 3.0

    # Quadratic drag: the frontal area against motion along each axis is the other two sides.
    area = torch.stack((by * bz, bz * bx, bx * by), dim=-1)
    drag = -0.5 * density * area * lin_vel.abs() * lin_vel
    # Linear viscous drag on a sphere of the box's mean diameter.
    drag = drag - (3.0 * math.pi * viscosity) * diam.unsqueeze(-1) * lin_vel

    b4 = box ** 4
    moment = torch.stack((bx * (b4[..., 1] + b4[..., 2]),
                          by * (b4[..., 2] + b4[..., 0]),
                          bz * (b4[..., 0] + b4[..., 1])), dim=-1)
    torque = -(density / 64.0) * moment * ang_vel.abs() * ang_vel
    torque = torque - (math.pi * viscosity) * (diam ** 3).unsqueeze(-1) * ang_vel

    return torch.cat((drag, torque), dim=-1)


@torch.jit.script
def limit_to_momentum(wrench: torch.Tensor, lin_vel: torch.Tensor, ang_vel: torch.Tensor,
                      mass: torch.Tensor, inertia: torch.Tensor, dt: float) -> torch.Tensor:
    """Cap each component so one substep's impulse cannot exceed the momentum it opposes.

    Drag removes momentum; it must never reverse it. Injecting the wrench explicitly and holding it
    fixed across a substep breaks that: quadratic drag at `density=4000` on a body this size reaches
    forces large enough that `F * dt` overshoots `m * v`, so the link comes back faster in the
    opposite direction, and the whole articulation diverges within three or four steps. MuJoCo does
    not hit this because it folds passive forces into its own integrator rather than applying them
    from outside.

    Clamping to `|m * v / dt|` per axis is the standard remedy, and the worst it can do is bring a
    link exactly to rest rather than past it. **It is not, however, inactive in practice**: at
    `Swimmer`'s default substep it still clamps roughly a fifth of all wrench components, so it is
    part of the model rather than a safety net over an already-converged one. See `swimmer.py` for
    the measurements. The law in `inertia_box_fluid` is exact against MuJoCo; this is where the
    approximation lives.
    """
    max_force = (mass.unsqueeze(-1) * lin_vel).abs() / dt
    max_torque = (inertia * ang_vel).abs() / dt
    limit = torch.cat((max_force, max_torque), dim=-1)
    return torch.clamp(wrench, -limit, limit)


@torch.jit.script
def rotate_inverse(q: torch.Tensor, u: torch.Tensor) -> torch.Tensor:
    """Carry `u` from the parent frame into the frame `q` (xyzw) describes -- `q^-1 * u * q`."""
    xyz = q[..., 0:3]
    w = q[..., 3:4]
    t = torch.cross(xyz, u, dim=-1) * 2.0
    return u - w * t + torch.cross(xyz, t, dim=-1)
