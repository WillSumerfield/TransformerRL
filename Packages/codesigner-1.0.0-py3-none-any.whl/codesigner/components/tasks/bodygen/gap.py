"""Gap: cross a course of platforms separated by holes. BodyGen's `terraincrosser` experiment.

`PlanarMotion` with terrain instead of a ground plane, a tighter healthy band, and one extra
observation: **where in the gap cycle the robot currently is**. Upstream computes that as
`x/3.2 - floor(x/3.2)` and prepends it to every body's token; here it is one declared `GlobalField`
in the global region, per the extend-don't-replace contract (D11).

**Departures from the source env**, beyond the ones `PlanarMotion` already documents:

- **The terrain is generated, not imported.** BodyGen ships `assets/mujoco_terrains/gap_terrain.png`
  and the plan was to transfer it unchanged, since VSim reads PNG height fields too. It does not
  transfer: VSim takes height from the **alpha** channel (that PNG's is opaque throughout, so it
  imports as a perfectly flat slab, silently) and maps PNG **columns to z**, across the course
  rather than along it. Reproducing the course from its own numbers -- 3.2 m period, ~0.85 m gaps --
  is both correct and legible, and keeps the period that shapes the terrain and the period in the
  phase observation the same constant. See `backend/heightfield.py` for the measured convention.
- **Platforms are at height 0 and gaps drop below it**, rather than upstream's platforms 1.93 m
  above a field placed 1.5 m down. `PlanarMotion` already spawns a body at its own reach above
  y = 0, so putting the walkable surface there is what makes the two compose; the absolute heights
  were never meaningful for a body whose size is the Algorithm's choice.
- **There is no ground plane.** One would fill every gap. `create_scene` is therefore empty, which
  is exactly the case that made it abstract (D7c) rather than defaulted to a plane.
- **No respawn retry loop.** Upstream's (`gap.py:330-346` -- write state, query contacts, raise
  rootz by 0.05, repeat) is gated on `env_init_height`, which defaults off and which no published
  config sets, so it never runs. The spawn point is a platform centre by construction instead.
"""
import numpy as np
import torch
import vlearn as v

from codesigner.backend.heightfield import build_profile_png, gap_profile
from codesigner.components.tasks.bodygen.bodygen import PlanarMotion
from codesigner.interfaces import GlobalField

# Upstream's course, measured off `gap_terrain.png` against its `<hfield size="32 32 2 0.1"/>`:
# 496 px over 64 m is 0.129 m/px, and the pattern repeats every ~24.8 px -- 3.2 m, of which ~6.5 px
# (~0.85 m) is hole. 3.2 is also the divisor in the source's phase observation, and they must agree.
_GAP_PERIOD = 3.2
_GAP_WIDTH = 0.85
_GAP_DEPTH = 2.5            # deep enough that falling in trips the healthy band rather than landing
_RESOLUTION = 0.05          # metres per height-field sample along the course
_WIDTH = 3.0                # metres across the course; a planar robot cannot leave its own plane

# Upstream's `terraincrosser.yml` sets `min_height: 1.0` against a torso that spawns at 1.25, so the
# body may drop a quarter metre before it counts as fallen. See PlanarMotion on why this is carried
# across as a tolerance about spawn rather than as an absolute height.
_HEALTHY_HEIGHT_RANGE = (1.0 - 1.25, 2.0 - 1.25)


class Gap(PlanarMotion):

    def __init__(
        self,
        device: torch.device,
        max_ang: float = 20.0,
        healthy_height_range: tuple = _HEALTHY_HEIGHT_RANGE,
        gap_period: float = _GAP_PERIOD,
        gap_width: float = _GAP_WIDTH,
        gap_depth: float = _GAP_DEPTH,
        course_start: float = -4.0,
        course_length: float = 80.0,
        **kwargs,
    ):
        super().__init__(device=device, plane="xz", max_ang=max_ang,
                         healthy_height_range=healthy_height_range, **kwargs)
        self.gap_period = gap_period
        self.gap_width = gap_width
        self.gap_depth = gap_depth
        self.course_start = course_start
        self.course_length = course_length

    def create_scene(self):
        """Nothing. A ground plane would floor every gap; the terrain is the scene, and it is
        per-env-def, so it is built in `create_props`."""
        pass

    def create_props(self, env_def, group_index: int, morph):
        """Import the course into this group's env def.

        Terrain is scenery rather than a Prop in the CONTEXT.md sense -- nothing acts on it -- but
        `import_height_field_def` lives on `EnvironmentDef`, and `create_props` is the only hook
        that runs while a group's env def is still open. Every group imports an identical file.
        """
        profile, _ = gap_profile(self.gap_period, self.gap_width, _RESOLUTION,
                                 self.course_start, self.course_length)
        width_px = max(2, int(round(_WIDTH / _RESOLUTION)))
        path = build_profile_png("gap_terrain", profile, width_px)

        hf = env_def.import_height_field_def(
            str(path), min_height=-self.gap_depth, max_height=0.0,
            scale=v.Vec3(_RESOLUTION, 1.0, _RESOLUTION), name="terrain")
        # The field's own origin is a corner, so it is offset to put course x=0 at env x=0 and to
        # centre the strip on the robot's plane at z=0.
        origin = v.Vec3(self.course_start, 0.0, -0.5 * width_px * _RESOLUTION)
        env_def.create_rigid_body(hf, v.Transform(v.Quat(0, 0, 0, 1), origin), "terrain")

    def obs_fields(self) -> dict:
        return {**super().obs_fields(), "phase": GlobalField(1)}   # phase within the gap cycle

    def compute_observations(self):
        """Append where the robot is within one gap cycle, in `[0, 1)` -- upstream's
        `x/3.2 - floor(x/3.2)`.

        Travel is the first mount axis, and it reads as displacement from the spawn placement, which
        is course x=0. So the DOF *is* the course coordinate, with no offset to apply.

        `floor`, where upstream truncates toward zero (`x/3.2 - int(x/3.2)`). The two agree for every
        x >= 0, which is everywhere upstream's robot ever is; behind the start line truncation gives
        a negative phase and a discontinuity at the origin, and this is meant to be a phase.
        """
        super().compute_observations()
        x = self.root_dof_state()[0][:, self._travel_col]
        phase = x / self.gap_period
        self.obs("phase")[:, 0] = phase - torch.floor(phase)

    def gap_centres(self) -> np.ndarray:
        """Course x of every hole's centre -- half a period off each platform centre, which is
        where the robot spawns. For tests, and for anything placing markers."""
        first = np.ceil((self.course_start - 0.5 * self.gap_period) / self.gap_period)
        n = int(self.course_length / self.gap_period)
        return (first + np.arange(n)) * self.gap_period + 0.5 * self.gap_period
