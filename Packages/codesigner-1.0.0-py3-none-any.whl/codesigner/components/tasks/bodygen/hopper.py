"""Hopper: travel along a vertical plane without pitching far over. BodyGen's `cheetah` experiment.

Upstream's `hopper` and `walker` env classes are the same file -- the diff is the class name, the
XML path, a comment, and `index_base`, which only feeds a body-tree observation feature that has no
counterpart without BodyGen's own module vocabulary. They are separate tasks here for traceability
to the published experiment names, and differ only in how far the body may pitch: `cheetah` allows
20 degrees, the walker family 60.
"""
import torch

from codesigner.backend.vlearn_helpers import create_plane
from codesigner.components.tasks.bodygen.bodygen import PlanarMotion


class Hopper(PlanarMotion):

    def __init__(self, device: torch.device, max_ang: float = 20.0, **kwargs):
        super().__init__(device=device, plane="xz", max_ang=max_ang, **kwargs)

    def create_scene(self):
        create_plane(self.gym)
