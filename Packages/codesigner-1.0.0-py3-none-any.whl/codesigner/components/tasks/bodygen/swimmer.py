"""Swimmer: make progress through a dense fluid with no ground to push against.

BodyGen's `swimmer` experiment. `PlanarMotion` in the **horizontal** plane, with no ground, no
gravity worth the name, and no way to fail -- and the only one of the five where the medium, not the
terrain, is what the body acts against.

**The fluid is ported, not inherited.** VSim has no fluid model at all, so `swimmer.xml`'s
`density="4000" viscosity="0.1"` has nothing to attach to. `fluid.py` computes MuJoCo's inertia-box
wrench for every link each substep and pushes it in as a per-link external force. That model is
verified against MuJoCo 3.11.0 to machine precision (`tests/test_fluid.py`).

**Departures from the source env**, beyond the ones `PlanarMotion` already documents:

- **No termination, ever.** Upstream returns `termination = False` unconditionally; `swimmer.yml`'s
  `done_condition` is empty. `PlanarMotion` arrives at the same place structurally: a horizontal
  plane has no vertical axis among its mount DOFs, so there is no height to fall below.
- **The control cost is kept.** Unlike the walker family, upstream's swimmer *does* subtract
  `ctrl_cost_coeff * mean(ctrl^2)`, defaulting to 1e-4, so that default is carried across.
- **Gravity is off**, matching a body that is neutrally buoyant in a fluid 4x denser than water.
  Upstream leaves MuJoCo's gravity on and relies on the plane constraint to hold the swimmer up;
  here the plane is horizontal, so gravity would act straight through the two passive slides and
  be absorbed by the weld rather than doing anything -- except through the passive hinge, where it
  would produce a spurious torque on an asymmetric body.
- **Fluid forces use each link's reported velocity at its own origin**, where MuJoCo uses the
  velocity of the link's centre of mass. They differ only by `omega x r` for a spinning link, and
  VSim reports no per-link inertial-frame velocity to use instead.
- **The substep is 32x finer than upstream's**, 0.00125 against 0.01, keeping the *control* step at
  upstream's 0.04. Injecting drag as an explicit external force is far less forgiving than folding
  it into the integrator, as MuJoCo does. Without the momentum guard in `fluid.py` the whole
  articulation diverges within four steps at BodyGen's `density=4000`, at every substep size tried
  down to 0.000625.
- **The momentum guard is materially active, and is therefore part of this model.** Measured over a
  fixed gait, it clamps ~44% of wrench components at upstream's 0.01 substep, ~31% at 0.0025 and
  ~22% at the 0.00125 default, and travel over that gait changes by 20x across the same range. So
  this is *not* a converged solution that merely needs a guard for safety -- it is an explicitly
  integrated approximation whose trajectory still depends on the substep. The law itself is exact
  (`tests/test_fluid.py` checks it against MuJoCo to 5e-16); what is approximate is the integration
  of it. Anything comparing against published swimmer numbers should treat this as the first thing
  to suspect.
"""
import torch
import vlearn as v

from codesigner.components.tasks.bodygen.bodygen import PlanarMotion
from codesigner.components.tasks.bodygen.fluid import (inertia_box_fluid,
                                                      limit_to_momentum,
                                                      rotate_inverse)

_DENSITY = 4000.0       # swimmer.xml's <option density=...>
_VISCOSITY = 0.1        # swimmer.xml's <option viscosity=...>


class Swimmer(PlanarMotion):

    def __init__(
        self,
        device: torch.device,
        gravity: v.Vec3 = v.Vec3(0, 0, 0),
        timestep: float = 0.00125,
        frame_skip: int = 32,
        ctrl_cost_coeff: float = 1e-4,
        density: float = _DENSITY,
        viscosity: float = _VISCOSITY,
        **kwargs,
    ):
        super().__init__(device=device, plane="xy", gravity=gravity, timestep=timestep,
                         frame_skip=frame_skip, ctrl_cost_coeff=ctrl_cost_coeff, **kwargs)
        self.density = density
        self.viscosity = viscosity

    def create_scene(self):
        """Open water: no plane, nothing to collide with. The fluid is the scene, and it is applied
        as forces rather than built as geometry."""
        pass

    def set_root_pose(self, group: dict, start: int, end: int):
        """Float at a fixed height. `PlanarMotion` lifts by the body's reach to clear a floor; there
        is no floor here, and the swimming plane is horizontal, so the height is arbitrary."""
        self._set_root_pose[start:end, 5] = self.spawn_height
        self._height_offset[start:end] = self.spawn_height

    def allocate_buffers(self):
        super().allocate_buffers()
        self._fluid_force = self.enable_link_external_forces()
        self._link_rows, self._link_mask = self.link_external_force_index()
        self._link_mass, self._link_box, self._link_inertia = self.link_inertia_boxes()

    def pre_gym_step(self):
        """Recompute and apply the fluid wrench before every substep.

        Per substep, not per control step: the drag is quadratic in velocity, and holding it fixed
        across a frame_skip of 4 is the difference between a swimmer and an oscillator. This costs
        one extra link-state fetch per substep, which is why it is here and not in the backend --
        no other task should pay for it.
        """
        self.gym.get_articulation_kinematic_states(self._get_link_cmd_array)
        pose = self._flat_get_link_pose.view(-1, 7)[self._link_rows]        # (N, L, 7)
        vel = self._flat_get_link_vel.view(-1, 6)[self._link_rows]          # (N, L, 6) ang, lin
        q = pose[..., 0:4]
        lin = rotate_inverse(q, vel[..., 3:6])
        ang = rotate_inverse(q, vel[..., 0:3])
        wrench = inertia_box_fluid(lin, ang, self._link_box, self.density, self.viscosity)
        wrench = limit_to_momentum(wrench, lin, ang, self._link_mass, self._link_inertia,
                                   self._timestep)
        self._fluid_force[:] = wrench * self._link_mask
        self.apply_link_external_forces()
