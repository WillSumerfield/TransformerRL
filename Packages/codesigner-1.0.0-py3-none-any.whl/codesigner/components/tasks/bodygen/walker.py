"""Walker: travel along a vertical plane, tolerant of pitch. BodyGen's `walker` and `glider` runs.

Six published experiments land on this one task: `walker-{regular,medium,hard}` and
`glider-{regular,medium,hard}`. They differ only in `max_nchild` (1/2/3) and `max_body_depth`
(4 for walker, 3 for glider) -- both properties of the *search space*, which is a `ModuleLibrary`
concern here and not a Task one. The objective, the scene and the thresholds are identical across
all six.

See `hopper.py` for why Hopper and Walker are separate tasks at all.
"""
import torch

from codesigner.backend.vlearn_helpers import create_plane
from codesigner.components.tasks.bodygen.bodygen import PlanarMotion


class Walker(PlanarMotion):

    def __init__(self, device: torch.device, max_ang: float = 60.0, **kwargs):
        super().__init__(device=device, plane="xz", max_ang=max_ang, **kwargs)

    def create_scene(self):
        create_plane(self.gym)
