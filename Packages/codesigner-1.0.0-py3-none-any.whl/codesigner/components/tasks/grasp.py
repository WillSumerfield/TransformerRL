"""Grasping from a fixed mount: a hand bolted above a workspace, reaching down to a target.

The counterweight to Ant, and the reason three of the interface decisions look the way they do:

- **Root mounting is the Task's** (D6). The hand is world-mounted on two actuated prismatic
  `RootAxis` -- vertical (model z) then lateral (model x). Ant is free-floating. One `ModuleLibrary`
  serves both only because it does not own how the root is fixed to the world.
- **`create_scene` has no default** (D7c). Ant's scene is a ground plane; inheriting one here would
  silently drop a floor into a workspace that did not ask for it.
- **The observation extends** (D11). The target's pose is task-specific, so it is declared as a
  `GlobalField` and lands in the global region beside the robot's own root state.

**Not migrated, because there was nothing to migrate.** The pre-migration `GraspCodesignEnv` was a
skeleton: its reward helper was a bare `pass`, so the reward, termination and truncation buffers
were never written at all, and it had no scene and no target. The mount, the lift and the parameter
list below are ports. The target pose is the minimum needed to make this a real witness for the
observation override -- it is a pose, not yet a body with geometry, and the objective that would
score reaching it is deferred with the rest of the reference implementations (Phase 9).
"""
import torch
import vlearn as v

from codesigner.backend.vlearn_helpers import create_plane
from codesigner.interfaces import GlobalField
from codesigner.interfaces.modlib import RootAxis
from codesigner.interfaces.task import Task

_TARGET_INDICATOR_SIZE = 0.15


class Grasp(Task):

    _TARGET_POSE_DIM = 7            # target pose: quat xyzw + pos xyz, as the root pose is laid out

    def __init__(
        self,
        device: torch.device,
        max_episode_length: int = 1000,
        gravity: v.Vec3 = v.Vec3(0, -9.81, 0),
        timestep: float = 0.01667,
        frame_skip: int = 1,
        spacing: float = 3.0,
        max_contact_pairs_per_env: int = 64,
        reset_noise_scale: float = 1.0,
        hover_height: float = 2.0,
        workspace_radius: float = 0.5,
        target_height: float = 0.1,
        mount_range: tuple = (-1.0, 1.0),
        **kwargs,
    ):
        # Model frame is z-up (CONTEXT.md), so the vertical approach axis is 'z' and 'x' is lateral.
        # This read `['y', 'x']` while claiming to be "vertical then lateral": model y is world -z,
        # so both axes were lateral and the hand could not descend towards the target at all.
        root_axes = [RootAxis.slide("z", mount_range),
                     RootAxis.slide("x", mount_range)]
        super().__init__(
            device=device,
            max_episode_length=max_episode_length,
            gravity=gravity,
            timestep=timestep,
            frame_skip=frame_skip,
            spacing=spacing,
            max_contact_pairs_per_env=max_contact_pairs_per_env,
            reset_noise_scale=reset_noise_scale,
            root_axes=root_axes,        # vertical then lateral approach, both actuated
            **kwargs,
        )
        self.hover_height = hover_height
        self.workspace_radius = workspace_radius
        self.target_height = target_height

    def create_scene(self):
        create_plane(self.gym)

    def allocate_buffers(self):
        super().allocate_buffers()
        # Identity orientation; position is drawn per episode in reset_idx.
        self._target_pose = torch.zeros((self.total_num_envs, 7), dtype=torch.float32,
                                        device=self.device)
        self._target_pose[:, 3] = 1.0
        self._target_pose[:, 5] = self.target_height
        # Target indicator (CONTEXT.md): a wireframe cube at the target, headed mode only.
        self._target_cubes = self.create_indicator_cubes(size=_TARGET_INDICATOR_SIZE)
        self._draw_targets(torch.ones(self.total_num_envs, dtype=torch.bool, device=self.device))

    def reset_idx(self):
        super().reset_idx()
        self._draw_targets(self._reset_buf)

    def _draw_targets(self, mask: torch.Tensor):
        """Place each resetting env's target somewhere in the workspace, in the env's own frame."""
        n = self._target_pose.shape[0]
        xz = (torch.rand((n, 2), device=self.device) * 2.0 - 1.0) * self.workspace_radius
        m = mask.unsqueeze(-1)
        self._target_pose[:, 4:5] = torch.where(m, xz[:, 0:1], self._target_pose[:, 4:5])
        self._target_pose[:, 6:7] = torch.where(m, xz[:, 1:2], self._target_pose[:, 6:7])

        if self._target_cubes:
            identity = v.Quat(0, 0, 0, 1)
            for i in mask.nonzero(as_tuple=True)[0].tolist():
                pos = v.Vec3(*self._target_pose[i, 4:7].tolist())
                self._target_cubes[i].set_transform(v.Transform(identity, pos))

    def obs_fields(self) -> dict:
        return {**super().obs_fields(), "target_pose": GlobalField(self._TARGET_POSE_DIM)}

    def compute_observations(self):
        super().compute_observations()
        self.obs("target_pose")[:] = self._target_pose

    def set_root_pose(self, group: dict, start: int, end: int):
        """Hang the hand above the workspace, clear of its own longest chain.

        Same rule as Ant for the chain-length term -- everything past the second module -- on top of
        a fixed hover height, so a longer hand still starts above the target rather than through it.
        """
        lift = self.hover_height + sum(group["deepest_chain"][2:])
        self._set_root_pose[start:end, 5] += lift
        self._height_offset[start:end] = lift

    def compute_reward_termination_truncation(self):
        """No objective yet -- see the module docstring. Episodes run to the time limit.

        Written out rather than left to the jit helper so that "this task does not score anything"
        is visible at the call site instead of hiding in a helper that returns without writing.
        """
        self._rew_buf.zero_()
        self._next_term_buf.zero_()
        self._next_trunc_buf[:] = self._progress_buf >= self.max_episode_length

    @staticmethod
    def reward_term_trunc_helper(
        rew_buf: torch.Tensor,
        term_buf: torch.Tensor,
        trunc_buf: torch.Tensor,
        progress: torch.Tensor,
        max_episode_length: int,
    ):
        rew_buf.zero_()
        term_buf.zero_()
        trunc_buf[:] = progress >= max_episode_length
