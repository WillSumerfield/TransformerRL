"""The control entry points: optimize a controller for bodies that are not being searched.

Two verbs beside `optimize` and `evaluate`, for the case that comes up as soon as a codesign run
finishes -- you have a body you like, and you want a better controller for it than a run that was
also busy designing bodies had reason to produce.

Both work the same way, and neither owns a loop. They bind the algorithm, call
`Algorithm.fix_morphologies`, and hand it to `optimize`'s own `drive`, so **Run**, the guaranteed
progress tick and the checkpoint cadence stay defined in exactly one place. What `fix_morphologies`
obliges an algorithm to do is on `Algorithm.apply_fixed_morphologies`; the short version is "build
nothing outside these bodies, and start counting again".

They differ in exactly two ways, both deliberate:

**The checkpoint.** `optimize_control` takes none and starts from whatever an untrained algorithm
has. `refine_control` requires one, so training continues from learned weights; it accepts the run
directory a previous run was given as readily as a checkpoint file, and reads that directory's
`best`.

**The bodies.** `optimize_control` requires them explicitly. `refine_control` defaults them to what
the checkpoint says its best body is, which is the one place in the package where inferring bodies
from prior state is correct -- `evaluate` forbids the same inference because a body set carried over
from training makes a generalization number measure memorization, and refinement is specialization
on purpose.

Both return `(best reward, best ControlPolicy, MetricRecord)` and no generator. The bodies were an
INPUT, so they are not a result, and an untrained algorithm's designer is never handed out as though
it were an artifact. The record comes back because a control run is still a run and still has a
**Training return** curve -- what it has no trajectory for is the **Protocols**, and those report
unavailable naming the retention policy as the reason.

A checkpoint written by a control run is not consulted for a design: a shared trunk may have moved
the generator while the controller trained, and the fixed-morphology record is what such a
checkpoint is read for instead.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple, Union

from codesigner import checkpoint as _checkpoint
from codesigner.interfaces import Algorithm, ControlPolicy, ModuleLibrary, Morphology, Task
from codesigner.metrics.record import MetricRecord
from codesigner.optimize import drive
from codesigner.progress import Progress, print_progress
from codesigner.rundir import resolve


def optimize_control(
    task: Task,
    algorithm: Algorithm,
    modlib: ModuleLibrary,
    bodies: Sequence[Morphology],
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    on_iteration: Optional[Callable[[Progress], None]] = None,
    checkpoint_dir: Optional[Union[str, Path]] = None,
    sample_budget: Optional[int] = None,
    metrics: Optional[MetricRecord] = None,
) -> Tuple[float, ControlPolicy, MetricRecord]:
    """Train a controller for `bodies`, with no morphology search.

    `bodies` is mandatory and explicit -- there is no prior state here to infer it from, and a
    control-only run whose bodies came from somewhere unstated is not a baseline anyone can compare
    against. Every other argument means what it means to `optimize`.

    Not the same thing as a control-only Algorithm. This constrains an ordinary codesign algorithm
    from outside; a **fixed** MorphologyGenerator is a property the algorithm was built with.
    """
    algorithm.assign_task_and_modlib(task, modlib)
    algorithm.attach_progress(on_iteration)
    algorithm.fix_morphologies(bodies)
    reward, policy, _, record = drive(algorithm, on_run=on_run, checkpoint_dir=checkpoint_dir,
                                      sample_budget=sample_budget, retain=None, metrics=metrics)
    return reward, policy, record


def refine_control(
    checkpoint: Union[str, Path],
    task: Task,
    algorithm: Algorithm,
    bodies: Optional[Sequence[Morphology]] = None,
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    on_iteration: Optional[Callable[[Progress], None]] = None,
    checkpoint_dir: Optional[Union[str, Path]] = None,
    sample_budget: Optional[int] = None,
    metrics: Optional[MetricRecord] = None,
    map_location=None,
) -> Tuple[float, ControlPolicy, MetricRecord]:
    """Continue a saved run's controller against a body it already found.

    `algorithm` is an instance of the algorithm that wrote the checkpoint, needed for the same
    reason `evaluate` needs one: reconstituting weights into a network requires the code that knows
    the architecture. Unlike `evaluate`'s, this one is then trained.

    The same live Task may be passed straight through from a finished `optimize`:
    `setup_simulation` releases a Task that is re-setting itself up. A *different* Task while the
    old one still holds the gym is the existing named error, fixed by `release()` on the first.

    `checkpoint_dir` is where THIS run writes to, and defaults to `None`. It is deliberately not
    the directory `checkpoint` came from: refining in place would overwrite the trained designer you
    refined away from, and a run directory refuses to be written into twice anyway.

    Neither control entry point retains checkpoints (`retain=None`). Retention exists so a protocol
    can read a run at a third and two thirds of its design search, and a control run has no design
    search -- the body is an input. It writes the rolling and best checkpoints like any run.
    """
    from codesigner.components.tasks import registry_key

    # Verified against the task being refined ON, exactly as `evaluate` does. A checkpoint trained
    # elsewhere can share this task's observation layout and still answer a different question.
    ckpt = _checkpoint.load(resolve(checkpoint), map_location=map_location,
                            task=registry_key(task))
    library = ckpt["library"]

    algorithm.assign_task_and_modlib(task, library)
    algorithm.attach_progress(on_iteration)
    # Reaching past `load_checkpoint` because the library has to be assigned before the payload is
    # restored and it comes out of the file -- the same ordering `evaluate` works around.
    algorithm._checkpoint_obs_layout = ckpt["obs_layout"]
    algorithm.load_checkpoint_payload(ckpt["payload"])

    if bodies is None:
        bodies = _default_bodies(ckpt, algorithm)

    algorithm.fix_morphologies(bodies)
    reward, policy, _, record = drive(algorithm, on_run=on_run, checkpoint_dir=checkpoint_dir,
                                      sample_budget=sample_budget, retain=None, metrics=metrics)
    return reward, policy, record


def _default_bodies(ckpt: dict, algorithm: Algorithm) -> List[Morphology]:
    """What "the current best morphology" resolves to, in two steps.

    A checkpoint from `optimize` has a real designer, so its current best is the deterministic n=1
    draw. A checkpoint from a control run does not -- its generator may have drifted while the
    controller trained, and nothing in this path is entitled to read it as a designer -- so the
    fixed morphologies it records are used instead, which also keeps repeated refinement on one
    body instead of letting it wander.
    """
    recorded = ckpt.get("fixed_morphologies")
    if recorded:
        return list(recorded)
    return algorithm.morphology_generator().generate(1, deterministic=True)
