"""The second entry point: score a saved checkpoint on bodies you name (D27).

`evaluate` owns its rollout. It does not hand the work back to the algorithm that produced the
checkpoint -- it reconstructs the module library from the checkpoint's provenance, puts everything
in eval mode, and drives the Task itself through `ControlPolicy.act()`. That is what makes a saved
policy independently useful rather than a private detail of a training run, and it gives `act()` its
first real caller.

Bodies are an **explicit parameter**, never inferred from prior state. Score the checkpoint's own
generator (`algorithm.morphology_generator().generate(n, deterministic=True)`), a fixed suite you
keep for comparability, or bodies you hand-authored -- but say which. A body set silently carried
over from training is how a generalization number ends up measuring memorization.

Evaluation is out-of-process and unrelated to training, so the licensed-gym singleton constraint
never bites: nothing else holds a gym in this process.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Sequence, Union

import torch

from codesigner import checkpoint as _checkpoint
from codesigner.interfaces import Algorithm, Morphology, Task


@torch.no_grad()
def evaluate(
    checkpoint: Union[str, Path],
    task: Task,
    algorithm: Algorithm,
    bodies: Sequence[Morphology],
    envs_per_body: int = 64,
    seed: int = 0,
    max_steps: Optional[int] = None,
    release: bool = True,
) -> List[float]:
    """Mean episode return per body, in the order `bodies` was given.

    `algorithm` is an instance of the algorithm that wrote the checkpoint, needed unconfigured and
    untrained: reconstituting weights into a network requires the code that knows the architecture,
    and no checkpoint format can carry that. It is never run -- only asked for its artifacts, once
    the payload is loaded.

    Each body gets `envs_per_body` environments and is scored on the return of its **first**
    completed episode in each, averaged. First-episode-only because bodies terminate at different
    rates, and averaging over "however many episodes fit in the budget" quietly weights the fragile
    bodies -- the ones that fall over early and get resampled most -- by their worst behaviour.
    """
    from codesigner.components.tasks import registry_key

    # Verified against the task being scored ON, not merely read: a checkpoint trained elsewhere can
    # share this task's observation layout exactly and still be answering a different question.
    ckpt = _checkpoint.load(checkpoint, map_location="cpu", task=registry_key(task))
    library = ckpt["library"]

    n_envs = len(bodies) * envs_per_body
    task.setup(library, n_envs, len(bodies), list(bodies), seed=seed)
    algorithm.assign_task_and_modlib(task, library)
    algorithm._checkpoint_obs_layout = ckpt["obs_layout"]
    algorithm.load_checkpoint_payload(ckpt["payload"])
    policy = algorithm.control_policy()

    n = task.total_num_envs
    per_body = task.envs_per_morph
    steps = max_steps if max_steps is not None else task.max_episode_length

    returns = torch.zeros(n, device=task.device)
    done = torch.zeros(n, dtype=torch.bool, device=task.device)
    obs, _ = task.reset()
    for _ in range(steps):
        actions = policy.act(obs, deterministic=True)
        obs, reward, terminated, truncated, _ = task.step(actions)
        reward = reward.squeeze(-1) if reward.ndim > 1 else reward
        returns += reward * (~done).float()          # frozen once an env's first episode ends
        done |= (terminated | truncated)
        if bool(done.all()):
            break

    scores = [returns[i * per_body:(i + 1) * per_body].mean().item() for i in range(len(bodies))]
    if release:
        task.release()
    return scores
