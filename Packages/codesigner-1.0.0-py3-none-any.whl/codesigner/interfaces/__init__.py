"""The three interfaces a user implements to plug into `optimize`."""
from codesigner.interfaces.algorithm import Algorithm, ControlPolicy, MorphologyGenerator
from codesigner.interfaces.task import Task
from codesigner.interfaces.modlib import (ModuleLibrary, ModuleType, ModuleDefinition, Module,
                                          Morphology, Orientation)
# Observation vocabulary, re-exported so a task declares its fields from the same place it imports
# Task. Suffixed rather than `Global`/`Module` because `Module` here is a part of a body.
from codesigner.backend.obs_spec import GlobalField, ModuleField

__all__ = ["Algorithm", "ControlPolicy", "MorphologyGenerator", "Task", "ModuleLibrary",
           "ModuleType", "ModuleDefinition", "Module", "Morphology", "Orientation",
           "GlobalField", "ModuleField"]
