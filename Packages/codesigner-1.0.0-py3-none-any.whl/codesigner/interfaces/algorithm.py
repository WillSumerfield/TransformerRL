"""The algorithm interface, and the two artifacts a run hands back.

`ControlPolicy` and `MorphologyGenerator` are **artifacts, not plug points** (D18). They are what a
user takes away at a checkpoint or at the end of a run -- a trained controller and a trained
designer, usable on their own. An algorithm drives its own network directly while training and need
not route through them; it constructs them to hand out. Either may be trivial: a planner that learns
no controller, a constant designer. A **fixed** generator is how a control-only baseline is
expressed, and a fixed policy is how a morphology-only search is.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple, Union

from codesigner.interfaces.modlib import ModuleLibrary, Morphology
from codesigner.interfaces.task import Task


class ControlPolicy(ABC):
    """A trained controller, detached from the algorithm that trained it."""

    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    def act(self, observation, deterministic: bool = True):
        """Actions for one batched observation.

        `observation` is the Task's observation tensor, `(num_envs, obs_total)`; the return is the
        action tensor the Task steps with. What the bytes mean is `Task.obs_layout()`, which a
        checkpoint carries so this works with no live Task (D23).

        `deterministic` selects the policy's committed action -- the distribution mode, not a draw
        from it. Evaluation wants the mode; anything measuring the policy's own exploration wants a
        sample. Default True, because the caller with no opinion is scoring, not exploring.
        """
        raise NotImplementedError

    def __str__(self):
        return f"ControlPolicy(name={self.name})"


class MorphologyGenerator(ABC):
    """A trained designer: a distribution over bodies, sampled in batches."""

    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    def generate(self, n: int, deterministic: bool = False) -> List[Morphology]:
        """Draw `n` bodies.

        **Always batched** (D29). A population is what a rebuild consumes, and n stochastic calls are
        not one batched draw of n -- a generator that models correlations between the bodies it emits
        (a diverse population, a covering set) cannot express that one call at a time. A batched
        implementation should not be forced into an n-iteration loop either.

        `deterministic` collapses the draw to the generator's committed design, so `n=1,
        deterministic=True` is "the single best body you have". A deterministic draw of n > 1 is
        allowed to return n copies of it; a generator with a deterministic *set* returns that set.
        """
        raise NotImplementedError

    def __str__(self):
        return f"MorphologyGenerator(name={self.name})"


class Algorithm(ABC):
    """A codesign algorithm: it holds a Task and a ModuleLibrary, and improves a body and a
    controller against them.

    Implement `run`, `is_finished`, `apply_fixed_morphologies`, and the two checkpoint payload
    hooks. Everything else here -- provenance, progress plumbing -- is inherited.
    """

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.task: Optional[Task] = None
        self.modlib: Optional[ModuleLibrary] = None
        self._on_iteration: Optional[Callable] = None
        self._checkpoint_obs_layout: Optional[dict] = None
        self._fixed_morphologies: Optional[List[Morphology]] = None

    # ---- the training loop ---------------------------------------------------------

    @abstractmethod
    def run(self) -> Tuple[float, ControlPolicy, MorphologyGenerator]:
        """Advance the search by one unit of the algorithm's own choosing, and report where it got
        to: the objective reached, plus the two artifacts as they now stand.

        **The package fixes no unit** (D12). One `run()` may be a generation, a trial, a batch of
        rollouts, or the whole of training -- an implementor picks whatever makes a natural
        reporting boundary, since the driver fires the guaranteed run tick after each one and may
        checkpoint there. Shorter units mean finer progress and more checkpoints; that is the only
        trade-off, and it is the implementor's to make.

        For a codesign algorithm that rebuilds the simulation periodically, the rebuild boundary is
        the natural unit: it is already a synchronization point, and checkpointing there bounds what
        a rebuild crash can cost (D24).
        """
        raise NotImplementedError

    @abstractmethod
    def is_finished(self) -> bool:
        """Whether the search is done. Checked by the driver before every `run()`, including the
        first, so an algorithm with nothing to do never runs."""
        raise NotImplementedError

    def assign_task_and_modlib(self, task: Task, modlib: ModuleLibrary) -> None:
        """Hand the algorithm what it optimizes against. Called once by the driver, before the first
        `run()`.

        The Task arrives unsized: `Task.setup()` wants an env count, a body count and the bodies
        themselves, and all three are the algorithm's to choose (D7). So the algorithm calls it,
        typically on its first `run()`.
        """
        self.task = task
        self.modlib = modlib

    # ---- fixed morphologies ---------------------------------------------------------

    def fix_morphologies(self, bodies: Sequence[Morphology]) -> None:
        """Stop searching bodies; build these. Called once, by `optimize_control` or
        `refine_control`, before the driver loop starts.

        Records the set and delegates to `apply_fixed_morphologies`. Not overridable in spirit --
        the record is the enforced part, exactly as `save_checkpoint` wraps `checkpoint_payload`, so
        no implementor can leave a control run's checkpoint unable to say what it was tuned on.
        """
        bodies = list(bodies)
        if not bodies:
            raise ValueError("fix_morphologies needs at least one body to build")
        self._fixed_morphologies = bodies
        self.apply_fixed_morphologies(bodies)

    @abstractmethod
    def apply_fixed_morphologies(self, bodies: List[Morphology]) -> None:
        """Enter the fixed-morphology phase. **Every Algorithm implements this**; there is no
        capability flag and nothing to grey out.

        The contract is exactly two lines:

        1. **Build nothing outside `bodies`.** A whitelist, not a layout -- it says what may be
           built, never how many envs or morph groups each body gets. `envs_per_morph` is MPPI's
           sample count and `num_morphs` is the EA's population, and both are tuned constants a
           driver must not silently change, so the default is to TILE the set across the population
           you already hold. Fixing one body means every group runs that body, not one group running
           while the rest go idle.
        2. **Reset whatever you count your budget in.** This is a new phase, not a continuation:
           `is_finished` is checked before the first `run()`, so an algorithm that just exhausted
           its codesign budget would otherwise refuse to refine at all. Reset the best-so-far too --
           a best reward earned by a different body will never be beaten, and the artifacts would
           stay pinned to a body no longer in play.

        A statement about the OBJECTIVE, not about parameters. It does not promise that parameters
        the ControlPolicy shares with the MorphologyGenerator are held still; with a shared trunk
        nothing could. The drift is harmless because the generator is out of scope by construction:
        the control entry points return no generator, and the checkpoint a refinement started from
        is not touched.

        Degenerate is legal. An algorithm whose controller is fixed and untrainable -- a
        morphology-only search -- satisfies this by rolling that controller out unchanged and
        reporting the same reward each run. A flat curve is the honest report of an algorithm with
        nothing to learn;
        knowing which algorithm that is belongs to whoever chose it.
        """
        raise NotImplementedError

    @property
    def fixed_morphologies(self) -> Optional[List[Morphology]]:
        """The bodies this algorithm was fixed to, or `None` for an ordinary `optimize` run."""
        return self._fixed_morphologies

    # ---- the artifacts -------------------------------------------------------------

    @abstractmethod
    def control_policy(self) -> ControlPolicy:
        """The controller as it currently stands, detached and usable on its own (D18).

        Available at any point, not only at a run boundary: `evaluate` reconstitutes an algorithm
        from a checkpoint and asks for this without ever calling `run`.
        """
        raise NotImplementedError

    @abstractmethod
    def morphology_generator(self) -> MorphologyGenerator:
        """The designer as it currently stands. A control-only algorithm returns a fixed generator
        over its one body -- that is how "no morphology search" is expressed (D18)."""
        raise NotImplementedError

    # ---- progress ------------------------------------------------------------------

    def attach_progress(self, callback: Optional[Callable]) -> None:
        """Register the iteration-tick handler. Called by the driver; `None` detaches."""
        self._on_iteration = callback

    def report_iteration(self, record) -> None:
        """Fire the iteration tick. **Best-effort**: an algorithm with no inner step never calls
        this, and it is a no-op when nothing is attached, so an implementor may call it freely."""
        if self._on_iteration is not None:
            self._on_iteration(record)

    # ---- checkpoints ---------------------------------------------------------------

    def obs_layout(self) -> dict:
        """Which bytes of the observation mean what, for whoever is rebuilding a network.

        The loaded checkpoint's layout if there is one, else the live Task's. A checkpoint records
        the offsets exactly so this works before -- or without -- `Task.setup`: the layout does not
        exist until a Task is sized, and a consumer scoring a saved policy has to build the network
        before it can decide how to size anything (D19, D23).
        """
        if self._checkpoint_obs_layout is not None:
            return self._checkpoint_obs_layout
        if self.task is None:
            raise RuntimeError(
                "no observation layout: load a checkpoint, or assign a Task and set it up")
        return self.task.obs_layout()

    @abstractmethod
    def checkpoint_payload(self) -> dict:
        """Everything needed to reconstitute this algorithm's artifacts: network weights, generator
        state, normalizer statistics. Tensors are fine.

        Provenance is *not* this method's job -- `save_checkpoint` attaches the library and the
        observation layout around whatever is returned here, so no implementor can forget them.

        **Include your random state if you draw randomly.** A **Resume** continues a run from this
        payload in a fresh process, and an algorithm that re-seeds from its `seed` there replays the
        exact draws it already spent -- silently, since the run looks continuous from outside. A
        `torch.Generator` travels as `get_state()`, a `random.Random` as `getstate()`. The run
        position and the metrics' state are the driver's and ride outside the payload; the RNG is
        yours because only you know how many streams you hold.
        """
        raise NotImplementedError

    @abstractmethod
    def load_checkpoint_payload(self, payload: dict) -> None:
        """Restore from what `checkpoint_payload` produced. The library has already been verified
        against this algorithm's own by the time this is called."""
        raise NotImplementedError

    def save_checkpoint(self, path: Union[str, Path], position: Optional[dict] = None,
                        metric_state: Optional[dict] = None) -> None:
        """Write a checkpoint: this algorithm's payload plus the provenance that makes it readable
        elsewhere. Not overridable in spirit -- the provenance is the enforced part (D19).

        `position` and `metric_state` are what a **Resume** needs and only the driver holds; an
        algorithm saving itself passes neither, and writes a checkpoint that loads but does not
        resume.
        """
        from codesigner import checkpoint as _checkpoint
        from codesigner.components.tasks import registry_key

        if self.modlib is None or self.task is None:
            raise RuntimeError(
                "save_checkpoint before assign_task_and_modlib: a checkpoint records the library, "
                "the task and the observation layout, and none of them exist yet")
        _checkpoint.save(path, library=self.modlib, task=registry_key(self.task),
                         obs_layout=self.task.obs_layout(),
                         payload=self.checkpoint_payload(), library_kwargs=self.library_kwargs,
                         fixed_morphologies=self._fixed_morphologies,
                         position=position, metric_state=metric_state)

    def load_checkpoint(self, path: Union[str, Path], map_location=None) -> dict:
        """Read a checkpoint written by `save_checkpoint`, verifying its library against this
        algorithm's before restoring. Returns the full stored dict for anything else the caller
        wants from it."""
        from codesigner import checkpoint as _checkpoint
        from codesigner.components.tasks import registry_key

        ckpt = _checkpoint.load(path, map_location=map_location, library=self.modlib,
                                task=registry_key(self.task) if self.task is not None else None)
        self._checkpoint_obs_layout = ckpt["obs_layout"]
        self.load_checkpoint_payload(ckpt["payload"])
        return ckpt

    # ---- optional hooks ------------------------------------------------------------

    def current_morphologies(self) -> Optional[List[Morphology]]:
        """The bodies currently under evaluation, for the run tick. `None` -- the default -- means
        "not reported", and is correct for an algorithm that holds no population."""
        return None

    # ---- provenance ----------------------------------------------------------------

    @property
    @abstractmethod
    def config(self) -> dict:
        """The hyperparameters this algorithm was constructed with, as plain JSON-able values.

        **Required**, and required to be honest: a **Metric record** found on disk months later says
        `population_size=32` because of this, and provenance the package cannot reconstruct is
        provenance nobody has. The name and description are already carried, so this is only what
        varies between two runs of the same algorithm -- the numbers a reader would need to tell
        whether two records are comparable.

        Documentation, never a gate. Nothing here is verified, matched, or acted on; the package
        computes no figure that spans runs, so comparability is the reader's judgement and this is
        what they judge it with. Seeds belong in it, being the commonest reason two otherwise
        identical records differ.
        """
        raise NotImplementedError

    @property
    def library_kwargs(self) -> dict:
        """How this algorithm's module library was constructed, for the checkpoint's provenance.
        Override when the library takes arguments; the default suits one that takes none."""
        return {}

    def __str__(self):
        return f"Algorithm(name={self.name}, description={self.description})"
