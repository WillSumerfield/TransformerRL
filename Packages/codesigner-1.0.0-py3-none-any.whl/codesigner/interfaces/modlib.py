"""The module library interface and the body types that cross the Algorithm/Task boundary."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from functools import cached_property
from hashlib import sha256
from typing import TYPE_CHECKING, Dict, Iterator, List, Sequence, Tuple, Union

if TYPE_CHECKING:                       # emit imports this module; the cycle is type-only
    from codesigner.backend.emit import BodyRecord


@dataclass(frozen=True)
class Orientation:
    """How a module is mounted at its connection point.

    Which of the module's connection points/methods is used, so an asymmetric module can attach one
    way up or the other. Intrinsic to every module at *every* connection -- not just the first, and
    never the attachment slot (that is carried by position in a Morphology).

    Frozen so it can key `ModuleDefinition.valid_configurations`.
    """
    index: int


@dataclass(frozen=True)
class RootAxis:
    """One joint of the chain fixing a robot's root to the world (see CONTEXT.md's Root mounting).

    A **Task** property: the scene decides whether the robot walks, is bolted above a table, or
    wears a wrist. The library owns only the geometry that realizes it.

    `direction` is in the robot's **model frame** (CONTEXT.md), which is z-up -- not the world
    frame, which is y-up. Model 'z' is the vertical.

    `range` is `(lo, hi)` in metres for a prismatic axis and radians for a revolute one, or `None`
    for an unlimited axis, which emits no `<limit>` at all.

    A **passive** axis (`actuated=False`) gets a joint but no motor. Three of them float a planar
    robot on a vertical plane the way MuJoCo's planar envs do: the body cannot leave the plane, and
    the policy cannot drive its own root -- which matters when the reward *is* root velocity.
    Passive axes are still observed; they are excluded only from the action width.

    Rejected alternatives:

    - **Axis strings** (`'x'`, `'rx'`, and a `~` prefix for passive) with range carried in a
      separate `root_axis_range` sequence. Smallest diff, and what this replaces. Two sequences
      index-aligned by convention is a defect waiting to happen -- reorder one and every axis
      silently takes its neighbour's limits -- and the broadcast-or-sequence rule needed to make the
      range argument bearable (`isinstance(range[0], (int, float))`) could not survive a mount that
      mixes metres and radians without a per-axis form anyway.
    - **A free-floating root for planar tasks.** Nothing then keeps a walker in its plane, and the
      out-of-plane slots of a ring library become dead weight.

    Frozen so a mount can be a module constant without a task mutating another's.
    """
    direction: str                                      # 'x' | 'y' | 'z', model frame
    revolute: bool = False                              # False: prismatic (translation)
    actuated: bool = True
    range: Union[Tuple[float, float], None] = (-1.0, 1.0)

    def __post_init__(self):
        if self.direction not in ("x", "y", "z"):
            raise ValueError(
                f"invalid root axis direction {self.direction!r}; want 'x', 'y' or 'z'")

    @classmethod
    def slide(cls, direction: str, range=(-1.0, 1.0), actuated: bool = True) -> "RootAxis":
        """A prismatic axis: the root translates along `direction`."""
        return cls(direction, revolute=False, actuated=actuated, range=range)

    @classmethod
    def hinge(cls, direction: str, range=(-1.0, 1.0), actuated: bool = True) -> "RootAxis":
        """A revolute axis: the root rotates about `direction`."""
        return cls(direction, revolute=True, actuated=actuated, range=range)

    @property
    def joint_type(self) -> str:
        return "revolute" if self.revolute else "prismatic"

    @property
    def joint_name(self) -> str:
        """`root_x` / `root_rx`. The emitter's name, defined here because it is a function of the
        axis alone -- two axes yielding the same name is rejected at emit time."""
        return f"root_{'r' if self.revolute else ''}{self.direction}"

    def __repr__(self) -> str:
        kind = "hinge" if self.revolute else "slide"
        drive = "" if self.actuated else ", passive"
        return f"RootAxis.{kind}({self.direction!r}, range={self.range}{drive})"


@dataclass(frozen=True)
class SlotPlacement:
    """Where one attachment slot sits on the root body, and which way it faces.

    A **full transform**, not a direction. A direction leaves the roll about itself free, and that
    roll is what orients the module's joint axis (`quat_rotate(rotation, geometry.axis)`) and its
    collision cylinder -- pick the roll by convention instead and it is degenerate exactly where the
    slot points opposite the convention's reference.

    `offset` is the attachment point in the **Model frame** (CONTEXT.md; z-up), measured from the
    root body's origin. `rotation` is a quaternion (xyzw) carrying the canonical slot frame onto
    this one; the canonical slot faces model **+x**, so `direction` is that axis rotated.
    """
    offset: Tuple[float, float, float]
    rotation: Tuple[float, float, float, float]

    @property
    def direction(self) -> Tuple[float, float, float]:
        """Unit outward direction: the canonical +x, carried by `rotation`."""
        x, y, z, w = self.rotation
        u = (1.0, 0.0, 0.0)
        t = (2 * (y * u[2] - z * u[1]), 2 * (z * u[0] - x * u[2]), 2 * (x * u[1] - y * u[0]))
        c = (y * t[2] - z * t[1], z * t[0] - x * t[2], x * t[1] - y * t[0])
        return tuple(u[i] + w * t[i] + c[i] for i in range(3))


@dataclass(frozen=True)
class RootLayout:
    """The root body limbs attach to: its collision geometry, and one `SlotPlacement` per slot.

    Library-owned, per `ModuleLibrary`'s "where they sit on the robot" -- and the opposite side of
    the boundary from `RootAxis`, which is how the *robot* attaches to the *world* and is the Task's.
    A library either picks a shipped preset (`components.modular_libraries.layouts`) or defines its
    own; `n_slots` follows from the layout rather than being declared twice.

    Presets are named by **the plane the slots occupy** (`RING_XY`, `RING_XZ`). "Horizontal ring" is
    not used: it reads backwards depending on whether it is taken to describe the disc or its normal.

    Rejected alternatives:

    - **A separate planar sibling library.** Two libraries sharing all their limb geometry and
      differing only in slot placement drift apart, and every module definition would be duplicated
      to express one number.
    - **A scalar `ring_normal`.** Covers the two rings and nothing else -- not a row of slots along
      a spine, not an irregular chassis.
    - **Direction-only slots.** See `SlotPlacement`.
    """
    name: str
    body: Tuple[str, Tuple[float, ...]]         # collision primitive: ("sphere", (0.25,))
    slots: Tuple[SlotPlacement, ...]

    @property
    def n_slots(self) -> int:
        return len(self.slots)

    def fingerprint(self) -> dict:
        """What a checkpoint records so a body built against a different layout is caught.

        Without it, two libraries differing only in slot placement are identical on every other
        `descriptor()` field while producing geometrically different robots -- a policy trained on
        one loads against the other and passes. The name alone is not enough, since a hand-built
        layout can reuse a preset's name, so the placements are hashed too.
        """
        flat = ",".join(f"{c:.9g}" for s in self.slots for c in (*s.offset, *s.rotation))
        return {"name": self.name, "n_slots": self.n_slots,
                "body": [self.body[0], list(self.body[1])],
                "slots_hash": sha256(flat.encode()).hexdigest()[:16]}


class ModuleType(Enum):
    """Whether a module actuates."""
    EFFECTOR = 0    # actuated, carries DOFs
    CAP = 1         # passive and terminal; nothing attaches beyond it


class ModuleDefinition:
    """The type-level description of a module. Class-level data owned by a ModuleLibrary."""

    def __init__(self, name: str, type: ModuleType,
                 valid_orientations: List[Orientation], action_dimensions: int,
                 joint_limits: Union[None, List[Tuple[float, float]]], geometry: object,
                 valid_configurations: Union[None, Dict[Orientation, Dict[str, List[Orientation]]]]):
        self.name = name
        self.type = type
        self.orientations = valid_orientations
        self.action_dimensions = action_dimensions
        self.joint_limits = joint_limits
        self.geometry = geometry
        self.valid_configurations = valid_configurations
        self.id = None                      # assigned by ModuleLibrary.modules

        if self.type == ModuleType.CAP and self.valid_configurations is not None:
            raise ValueError(
                f"cap module {name!r} declares valid_configurations; nothing attaches beyond a cap")
        if self.type == ModuleType.EFFECTOR and not self.orientations:
            raise ValueError(f"effector module {name!r} declares no valid orientations")

    def __repr__(self) -> str:
        return f"ModuleDefinition({self.name!r}, {self.type.name})"


class Module:
    """One physical body part in a chain: a definition plus the orientation it is mounted at."""

    def __init__(self, definition: ModuleDefinition, orientation: Orientation = None):
        # A module with exactly one valid orientation need not have it spelled out -- generators are
        # not required to emit orientation while every module in the library has only one.
        if orientation is None:
            if len(definition.orientations) != 1:
                raise ValueError(
                    f"{definition.name!r} has {len(definition.orientations)} orientations; "
                    "one must be given explicitly")
            orientation = definition.orientations[0]
        self.definition = definition
        self.orientation = orientation

    @property
    def type(self) -> ModuleType:
        return self.definition.type

    @property
    def name(self) -> str:
        return self.definition.name

    def can_connect(self, child: "Module") -> bool:
        """Whether `child` may attach onto this module, at both modules' orientations."""
        configs = self.definition.valid_configurations
        if configs is None:
            return False
        by_child = configs.get(self.orientation)
        if by_child is None:
            return False
        return child.orientation in by_child.get(child.definition.name, ())

    def __repr__(self) -> str:
        return f"Module({self.name!r}, o={self.orientation.index})"


class Morphology:
    """One specific robot body: an ordered chain of modules per attachment slot.

    The boundary type between Algorithm and Task. The **attachment slot is carried by position** --
    index *i* is slot *i* -- so a morphology is dense and fixed-width and an empty chain means an
    absent limb. Slots are 0-based; the 1-based names that appear in generated XML are a naming
    convention owned by the emitters, not by this type.

    Chains run proximal -> distal: index 0 attaches to the root.
    """

    def __init__(self, chains: Sequence[Sequence[Module]]):
        self._chains: List[List[Module]] = [list(c) for c in chains]

    # ---- sequence protocol: a Morphology *is* its slots ------------------------

    def __len__(self) -> int:
        return len(self._chains)

    def __iter__(self) -> Iterator[List[Module]]:
        return iter(self._chains)

    def __getitem__(self, slot: int) -> List[Module]:
        return self._chains[slot]

    # ---- accessors -------------------------------------------------------------

    @property
    def chains(self) -> List[List[Module]]:
        return self._chains

    @cached_property
    def occupied_slots(self) -> Tuple[int, ...]:
        """Ascending 0-based indices of the slots holding a limb.

        Deliberately not named `limbs`: the pre-migration attribute of that name was 1-based, and a
        caller that silently kept working against 0-based indices would be off by one everywhere.
        """
        return tuple(i for i, c in enumerate(self._chains) if c)

    def effectors(self, slot: int) -> List[Module]:
        return [m for m in self._chains[slot] if m.type is ModuleType.EFFECTOR]

    def cap(self, slot: int) -> Union[Module, None]:
        return next((m for m in self._chains[slot] if m.type is ModuleType.CAP), None)

    def num_effectors(self, slot: int) -> int:
        return sum(1 for m in self._chains[slot] if m.type is ModuleType.EFFECTOR)

    @property
    def total_effectors(self) -> int:
        return sum(self.num_effectors(i) for i in range(len(self._chains)))

    @classmethod
    def from_names(cls, library: "ModuleLibrary", chains: Dict[int, Tuple[Sequence[str], str]]
                   ) -> "Morphology":
        """Build from `{slot: ([effector names], cap name)}`, with **0-based** slots.

        A convenience for hand-authored bodies; a generator's own encoding stays algorithm-side.
        Slot keys are validated against the library's slot count, and every name is resolved through
        the library -- an unknown module or an out-of-range slot raises here rather than surfacing
        later as a malformed body.
        """
        out: List[List[Module]] = [[] for _ in range(library.n_slots)]
        for slot, (effectors, cap) in chains.items():
            if not 0 <= slot < library.n_slots:
                raise ValueError(
                    f"slot {slot} out of range for a library with {library.n_slots} slots "
                    "(slots are 0-based)")
            chain = [Module(library.modules[name]) for name in effectors]
            if cap is not None:
                chain.append(Module(library.modules[cap]))
            if len(chain) > library.max_depth:
                raise ValueError(
                    f"slot {slot}: chain of {len(chain)} exceeds max_depth={library.max_depth}")
            out[slot] = chain
        return cls(out)

    def __repr__(self) -> str:
        shape = {i: [m.name for m in self._chains[i]] for i in self.occupied_slots}
        return f"Morphology({shape})"


class ModuleLibrary(ABC):
    """The vocabulary of physical modules a robot family is assembled from, plus the geometry that
    realizes a morphology as a body.

    Owns which modules exist, what each one physically is, how they may connect, and where they sit
    on the robot. Owns no scene or mounting concern -- how the root is fixed to the world is a Task
    property (see CONTEXT.md's Root mounting).
    """

    def __init__(self, name: str, n_slots: int, max_depth: int,
                 root_layout: Union["RootLayout", None] = None):
        self.name = name
        self.n_slots = n_slots          # attachment slots on the robot
        self.max_depth = max_depth      # modules per chain, including the cap
        self.root_layout = root_layout  # None for a library that places slots some other way

        if root_layout is not None and root_layout.n_slots != n_slots:
            raise ValueError(
                f"library {name!r} declares {n_slots} slots but its root layout "
                f"{root_layout.name!r} places {root_layout.n_slots}")

        # Definitions are resolved lazily and cached; `_modules()` may build fresh objects on
        # every call, so nothing may mutate what it returns.
        _ = self.definitions

    # ---- module access ---------------------------------------------------------

    @cached_property
    def definitions(self) -> Tuple[ModuleDefinition, ...]:
        """Every module definition, in declaration order, with ids assigned."""
        defs = tuple(self._modules())
        for i, d in enumerate(defs):
            d.id = i
        return defs

    @cached_property
    def modules(self) -> Dict[Union[ModuleType, str, int], object]:
        """Definitions addressed by type, name, or id.

            modules[ModuleType.EFFECTOR]            # {name/id -> definition} for that type
            modules[ModuleType.CAP]["bare"]
            modules["swing"]                        # by name
            modules[0]                              # by id
        """
        mods: Dict[Union[ModuleType, str, int], object] = {t: {} for t in ModuleType}
        for d in self.definitions:
            mods[d.type][d.name] = d
            mods[d.type][d.id] = d
            mods[d.name] = d
            mods[d.id] = d
        return mods

    @cached_property
    def module_count(self) -> int:
        return len(self.definitions)

    def names(self, type: ModuleType) -> Tuple[str, ...]:
        """Module names of one type, in declaration order.

        The order *is* the subtype vocabulary: subtype identity is positional, so this tuple is what
        a checkpoint records to make a vocabulary mismatch detectable rather than silent.
        """
        return tuple(d.name for d in self.definitions if d.type is type)

    @cached_property
    def subtype_width(self) -> int:
        """Width of the shared subtype index: the largest per-type vocabulary."""
        return max(len(self.names(t)) for t in ModuleType)

    @cached_property
    def max_effectors(self) -> int:
        """Effectors a chain can hold: the grammar forces a cap at the deepest slot."""
        return self.max_depth - 1

    def validate(self) -> None:
        """Check every connection table names a module this library actually defines."""
        for d in self.definitions:
            for orientation, by_child in (d.valid_configurations or {}).items():
                if orientation not in d.orientations:
                    raise ValueError(
                        f"{d.name!r} declares connections at orientation {orientation.index}, "
                        f"which is not among its valid orientations")
                for child_name, child_orientations in by_child.items():
                    child = self.modules.get(child_name)
                    if child is None:
                        raise ValueError(
                            f"{d.name!r} may connect to unknown module {child_name!r}")
                    unknown = set(child_orientations) - set(child.orientations)
                    if unknown:
                        raise ValueError(
                            f"{d.name!r} -> {child_name!r} names orientation(s) "
                            f"{sorted(o.index for o in unknown)} the child does not declare")

    # ---- provenance ------------------------------------------------------------

    def descriptor(self) -> dict:
        """What a checkpoint records so a mismatched vocabulary is caught and named.

        Subtype identity is positional, so loading a policy against a differently-ordered library
        misreads every module token without erroring. The root layout is recorded for the same
        reason: two libraries can agree on every field here and still place their slots differently
        (see `RootLayout.fingerprint`). Pairs with the registry key and construction args needed to
        rebuild this library (the caller's to supply -- only it knows how the library was named).
        """
        return {
            "name": self.name,
            "n_slots": self.n_slots,
            "max_depth": self.max_depth,
            "subtype_width": self.subtype_width,
            "module_names": {t.name: list(self.names(t)) for t in ModuleType},
            "root_layout": self.root_layout.fingerprint() if self.root_layout else None,
        }

    # ---- the three things an implementation supplies ----------------------------

    @abstractmethod
    def _modules(self) -> List[ModuleDefinition]:
        """Every module in this library, in declaration order.

        Order is the subtype vocabulary and therefore part of the library's identity: reordering it
        invalidates every checkpoint trained against it.
        """
        raise NotImplementedError

    @abstractmethod
    def module_length(self, module: Module) -> float:
        """Physical length of one module along its chain.

        Reported generically because the padded observation carries a length per slot, and a
        `ModuleDefinition.geometry: object` is opaque to the backend. Libraries whose modules are
        all one length may return a constant.

        Required of every library, not optional: `BodyEmitter` reads it for every module of every
        chain, so a library without it cannot build any body at all.
        """
        raise NotImplementedError

    @abstractmethod
    def construct_robot(self, morphology: Morphology,
                        root_axes: Union[Sequence[RootAxis], None] = None) -> "BodyRecord":
        """Realize a morphology as a `codesigner.backend.emit.BodyRecord` -- simulator XML plus the
        structure the backend needs to interpret it.

        Implementations construct a `BodyEmitter` from this library and the morphology, supply
        geometry for the entities it has already declared, and return `emitter.build()`. Names,
        `(slot, depth)` keys and declaration order are the emitter's; numbers are the library's.

        `root_axes` is how the robot's root is fixed to the world -- `None` free-floating, `[]`
        world-fixed, or a sequence of `RootAxis` making a world-mounted joint chain: one actuated
        prismatic axis moves the root along a line, a full six-axis set gives it a fully actuated
        wrist, three passive axes float a planar walker. It is a **Task** property, passed in rather
        than stored: the scene decides which of those it is, so a library that owned it could not be
        reused across all three (superseding ADR-0016's first clause in the TransformerRL repo). The
        library owns the geometry that realizes it -- mount-stage mass, the direction vector each
        axis letter resolves to, and how limits are formatted.

        Raising here fails the run: a morphology that cannot be built is a bug in whatever produced
        it, not a condition to recover from. Filtering and retry belong to the Algorithm, which
        holds both the library and the generator.
        """
        raise NotImplementedError
