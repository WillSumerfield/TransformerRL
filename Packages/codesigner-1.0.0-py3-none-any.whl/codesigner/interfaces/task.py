"""Task: the user-facing layer of the simulation stack.

A Task is a VSim scene plus the objective that scores it -- what a robot is optimized *for*, and the
world it is optimized *in*. Everything below it is package-owned backend it inherits and does not
override: `backend.modular` (the padded per-module tensor layout, gather/scatter, rebuilds) over
`backend.simulation` (gym lifecycle, environment groups, buffers, step loop). See CONTEXT.md.

A Task owns neither the module library nor the initial body -- both arrive from the Algorithm.
"""
from abc import abstractmethod

import vlearn as v

from codesigner.backend.modular import CodesignEnvironmentGpu

_INDICATOR_COLOR = v.Vec3(0.0, 1.0, 0.0)


class Task(CodesignEnvironmentGpu):
    """The four things a task must define. Implement these; inherit everything else.

    The observation is the one part of the backend a task may take over, through the two hooks
    below -- `obs_fields` declares what the observation is made of, `compute_observations` fills it.
    Width, offsets and the published layout all derive from the declaration.
    """

    # ---- the four things a task must define ----------------------------------------

    @abstractmethod
    def compute_reward_termination_truncation(self):
        """Score every env this step.

        Normally just calls `reward_term_trunc_helper`'s jit-compiled form, but may be overridden
        for custom shaping. Writes `self._rew_buf`, `self._next_term_buf`, `self._next_trunc_buf`.
        """
        raise NotImplementedError

    @staticmethod
    @abstractmethod
    def reward_term_trunc_helper():
        """The jit-compilable core of the above: no Python control flow, no object attributes.

        Compiled once per class at setup and reused, so it must be a pure function of its arguments.
        """
        raise NotImplementedError

    @abstractmethod
    def create_scene(self):
        """Build the world the robot is optimized in -- ground plane, table, obstacles.

        No default: a locomotion plane is not a neutral choice, and inheriting one silently is how a
        manipulation task ends up with a floor it never asked for (D7c). Called once at setup and
        again after every rebuild, on a fresh gym. `codesigner.backend.vlearn_helpers.create_plane`
        is there for the common case.

        Global state only. Every morphology group's env def is already finalized by the time this
        runs (`create_envs` finalizes each one as it is built) -- a per-morphology body, like
        something for the robot to manipulate, cannot be added here. Use `create_props` for that.
        """
        raise NotImplementedError

    @abstractmethod
    def set_root_pose(self, group: dict, start: int, end: int):
        """Write the robot's root pose into `self._set_root_pose` for envs [start, end).

        This is where the scene decides how the robot is mounted -- dropped on a plane to walk, or
        bolted above a table. Called at reset and after every rebuild.

        `group["deepest_chain"]` is the group's longest chain as per-module lengths, proximal ->
        distal, and `group["reach"]` is their sum. A task that spawns its robot standing uses these
        to lift long-limbed bodies clear of the ground, and should record whatever lift it applies
        in `self._height_offset` so the reward can read body height relative to how tall the body
        actually stands (D6).
        """
        raise NotImplementedError

    # ---- optional hooks ------------------------------------------------------------
    #
    # The observation pair. Both default to the package's standard layout, and they move together:
    # declare a field and fill it, or neither (D11).
    #
    #   extend   -- `{**super().obs_fields(), "handle": GlobalField(3)}`, then write it in
    #               `compute_observations` after calling `super()`. Your fields land after the
    #               standard blocks of the same group.
    #   replace  -- return your own dict without `super()`, and fill the whole buffer yourself.
    #               Nothing stock will read the result; that is a choice a task is allowed to make,
    #               not a rule it is breaking.
    #
    # No offset appears in either hook. That is the point: a field's width is written once, and the
    # place it lands is derived from it, so a task cannot publish one offset and write at another.

    def obs_fields(self) -> dict:
        """Declare what this task's observation is made of: name -> `GlobalField`/`ModuleField`.

        A `GlobalField(dim)` is one instance per env -- what the objective needs that the body does
        not carry, like a handle's position or a target pose. A `ModuleField(dim)` is `dim` values
        per module slot, for anything a task measures per body part.

        Pass `structural=True` for a field whose values are read exactly rather than measured -- a
        {0,1} flag or a one-hot. An algorithm must keep those out of input normalization; see
        `backend.obs_spec` for why the failure is otherwise silent.

        Name fields for what they are (`"handle"`, `"hinge_angle"`), the way the standard blocks are
        named: an offline consumer should learn what it is decoding, not just that some unlabelled
        floats are there.
        """
        return super().obs_fields()

    def compute_observations(self):
        """Fill the observation buffer. Called every step, after physics.

        Extend by calling `super()` and then writing your own fields through `self.obs("name")`,
        which is a writable view shaped `(num_envs, dim)` for a global field and
        `(num_envs, n_modules, dim)` for a module one. Replace by filling every field yourself.
        """
        return super().compute_observations()

    def state_fields(self) -> dict:
        """Declare what this task carries across steps: name -> the live per-env buffer.

        The physics half of a **restorable state** (CONTEXT.md) is the backend's business. This is
        the other half -- whatever the task itself would get wrong if the simulator were rewound
        underneath it. A target position that only re-randomizes on reset, a contact counter, a gait
        phase: rewind the physics without rewinding those and the task keeps scoring against a
        target the robot has already been moved away from.

        Extend it the way `obs_fields` is extended:

            return {**super().state_fields(), "target": self._target}

        First dimension must be the env, in the same global order every other buffer here uses.
        Leave out anything the step loop overwrites before it reads it -- that is not state, it is
        scratch, and declaring it only makes a rewind slower.

        Only algorithms that rewind the simulator (a sampling planner, chiefly) touch this; a task
        that declares nothing still trains normally. But the failure mode when a field is missing is
        silent divergence rather than an error, so declare on the side of too much.
        """
        return super().state_fields()

    def create_props(self, env_def, group_index: int, morph):
        """Add extra rigid bodies or articulations to one morphology's env def, for the robot to
        act on -- a door, a hammer, a target ball (a **Prop**, see CONTEXT.md).

        Optional; the default does nothing. Called once per morphology group, inside `create_envs`,
        after the robot's own articulation is created but before that group's env def is finalized
        -- both `create_scene` (global, and every group is already finalized by the time it runs)
        and after `setup` returns (finalized already) are too late.

        Build props from `codesigner.backend.props.PropBuilder`: add links and joints, write the
        result with `write_prop_vsim`, then `env_def.import_definitions(...)` it and either
        `env_def.create_rigid_body(...)` (a prop with no joints -- a free ball, a pen) or
        `env_def.create_articulation(...)` (a prop with a joint -- a hinged door). Stash whatever
        handles are needed to read or drive the prop later on `self`, indexed by `group_index`, the
        same way `set_root_pose` consumers already key per-group state.
        """
        pass

    # ---- helpers you call ----------------------------------------------------------

    def _per_env_handles(self):
        """The vsim `EnvironmentHandle` for every env, in the same global order every other buffer
        here uses (group-major, then local index within the group's `envs_per_morph` envs)."""
        for g in self.groups:
            env_set = list(g["env_group"].get_environment_sets())[0]
            for j in range(self.envs_per_morph):
                yield env_set.get_environment_handle(j)

    def create_indicator_cubes(self, size: float, color: v.Vec3 = None) -> list:
        """One `UserLineCube` per env, in global env-index order -- a **Target indicator** (see
        CONTEXT.md): visual-only, no mass, no collision, unlike a Prop. `[]` when `self.rendering` is
        False, so a caller can loop over the result unconditionally and simply do nothing.

        Called from `allocate_buffers`, once `self.groups` exists. Move an indicator with its own
        `.set_transform(...)` whenever the task redraws the target it represents -- the transform is
        in that indicator's own environment's local frame, the same convention every other per-env
        pose in this codebase uses.
        """
        if not self.rendering:
            return []
        origin = v.Transform(v.Quat(0, 0, 0, 1), v.Vec3(0, 0, 0))
        cubes = []
        for env_handle in self._per_env_handles():
            cube = self.gym_render.create_user_line_cube(
                size, origin, color or _INDICATOR_COLOR, env_handle=env_handle)
            self.gym_render.register_line_shape(cube)
            cubes.append(cube)
        return cubes

    def create_indicator_lines(self, points: list, color: v.Vec3 = None) -> list:
        """One `UserLine` per env, in global env-index order -- same Target-indicator contract as
        `create_indicator_cubes`, for a target that is a direction/orientation rather than a cube-
        shaped region. `points` are local to the line's own transform, e.g. `[Vec3(0,0,0),
        Vec3(length,0,0)]` for a segment along local +X that a later `.set_transform(...)` then
        places and orients.
        """
        if not self.rendering:
            return []
        lines = []
        for env_handle in self._per_env_handles():
            line = self.gym_render.create_user_line(
                points, color or _INDICATOR_COLOR, env_handle=env_handle)
            self.gym_render.register_line_shape(line)
            lines.append(line)
        return lines
