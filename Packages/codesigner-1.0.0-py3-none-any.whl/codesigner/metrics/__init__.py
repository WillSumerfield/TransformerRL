"""The measurement layer: what is measured about a run, and what it is measured against.

**Metrics are package-owned.** An algorithm never implements one -- if it did, "sample efficiency"
would mean something subtly different per method, and that is the one thing a comparison cannot
survive. What varies between algorithms is only whether the **Capabilities** a metric needs are
there, and a metric that has none reports `Unavailable` naming the reason.

**Per run only.** No aggregation, no across-seed mean, no comparison. The record exists to make a
user's comparison possible, not to perform it.

**Two axes**: **Sample** count and wall time. Never a tick index -- a run is algorithm-defined, so a
tick is a reporting ordinal and not an axis.

    from codesigner.metrics import MetricRecord, standard_metrics, Unavailable

    best, policy, generator, record = optimize(alg, task, lib, checkpoint_dir="runs/ea",
                                               sample_budget=2_000_000)
    record["training_return"]["values"]        # a series
    record["off_design_return"]                # Unavailable until a protocol has been run
"""
from codesigner.metrics.base import Metric, Protocol, Tick
from codesigner.metrics.capability import (DESIGN_QUALITY_PREDICTOR, SPREAD_CONTROL, Capability,
                                           capabilities, provides)
from codesigner.metrics.inrun import (DesignModeCount, DesignTravel, ModesDiscovered,
                                      TrainingReturn, standard_metrics)
from codesigner.metrics.record import RECORD, MetricRecord
from codesigner.metrics.unavailable import Unavailable, is_available
from codesigner.metrics import distance

__all__ = ["MetricRecord", "RECORD", "Metric", "Protocol", "Tick",
           "Capability", "provides", "capabilities",
           "SPREAD_CONTROL", "DESIGN_QUALITY_PREDICTOR",
           "Unavailable", "is_available", "distance", "standard_metrics",
           "TrainingReturn", "DesignModeCount", "DesignTravel", "ModesDiscovered"]
