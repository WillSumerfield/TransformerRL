"""What a **Metric** is, and the context an in-run one sees at each tick.

Two kinds, and the distinction is **cost, not kind**:

  in-run    free, therefore always collected. Observes the ticks the driver already fires.
  Protocol  spends compute of its own, therefore always asked for. Runs afterwards against a
            **Retained checkpoint**, and writes its result back into that run's record.

Both are **package-owned**. An algorithm never implements a metric -- if it did, "sample efficiency"
would mean something subtly different per method, and that is the one thing a comparison cannot
survive. What varies between algorithms is never the definition, only whether the **Capabilities**
the metric needs are there.

A metric instance is **stateful and belongs to one run**: design travel remembers the previous
population, modes discovered remembers everything pooled. Construct a fresh set per run; the default
set is built by a function for exactly that reason.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Tuple

from codesigner.interfaces.modlib import Morphology
from codesigner.metrics.capability import Capability


@dataclass
class Tick:
    """One reporting tick, as an in-run metric sees it.

    Deliberately not a `Progress`: `progress.py` says in as many words that it is the common
    denominator a run reports and not a metrics bus. A recorder is a *consumer* of the same ticks,
    and what it needs -- a package-measured **Episode return**, a fresh draw from the designer -- is
    not what a progress line shows.
    """

    tick: int
    samples: int
    wall_time: float

    episode_return: Optional[float] = None
    """The package's own measurement, mean over the envs that finished an episode this tick. `None`
    when none did -- an absence of measurement, not a zero."""

    population: Optional[List[Morphology]] = None
    """A batched draw from the algorithm's `MorphologyGenerator`, taken once per tick and shared by
    every metric that needs one. A draw *is* a sample of the design distribution, which is what
    makes exploration measurable for every algorithm and not only population-based ones. `None` when
    the draw failed or was switched off."""

    evaluated: Optional[List[Morphology]] = None
    """The bodies actually built and run this tick, from `Algorithm.current_morphologies`.

    Not `population`, and the difference is the whole reason both are here: a draw says what the
    designer *would* propose now, while these are what the returns beside them were measured on. A
    metric about the search distribution wants the draw; one that reads designs against their own
    outcome wants these. `None` for an algorithm that holds no population."""

    evaluated_returns: Optional[List[Optional[float]]] = None
    """**Episode return** per entry of `evaluated`, measured by the package, `None` per design no
    env of which finished an episode.

    Present only when the Task publishes a `design_layout` *and* it agrees with `evaluated` in
    length -- a per-design figure that might be misaligned is worse than none, because nothing
    downstream can tell. `None` otherwise."""

    algorithm: object = None


class Metric(ABC):
    """An in-run metric: it observes ticks and produces points.

    Subclasses set `name`, optionally `requires`, and implement `observe`.
    """

    name: str = "metric"

    requires: Tuple[Capability, ...] = ()
    """Capabilities without which this metric cannot report. Checked at attach, so a structurally
    impossible metric is named before the run spends anything."""

    def unavailable_for(self, algorithm, run_config: dict) -> Optional[str]:
        """A reason this metric cannot report on this run, checked once at attach, or None.

        Capabilities are checked by the record itself; this is the second attach-time source -- how
        the run was *configured*, which is how a **Protocol** on a run that retains nothing gets
        named before the run starts rather than after it ends.
        """
        return None

    @abstractmethod
    def observe(self, tick: Tick):
        """This tick's value: a float, a dict of named components for a metric reporting more than
        one number, or `None` for a tick that produced no point.

        `None` is not zero and not an error -- a tick where no episode finished has nothing to say,
        and a series with a gap in it is the honest record of that.
        """
        raise NotImplementedError


class Protocol(ABC):
    """A metric that costs compute, and therefore runs after the fact.

    Takes a **Retained checkpoint**, spends its budget, and writes its result plus **its settings**
    into that run's record. The settings are not optional bookkeeping: off-design return at K=2 is
    episode noise and at K=20 it is a measurement, so a result without them is not interpretable and
    two of them are not comparable.
    """

    name: str = "protocol"
    requires: Tuple[Capability, ...] = ()

    @property
    @abstractmethod
    def settings(self) -> dict:
        """Everything about how this protocol was run that changes what its number means."""
        raise NotImplementedError

    @abstractmethod
    def measure(self, checkpoint, task, algorithm) -> dict:
        """Compute the result for one retained checkpoint. Returns the payload alone; the caller
        attaches the settings and the checkpoint it came from."""
        raise NotImplementedError

    def run(self, record, checkpoint, task, algorithm, samples: Optional[int] = None):
        """Measure, then write the result into `record` keyed by the checkpoint it came from.

        Availability is resolved here, the same way it is for an in-run metric: an algorithm that
        provides none of what this protocol reaches into gets an `Unavailable` written into the
        record and nothing spent. Returns the result, or that `Unavailable`.
        """
        from codesigner.metrics.capability import capabilities
        from codesigner.metrics.unavailable import Unavailable
        from codesigner.rundir import retained_samples

        provided = capabilities(algorithm)
        missing = [c.name for c in self.requires if c not in provided]
        if missing:
            reason = f"{algorithm.name} provides no {' or '.join(missing)}"
            record.unavailable[self.name] = reason
            return Unavailable(self.name, reason)

        if samples is None and checkpoint is not None:
            try:
                samples = retained_samples(checkpoint)
            except (ValueError, AttributeError):
                samples = None
        payload = self.measure(checkpoint, task, algorithm)
        result = {"samples": samples,
                  "checkpoint": str(checkpoint) if checkpoint is not None else None,
                  "settings": self.settings, **payload}
        record.add_protocol_result(self.name, result)
        return result
