"""**Capabilities**: what a Metric may reach into an Algorithm for, and how one is declared.

A capability is not a value and not a reading -- it is *reached into*. A spread control is bisected
on; a quality predictor is queried at points the metric chooses. That is what makes it a capability
rather than a published quantity: the metric needs the ability to ask again.

The registry is **open**. A user may declare a capability the package never heard of and write a
metric over it, and the two shipped ones have no special standing::

    MY_CAP = Capability("my_cap", signature="(n: int) -> list[float]", contract="...")

    class MyAlg(Algorithm):
        @provides(MY_CAP)
        def whatever_i_call_it(self, n): ...

Registered **by object, not by string**, so a name typo cannot silently register nothing, and the
method may be called anything -- what a metric looks up is the capability it was given.
"""
from __future__ import annotations

import inspect
from typing import Callable, Dict, Optional


class Capability:
    """A declaration: what the ability is called, what it is called with, and what it promises.

    The contract prose is the load-bearing part. Two algorithms whose `sample_at_spread` mean
    different things by "spread" produce a ladder that is not one axis, and no signature check
    catches that -- so the contract states the endpoints and the monotonicity, and an implementor
    who cannot honour them should not register.
    """

    __slots__ = ("name", "signature", "contract")

    def __init__(self, name: str, signature: str, contract: str):
        self.name = name
        self.signature = signature
        self.contract = contract

    def __repr__(self) -> str:
        return f"Capability({self.name!r})"

    @property
    def parameters(self) -> tuple:
        """The declared parameter names, for the attach-time signature check."""
        inner = self.signature[self.signature.find("(") + 1:self.signature.rfind(")")]
        names = []
        for part in inner.split(","):
            part = part.strip()
            if part:
                names.append(part.split(":")[0].split("=")[0].strip())
        return tuple(names)


def provides(capability: Capability):
    """Mark a method as this algorithm's implementation of `capability`."""
    def decorate(fn):
        fn._provides_capability = capability
        return fn
    return decorate


def capabilities(algorithm) -> Dict[Capability, Callable]:
    """Every capability `algorithm` provides, mapped to the bound method that provides it.

    Scanned off the class rather than tracked in a registry: an algorithm carries its own
    capabilities with it, so one imported from anywhere works, and nothing has to be imported for a
    side effect.
    """
    found: Dict[Capability, Callable] = {}
    for name in dir(type(algorithm)):
        attr = getattr(type(algorithm), name, None)
        cap = getattr(attr, "_provides_capability", None)
        if cap is not None:
            found[cap] = getattr(algorithm, name)
    return found


def signature_mismatch(capability: Capability, method: Callable) -> Optional[str]:
    """A complaint about `method`'s parameters against the declared ones, or None.

    Only names and count, and only as a warning -- a metric calls positionally, so this catches the
    implementor who registered the wrong method, not one who named an argument differently.
    """
    declared = capability.parameters
    actual = tuple(p.name for p in inspect.signature(method).parameters.values()
                   if p.kind not in (p.VAR_POSITIONAL, p.VAR_KEYWORD))
    if len(actual) != len(declared):
        return (f"{capability.name} is declared {capability.signature} but "
                f"{method.__qualname__} takes {len(actual)} arguments, not {len(declared)}")
    return None


SPREAD_CONTROL = Capability(
    "spread_control",
    signature="(spread: float, n: int) -> list[Morphology]",
    contract="Draw n designs at a normalized spread. 0 is the committed design -- the "
             "deterministic draw of one, repeated -- and 1 is uniform over the grammar. Required "
             "to be monotone in spread and nothing else: an algorithm maps its own knob (a "
             "temperature, an epsilon, a variance) onto the scale and owns both endpoints. The "
             "package never reads the internal knob, because a ladder indexed by one is not an "
             "axis two methods share.")

DESIGN_QUALITY_PREDICTOR = Capability(
    "design_quality_predictor",
    signature="(designs: list[Morphology]) -> list[float]",
    contract="What the algorithm THINKS each design is worth, before running it. In the units of "
             "measured Episode return, with any reward shaping divided out -- the metric built on "
             "this is the gap between prediction and reality, and a gap in mismatched units is not "
             "a gap.")
