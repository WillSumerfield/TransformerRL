"""**Morphology distance**: how far apart two bodies are, in modules.

The substrate every exploration metric and the perturbation ladder are built on. Three distances
ship, and they are read **together** rather than one being the true one -- they differ only in how
much they care *where* a limb sits:

    composition    what parts, and how many        blind to limbs and to slots
    limb-set       what limbs                      blind to which slot a limb occupies
    slot-matched   what limbs, where               blind to nothing

The **gaps** between them are readings in their own right. Limb-set near zero with slot-matched
large is one design rearranged around the root; composition near zero with limb-set large is the
same parts built into different limbs. That is also what makes a ring layout's rotational
rediscovery read as no movement under limb-set, with no symmetry group declared anywhere.

Three **identity levels**, nested: skeleton (**Module type** only -- chain lengths and where the cap
sits, i.e. the body plan), typed (+ subtype name), full (+ **Orientation**). The headline is full;
the two *shares* -- skeleton over full, typed over full -- say which axis actually moved, since
subtype and orientation are cheap axes that move before the body plan does.

Per-limb comparison is **tip-anchored**: limbs are aligned at the distal end, away from the root,
and length slack is charged at the proximal end, so a limb and the longer limb that extends it from
the root come out near each other. Chains are stored proximal -> distal, so everything here reverses
them first. Stated by index rather than by anatomy, this silently inverts.

Pure functions of a `Morphology`. No `ModuleLibrary` anywhere, so a distance never changes meaning
because the library did.
"""
from __future__ import annotations

from collections import Counter
from typing import List, Sequence, Tuple

SKELETON = "skeleton"
TYPED = "typed"
FULL = "full"
LEVELS = (SKELETON, TYPED, FULL)

COMPOSITION = "composition"
LIMB_SET = "limb_set"
SLOT_MATCHED = "slot_matched"
KINDS = (COMPOSITION, LIMB_SET, SLOT_MATCHED)

# One design, reduced to what a distance actually compares: a tuple of limbs, each a tuple of module
# identities, DISTAL FIRST. Everything below works on these, never on Morphology, so a population's
# reduction is paid once and the pairwise loop is tuple comparisons.
Design = Tuple[Tuple[object, ...], ...]


def identity(module, level: str = FULL):
    """What counts as "the same module" at `level`."""
    if level == SKELETON:
        return module.type.value
    if level == TYPED:
        return (module.type.value, module.name)
    if level == FULL:
        return (module.type.value, module.name, module.orientation.index)
    raise ValueError(f"unknown identity level {level!r}; expected one of {LEVELS}")


def reduce(morphology, level: str = FULL) -> Design:
    """A `Morphology` as the tuple-of-limbs the distances compare. Distal first."""
    return tuple(tuple(identity(m, level) for m in reversed(chain)) for chain in morphology.chains)


def reduce_all(morphologies: Sequence, level: str = FULL) -> List[Design]:
    return [reduce(m, level) for m in morphologies]


# ---- the three distances, on reduced designs ------------------------------------------------


def _limb_cost(a: Tuple, b: Tuple) -> int:
    """Tip-anchored cost between two limbs: mismatches from the distal end, plus the length slack.

    Both arrive distal-first, so index 0 is the tip and the slack falls off the proximal end -- a
    limb and the longer limb extending it from the root differ only by that slack.
    """
    k = min(len(a), len(b))
    mismatches = 0
    for i in range(k):
        if a[i] != b[i]:
            mismatches += 1
    return mismatches + abs(len(a) - len(b))


def _composition(a: Design, b: Design) -> int:
    """L1 between module histograms. A module present in one design and not the other costs 1, so a
    substitution -- one gone, one arrived -- costs 2."""
    ca = Counter(m for limb in a for m in limb)
    cb = Counter(m for limb in b for m in limb)
    return sum((ca - cb).values()) + sum((cb - ca).values())


def _slot_matched(a: Design, b: Design) -> int:
    n = max(len(a), len(b))
    total = 0
    for i in range(n):
        total += _limb_cost(a[i] if i < len(a) else (), b[i] if i < len(b) else ())
    return total


def _limb_set(a: Design, b: Design) -> int:
    """Limbs matched to each other optimally, ignoring which slot each occupies.

    Empty slots are dropped and the rectangle padded square with absent limbs, so a design with
    fewer limbs pays each unmatched limb's own length -- the cost of building it from nothing.
    """
    xs = [l for l in a if l]
    ys = [l for l in b if l]
    if not xs and not ys:
        return 0
    n = max(len(xs), len(ys))
    cost = [[_limb_cost(xs[i] if i < len(xs) else (), ys[j] if j < len(ys) else ())
             for j in range(n)] for i in range(n)]
    return _assign(cost)


_DISTANCES = {COMPOSITION: _composition, LIMB_SET: _limb_set, SLOT_MATCHED: _slot_matched}


def between(a: Design, b: Design, kind: str = LIMB_SET) -> int:
    """Distance between two already-reduced designs. The hot path."""
    try:
        return _DISTANCES[kind](a, b)
    except KeyError:
        raise ValueError(f"unknown distance {kind!r}; expected one of {KINDS}") from None


def distance(a, b, kind: str = LIMB_SET, level: str = FULL) -> int:
    """Distance between two `Morphology`s. Reduces both, then compares."""
    return between(reduce(a, level), reduce(b, level), kind)


def shares(a, b, kind: str = LIMB_SET) -> dict:
    """The full distance and the two shares that say which axis moved.

    A search can accumulate distance while building the same robot -- subtype churn, orientation
    churn -- and one lumped share could not tell those two apart, which is why both are reported.
    Shares are `None` when the full distance is zero: nothing moved, so no axis has a share of it.
    """
    full = distance(a, b, kind, FULL)
    out = {"full": full, "typed": distance(a, b, kind, TYPED),
           "skeleton": distance(a, b, kind, SKELETON)}
    out["typed_share"] = out["typed"] / full if full else None
    out["skeleton_share"] = out["skeleton"] / full if full else None
    return out


def pairwise(designs: Sequence[Design], kind: str = LIMB_SET) -> List[List[int]]:
    """Full symmetric matrix over reduced designs. Identical designs short-circuit to 0, which is
    the common case in a search that has collapsed."""
    n = len(designs)
    out = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            d = 0 if designs[i] == designs[j] else between(designs[i], designs[j], kind)
            out[i][j] = out[j][i] = d
    return out


# ---- optimal limb matching --------------------------------------------------------------


def _assign(cost: List[List[int]]) -> int:
    """Minimum-cost assignment on a square integer matrix (Jonker-Volgenant / Hungarian, O(n^3)).

    Written out rather than pulled from scipy, which is not a dependency: the matrices here are
    `n_slots` on a side -- four to eight -- so the constant factor matters more than the asymptotics
    and an extra dependency for a 30-line function is a bad trade. Greedy matching is not an option:
    it is what makes "the same design rearranged" read as a real move.
    """
    n = len(cost)
    INF = float("inf")
    u = [0.0] * (n + 1)
    v = [0.0] * (n + 1)
    p = [0] * (n + 1)          # p[j] = row assigned to column j
    way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [INF] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], INF, 0
            row = cost[i0 - 1]
            for j in range(1, n + 1):
                if not used[j]:
                    cur = row[j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while j0:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
    return int(round(-v[0]))
