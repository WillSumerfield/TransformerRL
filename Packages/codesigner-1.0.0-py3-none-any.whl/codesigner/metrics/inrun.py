"""The four in-run metrics: free, and therefore always collected.

All four are universal -- no **Capability** is needed for any of them. The three exploration metrics
run off a batched draw from the algorithm's `MorphologyGenerator`, taken once per tick by the
recorder. A batched draw *is* a sample of the design distribution, which is what makes exploration
measurable for every algorithm rather than only for population-based ones; a fixed generator
honestly reads as one mode and zero travel.

They are read together, and the pairs come apart in ways that matter:

  mode count vs travel     one design marching across the space explores while reading as fully
                           collapsed. Mode count is a snapshot; travel is motion.
  travel vs discovered     a search cycling among designs it already knows travels and discovers
                           nothing. Discovery accumulates; motion does not.
"""
from __future__ import annotations

import math
from typing import List, Optional, Sequence

from codesigner.metrics import distance as _d
from codesigner.metrics.base import Metric, Tick

TAU = 1.0
"""Default mode-clustering radius, in modules: two designs one module apart are the same mode.

On **limb-set distance** at **full** identity, which is what the exploration metrics default to.
One module is the smallest move a search can make, so this counts a mode as a design plus the
designs one edit from it -- deliberately generous, because the failure it exists to catch is a
search that has collapsed, and a radius that splits neighbours would report branching that is not
there. Raise it to ask a coarser question.
"""

POPULATION = 32
"""Designs drawn per tick. Enough for an energy distance to mean something and cheap for every
generator that ships; a draw is sampling, not simulation."""


def _reduced(tick: Tick, level: str) -> Optional[List]:
    """The tick's population, reduced once and shared by every metric that wants it."""
    if tick.population is None:
        return None
    cache = getattr(tick, "_reduced_cache", None)
    if cache is None:
        cache = {}
        tick._reduced_cache = cache
    if level not in cache:
        cache[level] = _d.reduce_all(tick.population, level)
    return cache[level]


def _as_design(design) -> tuple:
    """A reduced design rebuilt as tuples, whatever container it came back in.

    Carried state rides in a torch file, so tuples do survive -- but a design must be *hashable*
    (the discovery pool is a set) and one list anywhere inside it is not, so nothing here assumes
    the round trip was lossless. Identities are tuples at typed and full level and a bare value at
    skeleton, hence the check.
    """
    return tuple(tuple(tuple(m) if isinstance(m, (list, tuple)) else m for m in limb)
                 for limb in design)


def _clusters(designs: Sequence, kind: str, tau: float) -> List[int]:
    """Single-linkage cluster sizes at radius `tau`, largest first.

    Single linkage rather than k-anything: the number of modes is what is being measured, so it
    cannot be an input, and a chain of near-identical designs is one mode however long the chain.
    """
    n = len(designs)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            if find(i) == find(j):
                continue                      # already linked; the distance cannot change that
            if designs[i] == designs[j] or _d.between(designs[i], designs[j], kind) <= tau:
                parent[find(i)] = find(j)
    sizes = {}
    for i in range(n):
        r = find(i)
        sizes[r] = sizes.get(r, 0) + 1
    return sorted(sizes.values(), reverse=True)


def _hill1(sizes: Sequence[int]) -> float:
    """Hill number of order 1 -- exp(Shannon entropy) -- over cluster prevalences.

    Prevalence-weighted on purpose: a stray outlier is one design in thirty-two, contributes almost
    nothing, and must not read as a second mode. A plain cluster count cannot express that.
    """
    n = sum(sizes)
    if n == 0:
        return 0.0
    h = 0.0
    for s in sizes:
        p = s / n
        if p > 0:
            h -= p * math.log(p)
    return math.exp(h)


def _mean_offdiagonal(m: List[List[int]]) -> float:
    """Mean distance between DISTINCT members -- the companion figure beside mode count."""
    n = len(m)
    if n < 2:
        return 0.0
    return sum(sum(row) for row in m) / (n * (n - 1))


def _mean_within(m: List[List[int]]) -> float:
    """Mean distance over all n^2 pairs, the diagonal included.

    The diagonal belongs in the energy distance's within terms because the cross term counts all
    n*m pairs: mixing the two conventions leaves a population at a nonzero distance from itself.
    Included on both sides, the figure is the distance between the two EMPIRICAL distributions --
    exactly zero when they are the same, and never negative.
    """
    n = len(m)
    if n == 0:
        return 0.0
    return sum(sum(row) for row in m) / (n * n)


def _mean_cross(a: Sequence, b: Sequence, kind: str) -> float:
    if not a or not b:
        return 0.0
    total = 0
    for x in a:
        for y in b:
            total += 0 if x == y else _d.between(x, y, kind)
    return total / (len(a) * len(b))


def _energy(a: Sequence, b: Sequence, kind: str) -> float:
    """Energy distance between two populations: `2E[d(A,B)] - E[d(A,A')] - E[d(B,B')]`.

    The two subtracted terms are the whole point. Plain `E[d(A,B)]` scores a wide but static search
    as fast-moving, because two draws from one broad distribution are far apart on average; the
    within-population terms remove exactly that.
    """
    across = _mean_cross(a, b, kind)
    within_a = _mean_within(_d.pairwise(a, kind))
    within_b = _mean_within(_d.pairwise(b, kind))
    return 2 * across - within_a - within_b


class TrainingReturn(Metric):
    """**Episode return** under the algorithm's own current designs, per tick.

    The headline "which method ends up better", and the only trace of how it got there -- but a
    **joint** body-and-control score: it cannot separate "found a better body" from "got better at
    driving the body it has", and a run that collapses onto one easy body can win it. Every other
    metric exists to decompose this one.

    The mean over the tick's window, not the recovered peak, so a method is charged for its own
    re-adaptation after it changes bodies.
    """

    name = "training_return"

    def observe(self, tick: Tick):
        return tick.episode_return


class _PopulationMetric(Metric):
    """Shared configuration for the three exploration metrics: which distance, at which identity
    level, and the clustering radius."""

    def __init__(self, kind: str = _d.LIMB_SET, level: str = _d.FULL, tau: float = TAU):
        self.kind = kind
        self.level = level
        self.tau = tau

    @property
    def settings(self) -> dict:
        return {"distance": self.kind, "identity_level": self.level, "tau": self.tau}


class DesignModeCount(_PopulationMetric):
    """How many genuinely distinct designs the search holds **at once**.

    1.0 is collapse onto a single design; above 1 is branching. Reported beside the mean pairwise
    distance, which is threshold-free -- if the two disagree, `tau` is doing the talking and not the
    search.
    """

    name = "design_mode_count"

    def observe(self, tick: Tick):
        designs = _reduced(tick, self.level)
        if not designs:
            return None
        return {"modes": _hill1(_clusters(designs, self.kind, self.tau)),
                "mean_pairwise_distance": _mean_offdiagonal(_d.pairwise(designs, self.kind))}


class DesignTravel(_PopulationMetric):
    """How far the design distribution moves from one tick to the next.

    The complement to mode count, which is only a snapshot: one design marching across the space
    explores while reading as fully collapsed. Read against the same-data null reported beside it --
    the energy distance between two halves of the *current* population -- and never against zero,
    which no finite sample reaches.
    """

    name = "design_travel"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._previous: Optional[List] = None

    def observe(self, tick: Tick):
        designs = _reduced(tick, self.level)
        if not designs:
            return None
        previous, self._previous = self._previous, designs
        if previous is None:
            return None                       # nothing to move from yet
        half = len(designs) // 2
        null = (_energy(designs[:half], designs[half:], self.kind) if half >= 2 else None)
        return {"travel": _energy(previous, designs, self.kind), "null": null}

    def state(self):
        """The previous population, so the first tick after a **Resume** measures motion from where
        the run actually was rather than reporting nothing."""
        return None if self._previous is None else {"previous": self._previous}

    def restore(self, state) -> None:
        self._previous = [_as_design(d) for d in state["previous"]]


class ModesDiscovered(_PopulationMetric):
    """How many distinct designs have been found **by now**, cumulatively.

    Cumulative, so it reports *finding* and not motion: a search cycling among designs it already
    knows plateaus here while travelling. Its slope is the discovery rate, and a curve still
    climbing at the end means the search had not exhausted the space.

    Clustering the *pooled* draws rather than counting distinct populations is what stops a mode
    that shifted one module from counting as new -- and it is also why `modes` is **not** monotone
    while `unique_designs` is. A newly found design that sits between two clusters merges them under
    single linkage, and the count falls by one. That is a reading rather than a fault: the space
    turned out to be connected where it had looked separated. Read the pair, and take
    `unique_designs` as the monotone one.
    """

    name = "modes_discovered"

    POOL_LIMIT = 4096
    """Unique designs the pool will hold. Each new one is compared against the pool, so the cost is
    quadratic in what a search actually explores; a search that never repeats itself would otherwise
    spend more time being measured than running. Past the limit the curve saturates, and says so."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._pool: List = []
        self._seen = set()
        self._parent: List[int] = []
        self._saturated = False

    def _find(self, i: int) -> int:
        p = self._parent
        while p[i] != i:
            p[i] = p[p[i]]
            i = p[i]
        return i

    def observe(self, tick: Tick):
        designs = _reduced(tick, self.level)
        if not designs:
            return None
        for design in designs:
            if design in self._seen:
                continue
            if len(self._pool) >= self.POOL_LIMIT:
                self._saturated = True
                break
            self._seen.add(design)
            i = len(self._pool)
            self._pool.append(design)
            self._parent.append(i)
            for j in range(i):
                # Already in the same component -- the distance cannot merge them any further, and
                # skipping it is what keeps a collapsed search cheap to measure.
                if self._find(j) == self._find(i):
                    continue
                if _d.between(design, self._pool[j], self.kind) <= self.tau:
                    self._parent[self._find(i)] = self._find(j)
        roots = {self._find(i) for i in range(len(self._pool))}
        return {"modes": len(roots), "unique_designs": len(self._pool),
                "saturated": self._saturated}

    def state(self):
        """The pool and its clustering, which exist nowhere else.

        Without this a resumed run restarts near zero and the curve stops being monotone -- the one
        property this metric is defined by. `_seen` is not carried: it is the pool's own membership,
        and rebuilding it is a set construction rather than a distance computation.
        """
        if not self._pool:
            return None
        return {"pool": self._pool, "parent": self._parent, "saturated": self._saturated}

    def restore(self, state) -> None:
        self._pool = [_as_design(d) for d in state["pool"]]
        self._parent = list(state["parent"])
        self._saturated = bool(state["saturated"])
        self._seen = set(self._pool)


def standard_metrics(kind: str = _d.LIMB_SET, level: str = _d.FULL, tau: float = TAU
                     ) -> List[Metric]:
    """A fresh set of the four in-run metrics.

    A function rather than a constant because a metric instance is stateful and belongs to one run
    -- travel remembers the previous population, discovery remembers the pool. Sharing one set
    across two runs would silently splice them together.
    """
    return [TrainingReturn(),
            DesignModeCount(kind, level, tau),
            DesignTravel(kind, level, tau),
            ModesDiscovered(kind, level, tau)]
