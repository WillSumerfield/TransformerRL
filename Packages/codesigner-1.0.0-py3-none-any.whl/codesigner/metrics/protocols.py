"""The four **Protocols**: metrics that cost compute, and therefore run after the run.

Each takes a **Retained checkpoint**, spends a budget of its own, and writes its result plus **its
settings** into that run's **Metric record**, keyed by the checkpoint it came from. The settings are
not bookkeeping: off-design return at K=2 is episode noise and at K=20 it is a measurement, so a
result without them is not interpretable and two of them are not comparable.

    record = MetricRecord.load("runs/ea-seed0")
    protocol = CommittedDesignReturn(sample_budget=200_000)
    protocol.run(record, "runs/ea-seed0/retained/s000000900000.ckpt", task, EvolutionaryAlgorithm())
    record.resave()

The retained set is selected **by position** -- first, middle, last of the sample-sorted set. That
is correct under `retain=n`, which puts those at the same fractions of every method's run, and
merely arbitrary under `retain_every_ticks`, whose members land wherever the algorithm's run unit
happened to fall.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Sequence

from codesigner import checkpoint as _checkpoint
from codesigner.metrics import distance as _d
from codesigner.metrics.base import Protocol
from codesigner.metrics.capability import (DESIGN_QUALITY_PREDICTOR, SPREAD_CONTROL, capabilities)
from codesigner.metrics.record import MetricRecord


def reconstitute(checkpoint, task, algorithm):
    """Load `checkpoint` into `algorithm` against `task`, and hand back the stored dict.

    The same ordering `evaluate` and `refine_control` work around: the library comes out of the
    file, and has to be assigned before the payload is restored.

    `checkpoint=None` means "the algorithm as it stands" -- a protocol run against a live algorithm
    rather than a saved one, which is what a ladder built at the end of a run wants.
    """
    from codesigner.rundir import resolve

    if checkpoint is None:
        return None
    ckpt = _checkpoint.load(resolve(checkpoint), map_location="cpu")
    algorithm.assign_task_and_modlib(task, ckpt["library"])
    algorithm._checkpoint_obs_layout = ckpt["obs_layout"]
    algorithm.load_checkpoint_payload(ckpt["payload"])
    return ckpt


def retained_checkpoints(record: MetricRecord) -> List[dict]:
    """A record's retained checkpoints, in sample order."""
    return sorted(record.retained, key=lambda r: r["samples"])


def run_at(protocol: Protocol, record: MetricRecord, task, make_algorithm,
           positions: Sequence[str] = ("first", "middle", "last")) -> List:
    """Run one protocol at each retained checkpoint named by `positions`, writing into `record`.

    `make_algorithm` is a **factory**, called once per checkpoint: a protocol may train the
    algorithm it is handed (the committed-design fine-tune does), and reusing that instance for the
    next checkpoint would measure the previous checkpoint's fine-tune.

    A run that retained nothing leaves an `Unavailable` naming that, which is the third source of
    unavailability -- and the one a user can act on, by giving the next run a sample budget.
    """
    from codesigner.metrics.unavailable import Unavailable

    kept = at_positions(record, positions)
    if not kept:
        reason = ("this run retained no checkpoint to run a protocol against; give the run a "
                  "sample_budget so retain=n has fractions to space saves over")
        record.unavailable[protocol.name] = reason
        return [Unavailable(protocol.name, reason)]
    return [protocol.run(record, entry["path"], task, make_algorithm(), entry["samples"])
            for entry in kept]


FRACTIONS = {"first": 0.0, "middle": 0.5, "last": 1.0}


def at_positions(record: MetricRecord, positions: Sequence[str] = ("first", "middle", "last")
                 ) -> List[dict]:
    """The retained checkpoints a protocol should be run at, selected by position.

    Position, never an absolute sample count: two methods spending the same budget reach it in a
    different number of ticks, and the whole point of the evenly-spaced policy is that i/n of the
    budget is the same place in both runs.

    A position is resolved as a **fraction of the samples this run realized**, and the nearest
    retained checkpoint to it wins -- not an index into the list. The two agree whenever retention
    ran cleanly, and differ exactly when the set holds something off the ladder: the endpoint a run
    that stopped on its own rule leaves behind, or a file spaced over a budget a **Resume** later
    re-targeted. Indexing would let either quietly redefine "middle".

    A tie -- a fraction falling exactly between two retained checkpoints -- goes to the later one,
    so that a protocol's answer is deterministic and never drifts earlier than the evenly-spaced
    ladder intended.
    """
    kept = retained_checkpoints(record)
    if not kept:
        return []
    realized = record.provenance.get("samples_realized") or kept[-1]["samples"]
    return [min(kept, key=lambda entry: (abs(entry["samples"] - FRACTIONS[p] * realized),
                                         -entry["samples"]))
            for p in positions if p in FRACTIONS]


# ---- committed design return ------------------------------------------------------------------


class CommittedDesignReturn(Protocol):
    """What the design a method committed to is worth, with control removed as a confound.

    That one design on every env, the controller warm-started from the checkpoint and fine-tuned on
    it alone for a fixed budget. The **default decision metric**, because **Training return**
    punishes a method for having kept its controller general -- and a null here says the *designs*
    were comparable, and says nothing about the policies that found them.

    Needs no capability: every algorithm has a **Committed design** by construction, being its
    generator's deterministic draw of one.
    """

    name = "committed_design_return"

    def __init__(self, sample_budget: int, window: int = 5,
                 checkpoint_dir: Optional[Path] = None, on_run=None):
        """`sample_budget` is the fine-tune's, and is the setting that decides what the number
        means: too small and this measures warm-start luck rather than the design. `window` is how
        many trailing ticks the answer averages over, since one tick of a fine-tune is noise."""
        self.sample_budget = sample_budget
        self.window = window
        self.checkpoint_dir = checkpoint_dir
        self.on_run = on_run

    @property
    def settings(self) -> dict:
        return {"sample_budget": self.sample_budget, "window": self.window}

    def measure(self, checkpoint, task, algorithm) -> dict:
        from codesigner.control import refine_control
        from codesigner.metrics.unavailable import Unavailable

        # bodies=None is the committed design: `refine_control` takes the checkpoint's own
        # deterministic draw of one, which is what "the design this method committed to" means.
        _, _, nested = refine_control(checkpoint, task, algorithm, bodies=None,
                                      on_run=self.on_run, checkpoint_dir=self.checkpoint_dir,
                                      sample_budget=self.sample_budget,
                                      metrics=MetricRecord(population=0))
        series = nested["training_return"]
        value = (None if isinstance(series, Unavailable)
                 else sum(series["values"][-self.window:]) / len(series["values"][-self.window:]))
        return {"value": value,
                # The fine-tune's OWN record nests here, so "did the budget reach the single-body
                # ceiling" is answerable from the artifact rather than assumed.
                "fine_tune": nested.to_dict()}


# ---- the ladder -------------------------------------------------------------------------------


@dataclass
class Level:
    """One rung: a *distribution* whose mean **Morphology distance** from the committed design is
    `target`, not a set of designs exactly `target` out."""

    index: int
    target: float
    spread: float
    mean_distance: float
    designs: List = field(repr=False, default_factory=list)
    skeleton_share: Optional[float] = None

    def summary(self) -> dict:
        return {"index": self.index, "target": self.target, "spread": self.spread,
                "mean_distance": self.mean_distance, "skeleton_share": self.skeleton_share,
                "designs": [repr(m) for m in self.designs]}


class PerturbationLadder(Protocol):
    """Not a plotted figure -- the shared x-axis the two off-design metrics are read on.

    A one-parameter family of design distributions running from the committed design, through the
    algorithm's trained distribution, to uniform over the grammar. Levels are indexed by **mean
    Morphology distance** from the committed design, never by whatever internal knob produces them,
    which is what makes one method's ladder comparable to another's.

    Sampling only: it costs no rollouts. Its endpoints need no capability either -- level 0 is the
    committed design, and the top is `ModuleLibrary.random_morphology`, a property of the library
    rather than of the algorithm. **Spread control** is what the rungs in between need.

    Each level reports its **skeleton share**: how much of its distance is body plan rather than
    subtype or orientation. A ladder that perturbs a design a long way without ever testing a new
    body plan is a ladder measuring something narrower than it looks.
    """

    name = "perturbation_ladder"
    requires = (SPREAD_CONTROL,)

    def __init__(self, levels: int = 5, designs_per_level: int = 16, bisection_steps: int = 10,
                 kind: str = _d.LIMB_SET, tolerance: float = 0.1, seed: int = 0):
        self.levels = levels
        self.designs_per_level = designs_per_level
        self.bisection_steps = bisection_steps
        self.kind = kind
        self.tolerance = tolerance
        self.seed = seed
        self._built: dict = {}

    @property
    def settings(self) -> dict:
        return {"levels": self.levels, "designs_per_level": self.designs_per_level,
                "bisection_steps": self.bisection_steps, "distance": self.kind,
                "tolerance": self.tolerance, "seed": self.seed}

    # -- construction ---------------------------------------------------------------

    def build(self, checkpoint, task, algorithm) -> List[Level]:
        """The rungs, in memory. Cached per checkpoint, so the two metrics read on this axis are
        read on the *same* designs rather than on two independent draws of them."""
        import random

        key = str(checkpoint)
        if key in self._built:
            return self._built[key]

        reconstitute(checkpoint, task, algorithm)
        spread_at = capabilities(algorithm)[SPREAD_CONTROL]
        committed = algorithm.morphology_generator().generate(1, deterministic=True)[0]
        base = _d.reduce(committed, _d.FULL)
        rng = random.Random(self.seed)

        def mean_distance(designs) -> float:
            reduced = _d.reduce_all(designs, _d.FULL)
            return sum(_d.between(base, r, self.kind) for r in reduced) / len(reduced)

        # The top of the ladder is the library's uniform draw, so the span the rungs divide is a
        # property of the grammar and not of how wide this algorithm happens to go.
        top = algorithm.modlib.random_morphologies(self.designs_per_level, rng)
        span = mean_distance(top)

        rungs: List[Level] = []
        for i in range(self.levels):
            target = span * i / (self.levels - 1) if self.levels > 1 else span
            if i == 0:
                designs, spread = spread_at(0.0, self.designs_per_level), 0.0
            elif i == self.levels - 1:
                designs, spread = top, 1.0
            else:
                spread, designs = self._bisect(spread_at, mean_distance, target)
            rungs.append(self._level(i, target, spread, designs, committed, mean_distance))
        self._built[key] = rungs
        return rungs

    def _bisect(self, spread_at, mean_distance, target: float):
        """Find the spread whose mean distance is `target`.

        Bisection rather than a formula because the map from an algorithm's knob to a distance is
        the algorithm's own and only promised to be monotone. It is also noisy -- each evaluation is
        a finite draw -- so this stops on a tolerance in distance, not on an interval width.
        """
        lo, hi = 0.0, 1.0
        best = None
        for _ in range(self.bisection_steps):
            mid = 0.5 * (lo + hi)
            designs = spread_at(mid, self.designs_per_level)
            d = mean_distance(designs)
            if best is None or abs(d - target) < abs(best[2] - target):
                best = (mid, designs, d)
            if abs(d - target) <= self.tolerance:
                break
            if d < target:
                lo = mid
            else:
                hi = mid
        return best[0], best[1]

    def _level(self, index, target, spread, designs, committed, mean_distance) -> Level:
        full = mean_distance(designs)
        skeleton = sum(_d.distance(committed, m, self.kind, _d.SKELETON) for m in designs)
        return Level(index=index, target=target, spread=spread, mean_distance=full,
                     designs=list(designs),
                     skeleton_share=(skeleton / len(designs)) / full if full else None)

    def measure(self, checkpoint, task, algorithm) -> dict:
        return {"levels": [rung.summary() for rung in self.build(checkpoint, task, algorithm)]}


# ---- the two metrics read on the ladder ---------------------------------------------------------


class OffDesignReturn(Protocol):
    """Return as designs move away from the committed one, along the **Perturbation ladder**.

    How far outside its own design distribution a controller stays valid. Fast decay is a controller
    good only near its own designer, which is local search; a flat curve is global validity.

    The **noise floor is free at level 0**, where every design is the same design: the spread of
    per-body scores there is pure episode noise. If that band is a large fraction of the top level's
    decay, `episodes_per_design` is too low and the curve is measuring noise.
    """

    name = "off_design_return"
    requires = (SPREAD_CONTROL,)

    def __init__(self, ladder: Optional[PerturbationLadder] = None,
                 episodes_per_design: int = 8, seed: int = 0):
        self.ladder = ladder or PerturbationLadder()
        self.episodes_per_design = episodes_per_design
        self.seed = seed

    @property
    def settings(self) -> dict:
        return {"episodes_per_design": self.episodes_per_design, "seed": self.seed,
                "ladder": self.ladder.settings}

    def measure(self, checkpoint, task, algorithm) -> dict:
        from codesigner.evaluate import evaluate

        rungs = self.ladder.build(checkpoint, task, algorithm)
        out = []
        for i, rung in enumerate(rungs):
            # One scene rebuild per level, not per design: `evaluate` sizes the Task for the whole
            # level at once, which is the expensive part of a rollout in this package.
            scores = evaluate(checkpoint, task, algorithm, bodies=rung.designs,
                              envs_per_body=self.episodes_per_design, seed=self.seed,
                              release=(i == len(rungs) - 1))
            out.append({"index": rung.index, "mean_distance": rung.mean_distance,
                        "spread": rung.spread, "return": sum(scores) / len(scores),
                        "scores": scores, "spread_of_scores": _stdev(scores)})
        return {"levels": out, "noise_floor": out[0]["spread_of_scores"] if out else None}


class OffDesignPredictorBias(Protocol):
    """The gap between what the **design-quality predictor** says a design is worth and what it is
    actually worth, out along the same ladder, in the same units.

    The paired question: a method is doing global optimization only if the controller *and* the
    designer's judgement both survive outside the training distribution. Signed, and the signs mean
    opposite failures -- flat prediction against decaying reality is over-optimism about unfamiliar
    designs; prediction falling faster than reality is pessimism that pins the designer to local
    search.

    **Anchored at level 0**, whose offset is an artifact of what the predictor was trained on rather
    than a property of distance. And never a per-level correlation: at level 0 every design is the
    same design, so `r` is 0 however good the predictor is, and a per-level `r` curve climbs with
    distance purely as an artifact of that.
    """

    name = "off_design_predictor_bias"
    requires = (SPREAD_CONTROL, DESIGN_QUALITY_PREDICTOR)

    def __init__(self, ladder: Optional[PerturbationLadder] = None,
                 episodes_per_design: int = 8, seed: int = 0,
                 measured: Optional[dict] = None):
        """`measured` is an **Off-design return** result over the same ladder. Pass it and the
        rollouts are not repeated -- the two metrics are meant to be overlaid, and re-rolling would
        overlay one curve on a different sample of the other."""
        self.ladder = ladder or PerturbationLadder()
        self.episodes_per_design = episodes_per_design
        self.seed = seed
        self.measured = measured

    @property
    def settings(self) -> dict:
        return {"episodes_per_design": self.episodes_per_design, "seed": self.seed,
                "ladder": self.ladder.settings, "reused_off_design_return": self.measured is not None}

    def measure(self, checkpoint, task, algorithm) -> dict:
        rungs = self.ladder.build(checkpoint, task, algorithm)
        if self.measured is None:
            self.measured = OffDesignReturn(self.ladder, self.episodes_per_design,
                                            self.seed).measure(checkpoint, task, algorithm)
        actual = {lv["index"]: lv["return"] for lv in self.measured["levels"]}

        predict = capabilities(algorithm)[DESIGN_QUALITY_PREDICTOR]
        raw = []
        for rung in rungs:
            predicted = predict(rung.designs)
            raw.append({"index": rung.index, "mean_distance": rung.mean_distance,
                        "predicted": sum(predicted) / len(predicted),
                        "actual": actual.get(rung.index)})
        anchor = raw[0]["predicted"] - raw[0]["actual"] if raw and raw[0]["actual"] is not None else 0.0
        for level in raw:
            level["bias"] = (None if level["actual"] is None
                             else level["predicted"] - level["actual"] - anchor)
        return {"levels": raw, "anchor": anchor}


def _stdev(xs: Sequence[float]) -> float:
    n = len(xs)
    if n < 2:
        return 0.0
    mean = sum(xs) / n
    return (sum((x - mean) ** 2 for x in xs) / (n - 1)) ** 0.5
