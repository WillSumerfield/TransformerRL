"""The **Metric record**: everything ever measured about one run, in one file.

One record per run, and everything about that run lands in it -- the metrics collected while it ran,
and every **Protocol** result computed from its checkpoints afterwards, each keyed by the retained
checkpoint it came from and carrying the settings that produced it. A record is therefore *reopened*
after the run ends, and a copy taken before a protocol ran is incomplete rather than wrong.

**Strictly one run, though.** No across-seed mean, no confidence band, no paired difference, no
comparison. Those are the user's, and this exists to make them possible rather than to perform them.
Provenance is documentation -- enough for a reader to see that two records are comparable -- and
never a gate the package enforces.

Filled in place as the run proceeds, and rewritten to disk each tick, which is what lets a live view
read a multi-hour run before it ends. Distinct from a **Checkpoint**: that saves the artifacts a run
produced, this saves what the run cost to produce them.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Union

from codesigner.metrics.base import Metric, Tick
from codesigner.metrics.capability import capabilities, signature_mismatch
from codesigner.metrics.unavailable import Unavailable

RECORD = "metrics.json"


class MetricRecord:
    """A run's metrics and provenance, filled as the run proceeds.

    Constructed by the caller to choose the metric set or configure a metric, and built by the
    driver over the standard set when they do not -- so a run is measured whether or not anyone
    asked for it.
    """

    def __init__(self, metrics: Optional[Sequence[Metric]] = None, label: Optional[str] = None,
                 population: int = 32):
        """`metrics` defaults to the standard in-run set. `label` is free text a user gives the run
        -- the package groups nothing by it, since it computes no figure spanning runs, so it is
        there to be read.

        `population` is how many designs the recorder draws from the algorithm's generator each
        tick, for the exploration metrics. Zero switches the draw off, which is what a run measuring
        only return wants.
        """
        if metrics is None:
            from codesigner.metrics.inrun import standard_metrics
            metrics = standard_metrics()
        self.metrics: List[Metric] = list(metrics)
        self.label = label
        self.population = population

        self.provenance: dict = {"started": time.strftime("%Y-%m-%dT%H:%M:%S"), "label": label,
                                 "population": population}
        self.series: Dict[str, dict] = {m.name: {"samples": [], "wall_time": [], "values": []}
                                        for m in self.metrics}
        self.unavailable: Dict[str, str] = {}
        self.protocols: Dict[str, List[dict]] = {}
        self.retained: List[dict] = []
        self.warnings: List[str] = []
        self._path: Optional[Path] = None

    # ---- attach ---------------------------------------------------------------------

    def attach(self, algorithm, run_config: dict) -> None:
        """Bind to a run: record its provenance and resolve availability, before it spends anything.

        The first of the two resolutions. A metric whose **Capability** the algorithm does not
        provide, or whose inputs this run's configuration will never produce, is named here rather
        than discovered as an empty series hours later. Both are warnings and neither raises: one
        metric set is meant to be pointed at a whole suite.
        """
        provided = capabilities(algorithm)
        for metric in self.metrics:
            missing = [c.name for c in metric.requires if c not in provided]
            if missing:
                self._mark(metric.name,
                           f"{algorithm.name} provides no {' or '.join(missing)}")
                continue
            for cap in metric.requires:
                complaint = signature_mismatch(cap, provided[cap])
                if complaint:
                    self.warnings.append(complaint)
            reason = metric.unavailable_for(algorithm, run_config)
            if reason:
                self._mark(metric.name, reason)

        self.provenance.update({
            "algorithm": {"name": algorithm.name, "description": algorithm.description,
                          "config": _jsonable(dict(algorithm.config))},
            "library": {**algorithm.modlib.descriptor(),
                        "kwargs": _jsonable(dict(algorithm.library_kwargs))}
            if algorithm.modlib is not None else None,
            "task": _task_key(algorithm.task),
            "seed": dict(algorithm.config).get("seed"),
            "capabilities": sorted(c.name for c in provided),
            "run": _jsonable(run_config),
            "package_version": _version(),
        })

    def _mark(self, name: str, reason: str) -> None:
        self.unavailable[name] = reason
        self.series.pop(name, None)

    # ---- fill -----------------------------------------------------------------------

    def observe(self, tick: Tick) -> None:
        """Offer a tick to every attached metric that is still available."""
        for metric in self.metrics:
            if metric.name in self.unavailable:
                continue
            value = metric.observe(tick)
            if value is None:
                continue
            s = self.series[metric.name]
            s["samples"].append(tick.samples)
            s["wall_time"].append(round(tick.wall_time, 3))
            s["values"].append(_jsonable(value))

    def note_retained(self, samples: int, path) -> None:
        """Record a retained checkpoint with the sample count it reached, so nothing downstream
        reconstructs a filename."""
        self.retained.append({"samples": samples, "path": str(path)})

    def add_protocol_result(self, name: str, result: dict) -> None:
        self.protocols.setdefault(name, []).append(_jsonable(result))

    def finish(self, samples: int, wall_time: float) -> None:
        self.provenance["samples_realized"] = samples
        self.provenance["wall_time"] = round(wall_time, 3)
        self.provenance["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")

    # ---- read -----------------------------------------------------------------------

    def __getitem__(self, name: str):
        """A metric's series, or an `Unavailable` saying why there is none.

        The second resolution. A capability can be registered and still yield nothing -- a run that
        ended early, a phase never reached -- so an empty series is a hole too, and reads as one.
        """
        if name in self.unavailable:
            return Unavailable(name, self.unavailable[name])
        if name in self.protocols:
            return self.protocols[name]
        if name not in self.series:
            return Unavailable(name, "not attached to this run")
        s = self.series[name]
        if not s["values"]:
            return Unavailable(name, "attached, but the run produced no point for it")
        return s

    def summary(self) -> dict:
        """Every attached metric's last value, or its `Unavailable`. Reading returns an entry for
        every metric, so a hole in a comparison is visible as a hole."""
        out = {}
        for name in list(self.series) + list(self.unavailable):
            value = self[name]
            out[name] = value if isinstance(value, Unavailable) else value["values"][-1]
        for name, results in self.protocols.items():
            out[name] = results[-1]
        return out

    # ---- disk -----------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {"provenance": self.provenance, "series": self.series,
                "unavailable": self.unavailable, "protocols": self.protocols,
                "retained": self.retained, "warnings": self.warnings}

    def save(self, path: Union[str, Path]) -> None:
        """Write the record. Atomic, because this is rewritten every tick and a crash mid-write
        would otherwise destroy the whole run's measurements to save the last one."""
        path = Path(path)
        self._path = path
        tmp = path.with_name(path.name + ".partial")
        try:
            tmp.write_text(json.dumps(self.to_dict(), indent=2, default=str))
            os.replace(tmp, path)
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise

    @classmethod
    def load(cls, path: Union[str, Path]) -> "MetricRecord":
        """Reopen a record from disk -- to read it, or for a **Protocol** to write into it.

        Comes back with no live metric objects: their state belonged to the run that is over. What
        survives is what was measured, which is what a protocol and a reader both want.
        """
        path = Path(path)
        if path.is_dir():
            path = path / RECORD
        blob = json.loads(path.read_text())
        record = cls(metrics=[])
        record.provenance = blob.get("provenance", {})
        record.series = blob.get("series", {})
        record.unavailable = blob.get("unavailable", {})
        record.protocols = blob.get("protocols", {})
        record.retained = blob.get("retained", [])
        record.warnings = blob.get("warnings", [])
        record.label = record.provenance.get("label")
        record._path = path
        return record

    def resave(self) -> None:
        """Rewrite to wherever this record was last saved or loaded from. What a protocol calls once
        it has written its result in."""
        if self._path is not None:
            self.save(self._path)

    def __repr__(self) -> str:
        return (f"MetricRecord(label={self.label!r}, series={sorted(self.series)}, "
                f"unavailable={sorted(self.unavailable)}, protocols={sorted(self.protocols)})")


def _jsonable(value):
    """Plain JSON types, so a record written by one version reads in any other. Anything exotic
    lands as its repr rather than failing the write -- a record that refuses to save because one
    provenance field was a tensor has lost the whole run's measurements over bookkeeping."""
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def _task_key(task) -> Optional[str]:
    if task is None:
        return None
    from codesigner.components.tasks import registry_key
    return registry_key(task)


def _version() -> str:
    try:
        from importlib.metadata import version
        return version("CoDesigner")
    except Exception:
        return "unknown"
