"""The sentinel a metric reports when it has no value, and the reason it says why.

A hole in a comparison has to be visible *as* a hole. `None`, `NaN`, zero and a missing key each
read as a number somewhere downstream -- a mean, a plot, a table cell -- and a hole that averages
into a comparison is worse than no comparison at all. So a metric that cannot report returns one of
these instead: it prints legibly, carries the reason, and refuses arithmetic loudly.

Unavailability is **not an error**. One metric set is meant to be pointed at a whole suite of
algorithms, most of which will not serve all of it, so this is an ordinary outcome and never raises
on its own.
"""
from __future__ import annotations


class Unavailable:
    """A metric with no value, and the reason. Truthy, printable, and unusable as a number."""

    __slots__ = ("metric", "reason")

    def __init__(self, metric: str, reason: str):
        self.metric = metric
        self.reason = reason

    def __str__(self) -> str:
        return f"n/a ({self.reason})"

    def __repr__(self) -> str:
        return f"Unavailable({self.metric!r}, {self.reason!r})"

    def __eq__(self, other) -> bool:
        return (isinstance(other, Unavailable) and other.metric == self.metric
                and other.reason == self.reason)

    def __hash__(self) -> int:
        return hash((self.metric, self.reason))

    def to_dict(self) -> dict:
        return {"unavailable": self.reason}

    # ---- the refusals ------------------------------------------------------------------
    #
    # Every way a hole could quietly become a number. `__bool__` is deliberately NOT among them:
    # the default is truthy, so `if value:` on an unavailable metric does not read as "empty".

    def _refuse(self, *_args, **_kwargs):
        raise TypeError(
            f"{self.metric} is unavailable ({self.reason}) and has no value to compute with. "
            "Check with `isinstance(v, Unavailable)` before using it, or leave it out of the "
            "figure -- an unavailable metric folded into an average is an invented number.")

    __add__ = __radd__ = __sub__ = __rsub__ = __mul__ = __rmul__ = _refuse
    __truediv__ = __rtruediv__ = __floordiv__ = __rfloordiv__ = _refuse
    __pow__ = __rpow__ = __mod__ = __rmod__ = __neg__ = __abs__ = _refuse
    __lt__ = __le__ = __gt__ = __ge__ = _refuse
    __float__ = __int__ = __index__ = __round__ = _refuse


def is_available(value) -> bool:
    """Whether `value` is a real reading rather than a hole. The check to write."""
    return not isinstance(value, Unavailable)
