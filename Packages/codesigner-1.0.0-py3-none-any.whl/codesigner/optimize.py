"""The driver: run an algorithm against a task and a module library until it says it is done."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional, Tuple, Union

from codesigner.interfaces import Algorithm, ControlPolicy, ModuleLibrary, MorphologyGenerator, Task
from codesigner.metrics.base import Tick
from codesigner.metrics.record import RECORD, MetricRecord
from codesigner.progress import Progress, print_progress
from codesigner.rundir import RunDirectory


def optimize(
    algorithm: Algorithm,
    task: Task,
    modlib: ModuleLibrary,
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    on_iteration: Optional[Callable[[Progress], None]] = None,
    checkpoint_dir: Optional[Union[str, Path]] = None,
    sample_budget: Optional[int] = None,
    retain: Optional[int] = 3,
    retain_every_ticks: Optional[int] = None,
    metrics: Optional[MetricRecord] = None,
) -> Tuple[float, ControlPolicy, MorphologyGenerator, MetricRecord]:
    """Optimize a body and a controller for `task`, over the modules in `modlib`.

    Returns the best objective reached, the two artifacts that reached it, and the run's
    **Metric record**.

    Progress arrives on two callbacks (D25/26). `on_run` fires here after every `algorithm.run()`
    and is therefore **guaranteed** -- it defaults to printing a line per tick, and `None` silences
    it. `on_iteration` is handed to the algorithm to fire at its own inner cadence: frequent, but
    **best-effort**, since an algorithm with no inner step will never call it. Both carry a
    `Progress`.

    `checkpoint_dir` is one directory holding everything this run saved -- rolling and best
    checkpoints, retained checkpoints, the metric record, and the config that produced them. The
    user names and places it; the package names what goes inside. See `rundir`. `None` saves
    nothing, and the record is then only what this call returns.

    `sample_budget` is the number of **samples** -- one env advanced by one control step -- this run
    may spend, and the only budget two methods can be matched on: an epoch, a generation and a trial
    are not comparable units. Enforced here alongside the algorithm's own stopping rule, whichever
    fires first. The driver regains control only at a run boundary, so a run overshoots by at most
    one run unit rather than stopping mid-`run()`.

    `retain` / `retain_every_ticks` are the retention policy, documented on `RunDirectory`.

    `metrics` is the record to fill. Pass one to choose the metric set or configure a metric; leave
    it out and the driver builds the standard set, so a run is measured whether or not anyone asked.
    """
    algorithm.assign_task_and_modlib(task, modlib)
    algorithm.attach_progress(on_iteration)
    return drive(algorithm, on_run=on_run, checkpoint_dir=checkpoint_dir,
                 sample_budget=sample_budget, retain=retain,
                 retain_every_ticks=retain_every_ticks, metrics=metrics)


def drive(
    algorithm: Algorithm,
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    checkpoint_dir: Optional[Union[str, Path]] = None,
    sample_budget: Optional[int] = None,
    retain: Optional[int] = 3,
    retain_every_ticks: Optional[int] = None,
    metrics: Optional[MetricRecord] = None,
) -> Tuple[float, ControlPolicy, MorphologyGenerator, MetricRecord]:
    """Step `algorithm` until it says it is done, ticking, checkpointing and measuring at each run
    boundary.

    The loop itself, with the binding removed. `optimize` binds a Task and a library and calls this;
    `optimize_control` and `refine_control` bind, fix a body set, and call this. **Run**, the
    guaranteed progress tick, the sample budget, the checkpoint cadence and the metric cadence are
    therefore defined once rather than restated per entry point, which is the whole reason the
    control entry points are thin.

    Expects `assign_task_and_modlib` and `attach_progress` to have been called already.
    """
    rundir = None
    if checkpoint_dir is not None:
        # Constructed before the first `run()`, so a directory that already holds a run is refused
        # while nothing has been spent rather than after an hour of training.
        rundir = RunDirectory(checkpoint_dir, sample_budget=sample_budget, retain=retain,
                              retain_every_ticks=retain_every_ticks)
        rundir.write_config(algorithm)

    record = metrics if metrics is not None else MetricRecord()
    record.attach(algorithm, {"sample_budget": sample_budget, "retain": retain,
                              "retain_every_ticks": retain_every_ticks,
                              "retains": rundir.retains if rundir is not None else False,
                              "retention_reason": (rundir.unavailable_reason if rundir is not None
                                                   else "this run saves nothing: no checkpoint_dir "
                                                        "was given"),
                              "checkpoint_dir": str(checkpoint_dir) if checkpoint_dir else None})

    start = time.perf_counter()
    # A delta, not the Task's own count. The same live Task is deliberately passed straight from a
    # finished `optimize` into `refine_control`, and its counter is monotone across that handover;
    # measuring absolutely would put the refinement past its budget before it ran once.
    spent_before = algorithm.task.samples if algorithm.task is not None else 0

    best_reward: Optional[float] = None
    best_policy: Optional[ControlPolicy] = None
    best_generator: Optional[MorphologyGenerator] = None
    tick = 0
    samples = 0

    while not algorithm.is_finished() and (sample_budget is None or samples < sample_budget):
        reward, policy, generator = algorithm.run()
        tick += 1
        samples = (algorithm.task.samples - spent_before) if algorithm.task is not None else 0
        wall_time = time.perf_counter() - start

        # Artifacts are tracked at the best objective, not the last: a run that ends mid-collapse
        # should still hand back the body and controller that worked. `>=` so a run whose reward
        # plateaus still returns its most recent -- most-trained -- artifacts rather than the first
        # ones to hit the plateau.
        improved = best_reward is None or reward >= best_reward
        if improved:
            best_reward, best_policy, best_generator = reward, policy, generator

        if rundir is not None:
            rundir.tick(algorithm, tick=tick, samples=samples, improved=improved)
            for path in rundir.take_new_retained():
                record.note_retained(_stamp(path), path)

        # Taken once and shared: the take clears the accumulator, so a second reader would get an
        # empty window, and `current_morphologies` is a rebuild of the population for algorithms
        # that hold one -- neither is a call to make twice a tick.
        mean_return, per_design = _episode_returns(algorithm)
        evaluated = algorithm.current_morphologies()
        record.observe(Tick(tick=tick, samples=samples, wall_time=wall_time,
                            episode_return=mean_return,
                            population=_draw(algorithm, record),
                            evaluated=evaluated,
                            evaluated_returns=_attributed(evaluated, per_design, record),
                            algorithm=algorithm))
        if rundir is not None:
            # Rewritten every tick, which is what lets a live view read a multi-hour run. The write
            # is atomic, so the cadence costs nothing if the process dies mid-write.
            record.save(rundir.path / RECORD)

        if on_run is not None:
            on_run(Progress(tick=tick, reward=reward, best_reward=best_reward,
                            wall_time=wall_time, samples=samples,
                            morphologies=evaluated))

    if best_reward is None:
        raise RuntimeError(
            f"{algorithm.name} was finished before it ran, so there is nothing to return. An "
            "algorithm entering a fixed-morphology phase must reset its budget in "
            "`apply_fixed_morphologies`; one that did not will look finished here.")

    if rundir is not None:
        rundir.finish(algorithm, samples=samples)
        for path in rundir.take_new_retained():
            record.note_retained(_stamp(path), path)
    record.finish(samples=samples, wall_time=time.perf_counter() - start)
    if rundir is not None:
        record.save(rundir.path / RECORD)
    return best_reward, best_policy, best_generator, record


def _episode_returns(algorithm: Algorithm):
    """The package's own **Episode return** for the window just ended, taken from the Task.

    Taken here rather than reported by the algorithm, for the reason the definition gives: it is the
    same quantity for every method only if one place measures it, and the step loop is the one place
    no algorithm can bypass. `(mean, per_design)`, the second `None` where the Task publishes no
    design layout -- and note that the split is the Task's attribution, not the algorithm's word for
    which body earned what.
    """
    if algorithm.task is None:
        return None, None
    return algorithm.task.take_episode_returns()


def _attributed(evaluated, per_design, record: MetricRecord):
    """`per_design` if it lines up with `evaluated`, else None -- and say so once when it does not.

    A silent misalignment is the failure worth spending a check on: every downstream reading still
    looks like a per-design figure, and a design charged with another's return is invisible in the
    output. Warned rather than raised, on the same principle as the draw: a measurement must never
    be what kills a run.
    """
    if evaluated is None or per_design is None:
        return None
    if len(evaluated) != len(per_design):
        note = (f"per-design returns dropped: the Task attributes {len(per_design)} designs but the "
                f"algorithm reports {len(evaluated)} under evaluation")
        if note not in record.warnings:
            record.warnings.append(note)
        return None
    return per_design


def _draw(algorithm: Algorithm, record: MetricRecord):
    """One batched draw from the designer, shared by every exploration metric this tick.

    Guarded, because a measurement must never be what kills a run: an algorithm whose generator is
    not ready -- or throws -- loses the exploration metrics for that tick and keeps training.
    """
    if not record.population:
        return None
    try:
        return algorithm.morphology_generator().generate(record.population, deterministic=False)
    except Exception as exc:                                        # noqa: BLE001
        note = f"design draw failed ({type(exc).__name__}: {exc})"
        if note not in record.warnings:
            record.warnings.append(note)
        return None


def _stamp(path) -> int:
    from codesigner.rundir import retained_samples
    return retained_samples(path)
