"""The driver: run an algorithm against a task and a module library until it says it is done."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional, Tuple, Union

from codesigner.interfaces import Algorithm, ControlPolicy, ModuleLibrary, MorphologyGenerator, Task
from codesigner.progress import Progress, print_progress


def optimize(
    algorithm: Algorithm,
    task: Task,
    modlib: ModuleLibrary,
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    on_iteration: Optional[Callable[[Progress], None]] = None,
    checkpoint_path: Optional[Union[str, Path]] = None,
) -> Tuple[float, ControlPolicy, MorphologyGenerator]:
    """Optimize a body and a controller for `task`, over the modules in `modlib`.

    Returns the best objective reached and the two artifacts that reached it.

    Progress arrives on two callbacks (D25/26). `on_run` fires here after every `algorithm.run()`
    and is therefore **guaranteed** -- it defaults to printing a line per tick, and `None` silences
    it. `on_iteration` is handed to the algorithm to fire at its own inner cadence: frequent, but
    **best-effort**, since an algorithm with no inner step will never call it. Both carry a
    `Progress`.

    `checkpoint_path` writes a checkpoint after every run tick, overwriting in place. Cadence
    therefore follows whatever the algorithm made its `run()` unit -- which for a codesign algorithm
    should be its rebuild boundary, since `Task.resample` carries a known intermittent crash with no
    auto-resume and the checkpoint interval is the maximum loss (D24).
    """
    algorithm.assign_task_and_modlib(task, modlib)
    algorithm.attach_progress(on_iteration)

    start = time.perf_counter()
    best_reward: Optional[float] = None
    best_policy: Optional[ControlPolicy] = None
    best_generator: Optional[MorphologyGenerator] = None
    step = 0

    while not algorithm.is_finished():
        reward, policy, generator = algorithm.run()
        step += 1

        # Artifacts are tracked at the best objective, not the last: a run that ends mid-collapse
        # should still hand back the body and controller that worked. `>=` so a run whose reward
        # plateaus still returns its most recent -- most-trained -- artifacts rather than the first
        # ones to hit the plateau.
        if best_reward is None or reward >= best_reward:
            best_reward, best_policy, best_generator = reward, policy, generator

        if checkpoint_path is not None:
            algorithm.save_checkpoint(checkpoint_path)

        if on_run is not None:
            on_run(Progress(step=step, reward=reward, best_reward=best_reward,
                            wall_time=time.perf_counter() - start,
                            morphologies=algorithm.current_morphologies()))

    if best_reward is None:
        raise RuntimeError(
            f"{algorithm.name} was finished before it ran, so there is nothing to return")
    return best_reward, best_policy, best_generator
