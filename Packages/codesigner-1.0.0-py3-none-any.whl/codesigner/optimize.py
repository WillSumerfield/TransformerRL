"""The driver: run an algorithm against a task and a module library until it says it is done."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional, Tuple, Union

from codesigner.interfaces import Algorithm, ControlPolicy, ModuleLibrary, MorphologyGenerator, Task
from codesigner.metrics.base import Tick
from codesigner.metrics.record import RECORD, MetricRecord
from codesigner.progress import Progress, print_progress
from codesigner.rundir import CONFIG, LATEST, RunDirectory, holds_run


def optimize(
    algorithm: Algorithm,
    task: Task,
    modlib: ModuleLibrary,
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    on_iteration: Optional[Callable[[Progress], None]] = None,
    checkpoint_dir: Optional[Union[str, Path]] = None,
    sample_budget: Optional[int] = None,
    retain: Optional[int] = 3,
    retain_every_ticks: Optional[int] = None,
    metrics: Optional[MetricRecord] = None,
    resume: bool = False,
) -> Tuple[float, ControlPolicy, MorphologyGenerator, MetricRecord]:
    """Optimize a body and a controller for `task`, over the modules in `modlib`.

    Returns the best objective reached, the two artifacts that reached it, and the run's
    **Metric record**.

    Progress arrives on two callbacks (D25/26). `on_run` fires here after every `algorithm.run()`
    and is therefore **guaranteed** -- it defaults to printing a line per tick, and `None` silences
    it. `on_iteration` is handed to the algorithm to fire at its own inner cadence: frequent, but
    **best-effort**, since an algorithm with no inner step will never call it. Both carry a
    `Progress`.

    `checkpoint_dir` is one directory holding everything this run saved -- rolling and best
    checkpoints, retained checkpoints, the metric record, and the config that produced them. The
    user names and places it; the package names what goes inside. See `rundir`. `None` saves
    nothing, and the record is then only what this call returns.

    `sample_budget` is the number of **samples** -- one env advanced by one control step -- this run
    may spend, and the only budget two methods can be matched on: an epoch, a generation and a trial
    are not comparable units. Enforced here alongside the algorithm's own stopping rule, whichever
    fires first. The driver regains control only at a run boundary, so a run overshoots by at most
    one run unit rather than stopping mid-`run()`.

    `retain` / `retain_every_ticks` are the retention policy, documented on `RunDirectory`.

    `metrics` is the record to fill. Pass one to choose the metric set or configure a metric; leave
    it out and the driver builds the standard set, so a run is measured whether or not anyone asked.

    `resume` continues the run already in `checkpoint_dir`, from its rolling checkpoint, as **one
    run**: the sample budget is the total that run may spend rather than a fresh allowance, its
    curves continue on the same axes, and its retained set is added to rather than restarted. On a
    directory that does not exist yet it starts a fresh run, so one script survives being requeued
    without an edit. Raising the algorithm's own limit, or the budget, is how a finished run is
    *extended*; both are recorded as a new segment rather than overwriting what the earlier stretch
    was run with.
    """
    algorithm.assign_task_and_modlib(task, modlib)
    algorithm.attach_progress(on_iteration)
    return drive(algorithm, on_run=on_run, checkpoint_dir=checkpoint_dir,
                 sample_budget=sample_budget, retain=retain,
                 retain_every_ticks=retain_every_ticks, metrics=metrics, resume=resume)


def drive(
    algorithm: Algorithm,
    on_run: Optional[Callable[[Progress], None]] = print_progress,
    checkpoint_dir: Optional[Union[str, Path]] = None,
    sample_budget: Optional[int] = None,
    retain: Optional[int] = 3,
    retain_every_ticks: Optional[int] = None,
    metrics: Optional[MetricRecord] = None,
    resume: bool = False,
) -> Tuple[float, ControlPolicy, MorphologyGenerator, MetricRecord]:
    """Step `algorithm` until it says it is done, ticking, checkpointing and measuring at each run
    boundary.

    The loop itself, with the binding removed. `optimize` binds a Task and a library and calls this;
    `optimize_control` and `refine_control` bind, fix a body set, and call this. **Run**, the
    guaranteed progress tick, the sample budget, the checkpoint cadence and the metric cadence are
    therefore defined once rather than restated per entry point, which is the whole reason the
    control entry points are thin.

    Expects `assign_task_and_modlib` and `attach_progress` to have been called already.
    """
    resumed = _resume_from(algorithm, checkpoint_dir, resume, sample_budget)
    spent = resumed["samples"] if resumed else 0

    rundir = None
    if checkpoint_dir is not None:
        # Constructed before the first `run()`, so a directory that already holds a run is refused
        # while nothing has been spent rather than after an hour of training.
        rundir = RunDirectory(checkpoint_dir, sample_budget=sample_budget, retain=retain,
                              retain_every_ticks=retain_every_ticks,
                              resume=resumed is not None, spent=spent)
        rundir.write_config(algorithm, spent=spent)

    record = metrics if metrics is not None else MetricRecord()
    record.attach(algorithm, {"sample_budget": sample_budget, "retain": retain,
                              "retain_every_ticks": retain_every_ticks,
                              "retains": rundir.retains if rundir is not None else False,
                              "retention_reason": (rundir.unavailable_reason if rundir is not None
                                                   else "this run saves nothing: no checkpoint_dir "
                                                        "was given"),
                              "checkpoint_dir": str(checkpoint_dir) if checkpoint_dir else None,
                              "resumed_from_samples": spent if resumed else None})
    if resumed:
        # After `attach`, which describes the run as it stands now: the record then carries this
        # segment's configuration over the whole run's history, rather than the other way round.
        record.adopt(Path(checkpoint_dir), samples=spent, wall_time=resumed["wall_time"])
        record.restore_metric_state(resumed["metric_state"])

    # The clock is set back by what the run already accumulated, so wall time keeps measuring what
    # the METHOD cost. The days a crashed process sat dead are not the method's cost, and they are
    # exactly what an absolute clock would charge it for.
    start = time.perf_counter() - (resumed["wall_time"] if resumed else 0.0)
    # A delta, not the Task's own count. The same live Task is deliberately passed straight from a
    # finished `optimize` into `refine_control`, and its counter is monotone across that handover;
    # measuring absolutely would put the refinement past its budget before it ran once.
    spent_before = algorithm.task.samples if algorithm.task is not None else 0

    # Seeded from the position, so a resumed run does not overwrite a better `best.ckpt` with the
    # first tick it happens to run: the comparison is against the whole run's best, never this
    # segment's.
    best_reward: Optional[float] = resumed["best_reward"] if resumed else None
    best_policy: Optional[ControlPolicy] = None
    best_generator: Optional[MorphologyGenerator] = None
    last_policy: Optional[ControlPolicy] = None
    last_generator: Optional[MorphologyGenerator] = None
    tick = resumed["tick"] if resumed else 0
    samples = spent

    while not algorithm.is_finished() and (sample_budget is None or samples < sample_budget):
        reward, policy, generator = algorithm.run()
        tick += 1
        samples = spent + ((algorithm.task.samples - spent_before)
                           if algorithm.task is not None else 0)
        wall_time = time.perf_counter() - start
        last_policy, last_generator = policy, generator

        # Artifacts are tracked at the best objective, not the last: a run that ends mid-collapse
        # should still hand back the body and controller that worked. `>=` so a run whose reward
        # plateaus still returns its most recent -- most-trained -- artifacts rather than the first
        # ones to hit the plateau.
        improved = best_reward is None or reward >= best_reward
        if improved:
            best_reward, best_policy, best_generator = reward, policy, generator

        if rundir is not None:
            # Written before the record, so on a crash between the two this file is the one that
            # is a tick ahead -- the direction that keeps what a resume reads consistent with the
            # weights it reads it from. The metrics' state is taken before they observe this tick,
            # for the same reason: it describes the run at the position recorded here.
            rundir.tick(algorithm, tick=tick, samples=samples, improved=improved,
                        position={"samples": samples, "tick": tick,
                                  "wall_time": round(wall_time, 3), "best_reward": best_reward},
                        metric_state=record.metric_state())
            for path in rundir.take_new_retained():
                record.note_retained(_stamp(path), path)

        # Taken once and shared: the take clears the accumulator, so a second reader would get an
        # empty window, and `current_morphologies` is a rebuild of the population for algorithms
        # that hold one -- neither is a call to make twice a tick.
        mean_return, per_design = _episode_returns(algorithm)
        evaluated = algorithm.current_morphologies()
        record.observe(Tick(tick=tick, samples=samples, wall_time=wall_time,
                            episode_return=mean_return,
                            population=_draw(algorithm, record),
                            evaluated=evaluated,
                            evaluated_returns=_attributed(evaluated, per_design, record),
                            algorithm=algorithm))
        if rundir is not None:
            # Rewritten every tick, which is what lets a live view read a multi-hour run. The write
            # is atomic, so the cadence costs nothing if the process dies mid-write.
            record.save(rundir.path / RECORD)

        if on_run is not None:
            on_run(Progress(tick=tick, reward=reward, best_reward=best_reward,
                            wall_time=wall_time, samples=samples,
                            morphologies=evaluated))

    if best_reward is None:
        raise RuntimeError(
            f"{algorithm.name} was finished before it ran, so there is nothing to return. An "
            "algorithm entering a fixed-morphology phase must reset its budget in "
            "`apply_fixed_morphologies`; one that did not will look finished here.")

    if rundir is not None:
        rundir.finish(algorithm, samples=samples,
                      position={"samples": samples, "tick": tick,
                                "wall_time": round(time.perf_counter() - start, 3),
                                "best_reward": best_reward},
                      metric_state=record.metric_state())
        for path in rundir.take_new_retained():
            record.note_retained(_stamp(path), path)
    record.finish(samples=samples, wall_time=time.perf_counter() - start)

    if best_policy is None:
        # A resumed segment that never beat what the run had already reached. The reward returned is
        # the run's, so the artifacts must be too -- and those are on disk in `best`, not in memory
        # here. Reloading is safe only now: the algorithm has finished running, and every checkpoint
        # this run owes has been written.
        best_policy, best_generator = _best_from_disk(algorithm, rundir, record)
        best_policy = best_policy if best_policy is not None else last_policy
        best_generator = best_generator if best_generator is not None else last_generator
    if rundir is not None:
        record.save(rundir.path / RECORD)
    return best_reward, best_policy, best_generator, record


def _resume_from(algorithm: Algorithm, checkpoint_dir, resume: bool,
                 sample_budget: Optional[int]) -> Optional[dict]:
    """Load the run in `checkpoint_dir` into `algorithm`, and return where it had got to.

    `None` means "start fresh", which is what `resume=True` on a directory that does not exist yet
    means: the flag says *run or continue*, so one script can be requeued without being edited.

    Everything a resume refuses, it refuses here -- before a `RunDirectory` exists and before
    anything is spent. A checkpoint with no position was written before resume existed and cannot
    say where the run was; a different algorithm is the blunder worth catching, since one method's
    payload loaded into another would leave a directory that reads afterwards as a single coherent
    run; and a run already over is refused rather than returning after zero ticks, because a silent
    no-op looks exactly like a completed extension and is found out from a flat curve.
    """
    if not resume:
        return None
    if checkpoint_dir is None:
        raise ValueError("resume=True needs a checkpoint_dir: it continues the run saved in one, "
                         "and a run that saved nothing left nothing to continue")
    path = Path(checkpoint_dir)
    if not holds_run(path):
        return None

    _verify_algorithm(path / CONFIG, algorithm)
    ckpt = algorithm.load_checkpoint(path / LATEST)
    position = ckpt.get("position")
    if position is None:
        raise RuntimeError(
            f"{path / LATEST} records no run position, so there is nothing to resume from -- it "
            f"was written before checkpoints carried one. Its weights still load: pass it to "
            f"`refine_control`, or start a new run.")

    if algorithm.is_finished():
        raise RuntimeError(
            f"{path} is finished by {algorithm.name}'s own stopping rule, so resuming it would run "
            f"nothing. Re-targeting sample_budget does not extend it -- the two rules race and the "
            f"earlier one wins. Construct the algorithm with a higher limit (generations, epochs) "
            f"to continue, or start a new run.")
    if sample_budget is not None and position["samples"] >= sample_budget:
        raise RuntimeError(
            f"{path} has spent {position['samples']} samples of a {sample_budget} budget, so "
            f"resuming it would run nothing. Raise sample_budget to extend the run; the stretch "
            f"that ran under the old one stays recorded as its own segment.")

    print(f"[codesigner] resuming {path} at {position['samples']} samples, tick "
          f"{position['tick']}, best reward {position['best_reward']}", flush=True)
    return {**position, "metric_state": ckpt.get("metric_state")}


def _verify_algorithm(config_path: Path, algorithm: Algorithm) -> None:
    """Refuse a resume that would change which algorithm is running.

    The name only. Config differences are *recorded* as a new segment and never refused: raising a
    generation limit is how a run is extended, so an equality check on the config would refuse the
    thing resume is for. Provenance here is documentation a reader uses to see whether two records
    are comparable, not a gate -- the same terms as everywhere else in this package.
    """
    if not config_path.exists():
        return
    import json

    recorded = json.loads(config_path.read_text()).get("algorithm", {}).get("name")
    if recorded is not None and recorded != algorithm.name:
        raise RuntimeError(
            f"{config_path.parent} was run by {recorded!r} and this is {algorithm.name!r}. A "
            f"resume continues one run, and loading one method's payload into another would leave "
            f"a directory that reads afterwards as a single coherent run.")


def _best_from_disk(algorithm: Algorithm, rundir, record):
    """The artifacts in `best`, reconstituted, for a segment that never beat it.

    Costs one load and mutates the algorithm, which is why it happens only after the last checkpoint
    this run owes has been written. Returns `(None, None)` when there is nothing to read, and the
    caller falls back to the last tick's artifacts rather than handing back nothing.
    """
    if rundir is None or not rundir.best_path.exists():
        return None, None
    try:
        algorithm.load_checkpoint(rundir.best_path)
        return algorithm.control_policy(), algorithm.morphology_generator()
    except Exception as exc:                                            # noqa: BLE001
        record.warnings.append(
            f"this segment did not beat the run's best, and {rundir.best_path.name} could not be "
            f"reloaded ({type(exc).__name__}: {exc}); the artifacts returned are the last tick's "
            f"rather than the run's best")
        return None, None


def _episode_returns(algorithm: Algorithm):
    """The package's own **Episode return** for the window just ended, taken from the Task.

    Taken here rather than reported by the algorithm, for the reason the definition gives: it is the
    same quantity for every method only if one place measures it, and the step loop is the one place
    no algorithm can bypass. `(mean, per_design)`, the second `None` where the Task publishes no
    design layout -- and note that the split is the Task's attribution, not the algorithm's word for
    which body earned what.
    """
    if algorithm.task is None:
        return None, None
    return algorithm.task.take_episode_returns()


def _attributed(evaluated, per_design, record: MetricRecord):
    """`per_design` if it lines up with `evaluated`, else None -- and say so once when it does not.

    A silent misalignment is the failure worth spending a check on: every downstream reading still
    looks like a per-design figure, and a design charged with another's return is invisible in the
    output. Warned rather than raised, on the same principle as the draw: a measurement must never
    be what kills a run.
    """
    if evaluated is None or per_design is None:
        return None
    if len(evaluated) != len(per_design):
        note = (f"per-design returns dropped: the Task attributes {len(per_design)} designs but the "
                f"algorithm reports {len(evaluated)} under evaluation")
        if note not in record.warnings:
            record.warnings.append(note)
        return None
    return per_design


def _draw(algorithm: Algorithm, record: MetricRecord):
    """One batched draw from the designer, shared by every exploration metric this tick.

    Guarded, because a measurement must never be what kills a run: an algorithm whose generator is
    not ready -- or throws -- loses the exploration metrics for that tick and keeps training.
    """
    if not record.population:
        return None
    try:
        return algorithm.morphology_generator().generate(record.population, deterministic=False)
    except Exception as exc:                                        # noqa: BLE001
        note = f"design draw failed ({type(exc).__name__}: {exc})"
        if note not in record.warnings:
            record.warnings.append(note)
        return None


def _stamp(path) -> int:
    from codesigner.rundir import retained_samples
    return retained_samples(path)
