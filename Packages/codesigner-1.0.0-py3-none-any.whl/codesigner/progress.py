"""The one record type both progress callbacks carry (D25/26).

Two ticks report progress, at different cadences and with different guarantees:

  **run tick**       fired by `optimize` after every `Algorithm.run()`. Guaranteed: the driver owns
                     it, so every algorithm reports at least this.
  **iteration tick** fired by the algorithm itself at its own inner cadence -- an RL epoch, a
                     generation, a BO trial. Frequent, algorithm-defined, and **best-effort**: an
                     algorithm with no inner step simply never fires it, and a consumer must not
                     wait on one.

Both carry this record, so a consumer writes one handler and points it at either. Every field but
`step` is optional, because what an algorithm can cheaply report differs -- a generation-based
method knows its population, a policy-gradient method knows a running reward and not much else.

Deliberately generic naming: "epoch" is RL-specific, and this record is what a Bayesian-optimization
or evolutionary implementor fills too. Algorithm-specific richness (losses, entropies, per-body
diagnostics) stays in that algorithm's own logging -- this is the common denominator the package
reports, not a metrics bus.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from codesigner.interfaces.modlib import Morphology


@dataclass
class Progress:
    """One progress report. See the module docstring for which tick fired it."""

    step: int
    """Which tick this is, counted from 1 within its own cadence. Run ticks and iteration ticks
    count independently, so a consumer must not compare one's step against the other's."""

    reward: Optional[float] = None
    """The objective as of this tick -- whatever the algorithm currently achieves, not its best."""

    best_reward: Optional[float] = None
    """Best objective seen so far in this run. Monotone by construction, so a consumer can plot it
    against `reward` to see how far the current iterate has fallen behind the incumbent."""

    wall_time: Optional[float] = None
    """Seconds since `optimize` started. Wall clock, not compute time: the rebuild cost that
    dominates a codesign run is real time an algorithm-step counter does not see."""

    morphologies: Optional[List[Morphology]] = None
    """The bodies currently under evaluation, when the algorithm holds a population. `None` means
    "not reported", never "no bodies"."""


def print_progress(record: Progress) -> None:
    """The default run-tick handler: one line per tick, fields that are None left out."""
    parts = [f"step {record.step}"]
    if record.reward is not None:
        parts.append(f"reward {record.reward:.4g}")
    if record.best_reward is not None:
        parts.append(f"best {record.best_reward:.4g}")
    if record.morphologies is not None:
        parts.append(f"{len(record.morphologies)} bodies")
    if record.wall_time is not None:
        parts.append(f"{record.wall_time:.1f}s")
    print("[codesigner] " + " | ".join(parts), flush=True)
