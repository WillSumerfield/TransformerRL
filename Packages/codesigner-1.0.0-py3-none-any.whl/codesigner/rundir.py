"""The run directory: everything one run saved, in one place the user named.

A run used to write a single file at a path the caller invented, overwritten every tick. That file
held the *last* tick while `optimize` returned the *best* artifacts, it recorded nothing about what
produced it, and there was no second copy of the run at any earlier point -- so nothing could ask
what a method looked like a third of the way in.

One directory instead, whose name and location are the user's and whose contents are the package's::

    runs/ea-seed0/            <- the user's name, the user's location
      config.json             what produced this run
      latest.ckpt             rewritten every run tick
      best.ckpt               rewritten when the objective improves
      retained/
        s000000330000.ckpt    written once, never revised
        s000000660000.ckpt
        s000001000000.ckpt

**latest and best are different jobs.** `latest` is crash recovery: it holds wherever the run
actually got to, so restarting loses at most one run unit. `best` is the artifact -- it matches what
`optimize` hands back, and the two diverge exactly when a run ends worse than it peaked. Keeping only
one of them means either a collapsed run leaves a collapsed file, or a long plateau leaves a stale
one; the second file costs a write on improvement, which is rare after the early ticks.

**Retained checkpoints are stamped with samples, never with ticks or fractions.** A **Tick** is
algorithm-defined -- one `run()` may be a generation or the whole of training -- so tick 40 is not a
place two methods share. A sample count is. The stamp is also the count actually reached rather than
the fraction aimed at: the driver only regains control at a run boundary, so a fraction is always
crossed mid-tick and a `0.66.ckpt` would be naming a figure the file does not hold. Zero-padded so
lexical order is numeric order, and wide enough for the counts that actually occur (a 4096-env run
at a million control steps is already 4e9 samples).

**A directory that already holds a run is refused, unless that run is being resumed.** Two runs
merged into one folder still look valid, and the retained set would read as one trajectory when it
is two -- the failure is silent and lands in whatever comparison the folder is later used for. A
**Resume** is the one case where the second thing written is the *same* run, which is why it is
asked for explicitly rather than inferred from the directory being there.

A resumed directory is added to rather than rebuilt: `latest` and `best` carry on being rewritten,
the retained set keeps what it has and its cursor is placed past every threshold already crossed,
and `config.json` gains a **segment** rather than being overwritten -- so the stamp saying when the
run started still says when the run started, and a stretch that ran with a different budget or a
raised generation limit is visible as the stretch it was.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import List, Optional, Union

LATEST = "latest.ckpt"
BEST = "best.ckpt"
RETAINED = "retained"
CONFIG = "config.json"

STAMP_WIDTH = 12
"""Digits in a retained checkpoint's sample stamp, so lexical sort equals numeric sort."""


def retained_name(samples: int) -> str:
    """The filename a retained checkpoint takes at `samples`."""
    return f"s{samples:0{STAMP_WIDTH}d}.ckpt"


def retained_samples(path: Union[str, Path]) -> int:
    """The sample count a retained checkpoint's name encodes."""
    return int(Path(path).stem.lstrip("s"))


def resolve(path: Union[str, Path], prefer: str = BEST) -> Path:
    """A checkpoint file, given either a file or a run directory.

    Lets `evaluate` and `refine_control` take the directory a run was given, which is the name the
    user actually has, rather than making them remember which file inside it they want. `prefer`
    picks between `best` (the artifact -- what you want to score or refine) and `latest` (where the
    run got to). A path that is not a directory is returned untouched, so an explicit file -- a
    retained checkpoint among them -- still works.
    """
    path = Path(path)
    if not path.is_dir():
        return path
    chosen = path / prefer
    if chosen.exists():
        return chosen
    other = path / (LATEST if prefer == BEST else BEST)
    if other.exists():
        return other
    raise FileNotFoundError(
        f"{path} is a run directory holding no {prefer} -- it has "
        f"{sorted(p.name for p in path.iterdir())}. Name a checkpoint file directly.")


class RunDirectory:
    """The layout above, and the retention policy that fills it.

    Constructed by `drive` when a `checkpoint_dir` was given. Refusal and directory creation happen
    here, in the constructor, so a bad path is an error before the run spends anything rather than
    after the first tick.
    """

    def __init__(self, path: Union[str, Path], sample_budget: Optional[int] = None,
                 retain: Optional[int] = 3, retain_every_ticks: Optional[int] = None,
                 resume: bool = False, spent: int = 0):
        """`retain` keeps *n* checkpoints evenly spaced over `sample_budget`, at i/n of it.
        `retain_every_ticks` keeps one every *n* run ticks instead. They are alternatives, and
        `retain=None` with no tick cadence keeps nothing but `latest` and `best`.

        The two are not equally good and the difference is not a detail. `retain=n` puts an early, a
        middle and a final at the *same fractions* of every method's run, which is the whole basis
        on which a protocol may compare methods at three points. `retain_every_ticks` fires on an
        algorithm-defined unit, so its saves land wherever that algorithm's run unit happened to
        fall and "mid-run" means something different per method; it also grows without bound. It is
        for watching a run, not for comparing runs -- and it is the only policy available when there
        is no budget to take fractions of.

        `resume` lifts the refusal for this directory alone, and `spent` is what earlier segments of
        the same run already cost. The cursor is placed past every threshold `spent` has crossed, so
        a resumed run neither rewrites a retained checkpoint it already has nor skips one it does
        not. A re-targeted budget recomputes the thresholds and leaves the files spaced over the old
        one where they are: a protocol reads by fraction of realized spend, so an off-ladder file
        costs a little disk and changes nothing it means.
        """
        if retain is not None and retain_every_ticks is not None:
            raise ValueError(
                "retain and retain_every_ticks are alternative retention policies; pass one. "
                "`retain=n` spaces n saves over the sample budget and is what a protocol reads; "
                "`retain_every_ticks=n` fires on the algorithm's own unit and is diagnostic.")
        if retain is not None and retain < 1:
            raise ValueError(f"retain must be at least 1, got {retain}")
        if retain_every_ticks is not None and retain_every_ticks < 1:
            raise ValueError(f"retain_every_ticks must be at least 1, got {retain_every_ticks}")

        self.path = Path(path)
        self.sample_budget = sample_budget
        self.retain = retain
        self.retain_every_ticks = retain_every_ticks

        occupied = self.path.exists() and any(self.path.iterdir())
        if occupied and not resume:
            raise FileExistsError(
                f"{self.path} is not empty, and a run directory is never added to: two runs' "
                f"checkpoints in one folder still look like one run's, and whatever reads the "
                f"folder later cannot tell. Name a new directory, remove this one, or pass "
                f"resume=True to continue the run that is already there.")
        if occupied and not self.latest_path.exists():
            raise FileExistsError(
                f"{self.path} is not empty but holds no {LATEST}, so there is no run in it to "
                f"resume -- it has {sorted(p.name for p in self.path.iterdir())}. A resume "
                f"continues from the rolling checkpoint; name a different directory.")
        self.resumed = occupied
        self.retained_dir.mkdir(parents=True, exist_ok=True)

        # Absolute sample counts rather than fractions, resolved once. Nothing downstream sees a
        # fraction again -- the stamp is the realized count, so a target is a threshold to cross and
        # not a name to write.
        self._targets: List[int] = []
        if retain is not None and sample_budget is not None:
            self._targets = [round(sample_budget * (i + 1) / retain) for i in range(retain)]
        # Already on disk from an earlier segment, and already listed in that segment's record, so
        # they are counted as reported: re-reporting them would double every entry in the record's
        # retained list on each resume.
        self._retained: List[Path] = (sorted(self.retained_dir.glob("s*.ckpt"))
                                      if self.resumed else [])
        self._reported = len(self._retained)
        self._next_target = sum(1 for target in self._targets if target <= spent)

    # ---- layout --------------------------------------------------------------------

    @property
    def latest_path(self) -> Path:
        return self.path / LATEST

    @property
    def best_path(self) -> Path:
        return self.path / BEST

    @property
    def retained_dir(self) -> Path:
        return self.path / RETAINED

    @property
    def retained(self) -> List[Path]:
        """What has been retained, in sample order."""
        return list(self._retained)

    def take_new_retained(self) -> List[Path]:
        """What has been retained since this was last called.

        The **Metric record** lists what was retained with its sample count, so nothing downstream
        reconstructs a filename; this is how the driver feeds it without re-scanning the directory.
        """
        out = self._retained[self._reported:]
        self._reported = len(self._retained)
        return out

    @property
    def retains(self) -> bool:
        """Whether any retention policy is in force.

        False means every **Protocol** is unavailable for this run, and says so for a reason a user
        can act on: nothing was kept to run one against. Reachable two ways -- no policy asked for,
        or `retain=n` with no budget to take fractions of.
        """
        return bool(self._targets) or self.retain_every_ticks is not None

    @property
    def unavailable_reason(self) -> Optional[str]:
        """Why nothing is retained, phrased for a reader, or None when something is."""
        if self.retains:
            return None
        if self.retain is not None and self.sample_budget is None:
            return ("retain=%r spaces checkpoints over the sample budget, and no sample_budget was "
                    "set, so there was nothing to take fractions of" % self.retain)
        return "no retention policy was in force, so no checkpoint was kept to run this on"

    # ---- writing -------------------------------------------------------------------

    def write_config(self, algorithm, spent: int = 0) -> None:
        """Record what produced this run, in text, before it starts.

        Plain JSON beside the checkpoints so a directory can be identified without loading a torch
        file -- which is the difference between a folder a person can browse and a folder they have
        to write a script to read.

        A resume **appends a segment** instead of overwriting. The top level always describes the
        run as it stands now -- current budget, current algorithm config -- and `started` keeps
        saying when the run first started; `segments` says what each stretch was run with and from
        what sample count, since a resumed stretch may raise a generation limit, re-target the
        budget, or sit on a different machine, and a reader comparing this run with another has to
        be able to see that.
        """
        segment = {
            "started": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "from_samples": spent,
            "sample_budget": self.sample_budget,
            "algorithm_config": dict(algorithm.config),
            "host": _host(),
            "device": _device(algorithm.task),
        }
        config = {
            "algorithm": {"name": algorithm.name, "description": algorithm.description,
                          "config": dict(algorithm.config)},
            "task": _task_key(algorithm.task),
            "library": {**algorithm.modlib.descriptor(), "kwargs": dict(algorithm.library_kwargs)},
            "sample_budget": self.sample_budget,
            "retention": {"retain": self.retain, "retain_every_ticks": self.retain_every_ticks},
            "fixed_morphologies": len(algorithm.fixed_morphologies or []) or None,
            "started": segment["started"],
            "segments": [segment],
        }
        path = self.path / CONFIG
        if self.resumed and path.exists():
            previous = json.loads(path.read_text())
            config["started"] = previous.get("started", config["started"])
            config["segments"] = list(previous.get("segments", [])) + [segment]
        path.write_text(json.dumps(config, indent=2, default=str))

    def tick(self, algorithm, tick: int, samples: int, improved: bool,
             position: Optional[dict] = None, metric_state: Optional[dict] = None) -> None:
        """Write what this run tick calls for: always `latest`, `best` on an improvement, and a
        retained copy if a threshold was crossed.

        `samples` is the count consumed by *this run*, so a Task carried over from an earlier run
        does not push every threshold past itself on the first tick. `position` and `metric_state`
        are what a **Resume** continues from; they go into every file written here, so a run resumes
        from `latest` and a protocol reading a retained checkpoint sees where it sat.
        """
        algorithm.save_checkpoint(self.latest_path, position=position, metric_state=metric_state)
        if improved:
            algorithm.save_checkpoint(self.best_path, position=position, metric_state=metric_state)

        if self.retain_every_ticks is not None:
            if tick % self.retain_every_ticks == 0:
                self._retain(algorithm, samples, position, metric_state)
        elif self._next_target < len(self._targets) and samples >= self._targets[self._next_target]:
            # Advance past every threshold this tick crossed, not just one. A run unit large next to
            # the budget can step over two, and retaining twice at the same sample count would write
            # the same file under the same name.
            while (self._next_target < len(self._targets)
                   and samples >= self._targets[self._next_target]):
                self._next_target += 1
            self._retain(algorithm, samples, position, metric_state)

    def finish(self, algorithm, samples: int, position: Optional[dict] = None,
               metric_state: Optional[dict] = None) -> None:
        """Retain the endpoint, if a policy is in force and the last tick did not already.

        A run that stops on its own rule rather than on the budget never crosses the final
        threshold, and a retained set missing its endpoint is missing the one point every protocol
        needs. "The end" is where the run ended, which is not always where the budget was.
        """
        if self.retains and not (self._retained
                                 and retained_samples(self._retained[-1]) == samples):
            self._retain(algorithm, samples, position, metric_state)

    def _retain(self, algorithm, samples: int, position: Optional[dict] = None,
                metric_state: Optional[dict] = None) -> None:
        path = self.retained_dir / retained_name(samples)
        algorithm.save_checkpoint(path, position=position, metric_state=metric_state)
        self._retained.append(path)


def holds_run(path: Union[str, Path]) -> bool:
    """Whether `path` is a directory a **Resume** can continue: it exists and holds a rolling
    checkpoint. False for a path that does not exist yet, which is a fresh run rather than an
    error."""
    path = Path(path)
    return path.is_dir() and (path / LATEST).exists()


def _host() -> Optional[str]:
    """The machine a segment ran on. Recorded, never checked -- a resumed segment on a different
    GPU makes the run's *time* axis a splice of two throughputs, and a reader can only allow for
    that if the record says it happened."""
    import socket
    try:
        return socket.gethostname()
    except Exception:                                                   # noqa: BLE001
        return None


def _device(task) -> Optional[str]:
    if task is None or getattr(task, "device", None) is None:
        return None
    try:
        import torch
        if task.device.type == "cuda":
            return torch.cuda.get_device_name(task.device)
    except Exception:                                                   # noqa: BLE001
        pass
    return str(task.device)


def _task_key(task) -> Optional[str]:
    """The Task's registry key, or None for one that is not registered.

    The import is both lazy and guarded: `codesigner.components.tasks` pulls in the backend, and
    this module is otherwise pure filesystem work that a machine with no simulator can exercise.
    """
    if task is None:
        return None
    from codesigner.components.tasks import registry_key

    return registry_key(task)
